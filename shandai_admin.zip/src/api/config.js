export var imgUrl = 'http://su.bangyiwl.com:8082/'
export var uploadUrl = 'http://su.bangyiwl.com:8083/'
export var downloadUrl = 'http://su.bangyiwl.com:8083/'

