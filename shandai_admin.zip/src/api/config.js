export var imgUrl = 'http://yi.bangyiwl.com:8000/'
export var uploadUrl = 'http://yi.bangyiwl.com:8081/'
export var downloadUrl = 'http://yi.bangyiwl.com:8081/'

