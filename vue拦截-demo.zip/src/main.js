// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill'  //
import Vue from 'vue'
import store from './store'
import App from './App'
import router from './router'
import axios from './api/require-post'
import './filter'   	//导入过滤器
import './validator'   //导入表单验证
// import VueCookies from 'vue-cookies'
// Vue.use(VueCookies)
Vue.config.productionTip = false
// 将axios挂载到prototype上，在组件中可以直接使用this.axios访问
Vue.prototype.axios = axios;
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  axios,
  store,
  template: '<App/>',
  components: { App }
})
		


/**
* to          即将要进入的目标 路由对象
* from        当前导航正要离开的路由
* next()      进行管道中的下一个钩子。如果全部钩子执行完了，则导航的状态就是 confirmed （确认的）。
* next(false) 中断当前的导航。如果浏览器的 URL 改变了（可能是用户手动或者浏览器后退按钮），那么 URL 地址会重置到 from 路由对应的地址。
* next('/')   或者 next({ path: '/' }): 跳转到一个不同的地址。当前的导航被中断，然后进行一个新的导航。
*/
router.beforeEach((to, from, next) => {//建议cookie判断是否登录状态
  var _this = this ;
   console.log(vm)
  //to.meta.isAuth
  if ( vm.$cookies.get('token') ) {  // 判断该路由是否需要登录权限
        // next({
        //     path: '/login',
        //     query: {redirect: to.fullPath}  // 将跳转的路由path作为参数，登录成功后跳转到该路由
        // })
        //next()
        let token = vm.$cookies.get('token');
        	//重新刷新时间
    	vm.$cookies.set('token',token,'60s')
        if( to.path == '/login' ) { //
        	next({
		            path: '/readme'
		              // 将跳转的路由path作为参数，登录成功后跳转到该路由
		        })
        } else {
        	next()
        }
        
        
    }
    else {
    	if( to.path == '/login'){
    		next()
    	} else {
    		vm.$message({
	        	message:'登录状态已过期，请重新登录',
	        	type: 'warning'
	       	})
	       	setTimeout( ()=>{
		        next({
		            path: '/login'
		              // 将跳转的路由path作为参数，登录成功后跳转到该路由
		        })
	        },1000)
    	}
    }
})
