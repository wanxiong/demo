export let USER_NAME = 'USER_NAME'
export let USER_AGE = 'USER_AGE'
export let USER_SEX = 'USER_SEX'
export let NAME = 'NAME'
export let AGE = 'AGE'



