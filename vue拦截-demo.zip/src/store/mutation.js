

import * as types from './type'


let mutations = {
	[types.NAME](state, params) {
    	state.name = params.name
  	},
  	[types.AGE](state, params) {
  		state.age = params.age
  		params.callback && params.callback()
  	}

}
export default mutations;