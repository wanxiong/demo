<template>
  <div class="hello">
    <form class="signin-form form-horizontal" @submit.prevent="login" novalidate>
      <!-- 手机 -->
      <div class="form-group">
          <div>
              <label for="mobile">手机：</label>
              <input v-validate ="'required|mobile'" v-model="user.mobile" type="text" id="email" name="mobile">
          </div>
          <span v-show="errors.has('mobile')">{{ errors.first('mobile')}}</span>
      </div>
      </br>
      <!-- 名字 -->
      <div class="form-group">
          <div>
              <label for="nickname">名字：</label>
              <input v-validate ="'required|nickname'" v-model="user.nickname" type="text" id="myname" name="nickName">
          </div>
          <span v-show="errors.has('nickName')">{{ errors.first('nickName')}}</span>
      </div>
      </br>
      <!-- 提交按钮  -->
      <button class="btn btn-primary btn-lg btn-block" type="submit" id="signin_btn">提  交</button>
    </form>
  </div>
</template>

<script>

export default {
  name: 'validator',
  data () {
    return {
      user:{
        nickname:'',
        mobile:''
      }
    }
  },
  methods:{
    login (e) {
      this.$validator.validateAll().then(result => {
        //验证全部通过
        if(result){
           //提交请求
          console.log('可以发起请求提交表单了')
          console.log(this.user)
        }
      }).catch(() => {
        //提示错误
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
