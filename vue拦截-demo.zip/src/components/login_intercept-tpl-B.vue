<template>
	<div>intercept_B页面</div>
</template>