<template>
	<div>
		
		<p>存储成功哦</p>
		<br>
		<div>
			<button @click="goBack">点击返回上一页</button>
		</div>
	</div>
</template>
<script type="text/javascript">
	export default {
		data () {
			return {

			}
		},
		methods:{
			goBack() {
				window.history.back()
			}
		}
	}
</script>
<style type="text/css"></style>