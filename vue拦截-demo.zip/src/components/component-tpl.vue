<template>
	<div>
		<div>点击我加载下面的组件</div>
		</br>
		<div>============= 华丽的分割线 ======== </div>
		</br>
		<div>
			<demoOne @switch="demo"></demoOne>
		</div>
	</div>
</template>
<style type="text/css" lang="scss">
	
</style>
<script type="text/javascript">
	import demoOne from './storeTpl/demo-one.vue'
	export default {
		data() {
			return {

			}
		},
		methods:{
			demo(params) {
				alert('子组件传递了一个方法' + params)
			}
		},
		components:{
			demoOne
		}
	}
</script>