<template>
	<div>
		<div class="vue-lazyload">vue-lazyload案例</div></br></br></br>
		<div class="img-box">
			<p>纯img加载图片的格式</p>
			<div v-for="item in items" class="v-load-img">
				<img src="" class="logo" v-lazy="item">  
			</div>
		</div>
		<div class="bg_img-box">
			<p>纯背景加载图片的格式</p>
			<div v-for="item in items" class="v-load-img">
				<div class="bg-company" v-lazy:background-image="item"></div>    
			</div>
		</div>
	</div>
</template>
<script type="text/javascript">
	import  Vue from 'vue'
	import VueLazyload from 'vue-lazyload'  
	//等多参数请移步  https://github.com/hilongjw/vue-lazyload
	//配置图片懒加载
	Vue.use(VueLazyload, {
		//error: 'dist/error.png',//这个是请求失败后显示的图片
		loading: require('@/assets/default.png'),//这个是加载的loading过渡效果
		try: 2, // 这个是加载图片数量,
		// preload:1.3,//预加载的宽高
		//attempt:3,//尝试加载的次数
		//listenEvents: [ 'scroll' ]
	    // filter: { //滤图片的路径，默认{ }
	    //   webp ({ src }) {
	    //   	  console.log('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
	    //   	  console.log(src)
	    //       return src
	    //   }
	    // }
	})
	export default {
		data() {
			return {
				items:[
					'http://imgcno0.nos.netease.com/img/R1N2VWIyZFFQMzJQWWRHa0pQRlJQcmZXZGM4Q1RqMUpWbmdlb3d0YytBdHdxeVgzN21xREVnPT0.jpg'
					,
					'http://imgcno1.nos.netease.com/img/R1N2VWIyZFFQMzNhVGthQ1lsZ2VBY2s3Kzh0RXFoUTFqMXdUUzRTWUxhWHczYVkvelFRZHdBPT0.jpg'
					,
					'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzAweitPWUN6N0tJaXRVK1JtakV2OWVTNVN6V0pXZisrRHl0UnFQQXhPR0p3PT0.jpg'
					,
					'http://imgcno.nos.netease.com/img/R1N2VWIyZFFQMzE2MEhUclVQVitQVHptZ0ZDNUJhK0dranZ6Y2J2Z0YwTXZsNFpuTmdQQkdnPT0.jpg'
				]
			}
		}
	}
</script>
<style type="text/css">
	.vue-lazyload{
		font-size: 30px;
		text-align: center;

	}
	.v-load-img{
		width: 150px;
		height: 150px;
		float: left;
		margin-right: 20px;
	}
	.v-load-img img {
		display: inline-block;
		width: 100%;
		height: 100%;
	}
	.img-box,.bg_img-box{
		margin: 0 auto;
		text-align: center;
		overflow: hidden;
		width: 700px;
		padding-bottom: 10px;
		border-bottom: 1px solid red;
	}
	.bg_img-box .bg-company{
		width: 160px;
		height: 100px;
		background-size: cover;
		background-position: center;
	}
</style>
