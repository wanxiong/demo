<template>
	<transition name="fade">
		<div class="transition-div">
			你好 name
		</div>
	</transition>
</template>
<script type="text/javascript">
	import '@/assets/style/animate.css'
	export default {
		 data() {
		 	return {

		 	}
		}
	}
</script>
<style type="text/css" lang="scss">
	/*  1 ***** v-enter: 定义进入过渡的开始状态。在元素被插入时生效，在下一个帧移除。
		2 ***** v-enter-active: 定义进入过渡的结束状态。在元素被插入时生效，在 transition/animation 完成之后移除。
		3 ***** v-leave: 定义离开过渡的开始状态。在离开过渡被触发时生效，在下一个帧移除。
		4 ***** v-leave-active: 定义离开过渡的结束状态。在离开过渡被触发时生效，在 transition/animation 完成之后移除。 */
	.fade-enter-active, .fade-leave-active{
	    transition: all 0.3s
	}

	.fade-enter, .fade-leave-to{
		    transform: translate3d(100%, 0, 0)
	}
	.transition-div{
		height: 100%;
		width: 100%;
		background-color: #e9d8d8;	
		position: absolute;
		top: 0;
		left: 0;
		line-height: 500px;
		font-size: 50px;
	}
</style>