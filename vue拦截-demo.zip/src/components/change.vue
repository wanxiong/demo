<template>
	<div class="tabs">
		 <router-link tag="span" class="tab-item" to="/validator">
		 	表单验证的案例
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/proxyTable">
		 	本地跨域的案例
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/login_intercept">
		 	登录拦截登出功能的案例-路由拦截
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/login_intercept_api">
		 	API请求拦截设置
		 </router-link></br></br>
		 <router-link tag="span" class="tab-item" to="/vue-swiper">
		 	vue-awesome-swiper滑块组件案列
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/vue-lazyload">
		 	vue-lazyload图片懒加载案列
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/vue-waterfall">
		 	vue-waterfall瀑布流案列
		 </router-link></br></br>
		 <router-link tag="span" class="tab-item" to="/vue-infinite-scroll">
		 	vue-infinite-scroll无限滚动案列
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/vue-transition">
		 	vue-transition单个节点动画贼简单版本
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/vue-transition-animate">
		 	vue-transition嵌入animate.css
		 </router-link></br></br>
		 <router-link tag="span" class="tab-item" to="/vue-transition-group">
		 	vue-transition-group单个节点动画贼简单版本
		 </router-link>
	 	 <router-link tag="span" class="tab-item" to="/vuex">
		 		vuex简单小案例(数据不被清空案列)
	 	 </router-link>
	 	 <router-link tag="span" class="tab-item" to="/add-component">
		 		加载组件
	 	 </router-link>
	 	 <router-link tag="span" class="tab-item" to="/particles">
		 		粒子特效
	 	 </router-link>
	</div>
</template>
<script type="text/javascript">
	
</script>
<style type="text/css">
	.tabs span{
		margin: 0 30px;
		cursor: pointer;
		border-bottom: 1px solid red;
	}



	
</style>