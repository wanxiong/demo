<template>
	<div>
		 <router-link tag="span" class="tab-item" to="/login_intercept/login">
		 	需要登录新页面
		 </router-link>
		 </br>
		 <router-link tag="span" class="tab-item" to="/login_intercept/A">
		 	已成功登录页面A
		 </router-link>
		 </br>
		 <router-link tag="span" class="tab-item" to="/login_intercept/B">
		 	已成功登录页面B
		 </router-link>	

		 <!--  -->
		 <router-view class="box" ></router-view>
	</div>
</template>
<script type="text/javascript">
	export default {
		data() {
			return {
				isShow : false 
			}
		}
	}
</script>
<style type="text/css">
	span{
		border-bottom: 1px solid red;
	}
	.box{
		border: 1px solid #303030;
		height: 100px;
		padding-top: 50px;
	}
</style>

