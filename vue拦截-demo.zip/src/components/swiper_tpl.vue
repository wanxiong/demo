<template>
	<div>
		<div class="vue-swiper">vue-awesome-swiper案列</div></br>
		<swiper :options="swiperOption"  ref="mySwiper" class="swiper-area">  
            <!-- 这部分放你要渲染的那些内容 -->  
            <swiper-slide v-for="item in items">
            	<img v-bind:src="item">            
            </swiper-slide>  
            <!-- 这是轮播的小圆点 -->  
            <div class="swiper-pagination" slot="pagination"></div>  
        </swiper>
	</div>
</template>
<script type="text/javascript">
	import '@/assets/style/swiper.css'
	import { swiper, swiperSlide } from 'vue-awesome-swiper'
	// 本次下载的是 swiper4.0版本  具体API请移步http://www.swiper.com.cn/api/pagination/paginationType.html
	export default {
		data () {
			return {
				items:[
					'http://imgcno0.nos.netease.com/img/R1N2VWIyZFFQMzJQWWRHa0pQRlJQcmZXZGM4Q1RqMUpWbmdlb3d0YytBdHdxeVgzN21xREVnPT0.jpg'
					,
					'http://imgcno1.nos.netease.com/img/R1N2VWIyZFFQMzNhVGthQ1lsZ2VBY2s3Kzh0RXFoUTFqMXdUUzRTWUxhWHczYVkvelFRZHdBPT0.jpg'
					,
					'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzAweitPWUN6N0tJaXRVK1JtakV2OWVTNVN6V0pXZisrRHl0UnFQQXhPR0p3PT0.jpg'
					,
					'http://imgcno.nos.netease.com/img/R1N2VWIyZFFQMzE2MEhUclVQVitQVHptZ0ZDNUJhK0dranZ6Y2J2Z0YwTXZsNFpuTmdQQkdnPT0.jpg'
				],
				swiperOption: {  
	                //是一个组件自有属性，如果notNextTick设置为true，组件则不会通过NextTick来实例化swiper，也就意味着你可以在第一时间获取到swiper对象，假如你需要刚加载遍使用获取swiper对象来做什么事，那么这个属性一定要是true  
	                notNextTick: true,  
	                pagination: {
					    el: '.swiper-pagination',
					},
	                slidesPerView: 'auto',  
	                centeredSlides: true,  
	                paginationClickable: true,  
	                spaceBetween: 0,
	                on:{
	                	slideChange: swiper => {  
                        	//slide切换开始时的回调
	                        //alert(this.swiper.activeIndex); 
	                    }  
	                }
                    
	            }  
			}
		},
		methods:{

		},
		computed:{
			swiper() {
				return this.$refs.mySwiper.swiper;  
			}
		},
		components:{
			swiper,
			swiperSlide,
		},
		mounted () {  
            //这边就可以使用swiper这个对象去使用swiper官网中的那些方法  
            this.swiper.slideTo(2, 0, false);  
        }  

	}
</script>
<style type="text/css">
	.vue-swiper{
		font-size: 30px;
		text-align: center;
	}
	.swiper-area{
		width: 500px;
		height: 300px;
		margin: 20px auto 0;
	}
	.swiper-area img {
		display: block;
		width: 100%;
		height: 100%;
	}
</style>