<template>
	<div class="demo-one">
		我是加载进来的demo哦
		<div @click="goParent">点我传递给父组件</div>
	</div>
</template>
<script type="text/javascript">
	export default {
		data() {
			return {

			}
		},
		methods:{
			goParent() {
				console.log(111)
				this.$emit('switch','xionga')
			}
		}
	}
</script>
<style type="text/css" lang="scss">
	.demo-one{
		color: red;
	}
</style>