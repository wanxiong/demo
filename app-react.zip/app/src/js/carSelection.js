import app from './utils/app'
import Container,{config} from './containers/carSelection'
app.init(Container,config);



