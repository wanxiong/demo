import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as chooseAirportAction from '../actions/chooseAirport'
import Loading from '../components/loading'
import {localStorage,sessionStorage} from '../utils/storage'

export const config={title:'城市选择',isFirst:false};

function matchStateToProps(state) {
    return {
        state: state.cityLoad
    }
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({
        ...chooseAirportAction
    }, dispatch)
}

@connect(matchStateToProps, matchDispatchToProps)
class chooseAirport extends React.Component{

    componentDidMount(){
        this.props.cityLoad();
    }

    linkGo = (value) =>{

        let domNode = this.refs['city'+value];
        let scrollTop = domNode.offsetTop-200;
        window.scrollTo('0',scrollTop);
    }

    selectCity=(cityName)=>{
        return ()=>{
            localStorage.setItem('cityName',cityName);


            window.location.href = window.pagePath.address;
            // location.href='address.html';
        }
    }

    keywordOnchange=(e)=>{

        let keyword=e.target.value;
        this.props.updateState({keyword})
    }

    mapAddress=(address,keyword)=>{
        if(!keyword)return true;
        let isMap=false;
        ['Acronym','AirPortCode','AirPortName','CityCode','CityName','Pinyin'].some((key)=>{
            if(address[key].toLowerCase().indexOf(keyword.toLowerCase())>-1)
            {
                isMap=true;
                return true;
            }
        })
        return isMap;
    }

    emptyFill=(e)=>{

        this.props.updateState({keyword:''});
    }

    render() {

        let letters = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];//遍历字母
        let wrapLetters =[];
        let allCityArray=[];
        let {state:{keyword='',Data}={}}=this.props;

        if(Data){
            let address={};
            letters.forEach((value,item) => {
                let count=0;
                let itemCity = [];
                Data.forEach((v,i) => {
                    if(v.Acronym.slice(0,1) === value&&!address[v.CityName]&& this.mapAddress(v,keyword)){
                        address[v.CityName]=true;
                        count++;
                        itemCity.push ((
                            <p onClick={this.selectCity(v.CityName)}>
                                <b>{v.CityName}</b>
                            </p>
                        ))
                    }
                });
                if(count==0)return;
                let clickFn=()=>{
                     this.linkGo(value);
                }
                wrapLetters.push((<li onClick={clickFn}>{value}</li>))
                allCityArray.push((
                    <div class="cityList" ref={'city'+value}>
                        <span>{value}</span>
                        <div class="cityName">
                            {itemCity}
                        </div>
                    </div>
                ))
            });

        }

        let inputFill=keyword?( <i onClick={this.emptyFill}></i>):null;

        return Data?(
        <div>
            <div>
                <div class="container">
                    <div class="address">
                        <div class="addChoose">
                            <input type="text" placeholder="北京／beijing／bj／中国" class="inputAddress" value={keyword} onChange={this.keywordOnchange}/>
                            {inputFill}
                        </div>
                    </div>

                    <div class="chooseCity">
                        {allCityArray}
                    </div>
                    <div class="letter">
                        <ul>
                            {wrapLetters}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        ):null;
    }
}

export default chooseAirport

