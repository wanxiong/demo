import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as orderListAction from '../actions/orderList'
import { getOrderStatus } from '../utils/utils-fn'
import  {sessionStorage} from "../utils/storage"

export const config={title:'订单列表',isFirst:true};



function matchStateToProps(state) {
  return {
    state:state.orderListReducer
  }
}

function matchDispatchToProps(dispatch) {
  return bindActionCreators({
    ...orderListAction
  },dispatch);
}


@connect(matchStateToProps,matchDispatchToProps)

class orderList extends React.Component{

      constructor(...props) {
        super(...props);
        this.curDate=+ new Date();
      }

      componentDidMount(){
         this.props.orderInitStatus();

         let {state} =this.props;

            //一个月内
             if(!state.status || state.status=='preActiveIndex'){

                this.props.orderLoad({
                    'StartCreateTime':Math.floor((this.curDate*100-30*24*3600*1000*100)/100),
                    'EndCreateTime':this.curDate,
                    'PageIndex':1,
                    'PageSize':1000,
                    'OrderStatus':-1
                });
                
             }
             //一个月前
             else if(state.status=='nextActiveIndex'){
              this.props.orderLoad({
                    'StartCreateTime':'', 
                    'EndCreateTime':Math.floor((this.curDate*100-30*24*3600*1000*100)/100), 
                    'PageIndex':1,
                    'PageSize':1000,
                    'OrderStatus':-1
                  })
             }
      }

      //去支付
      _goPay=(orderID)=>{
        this.props.orderGoPay({OrderID: orderID,PayIndex:1});
      }
     


    
      //tab切换
      _changeTitle=(element)=>{

         let{state}=this.props;
         let curDate= +new Date();
         if(element.target.getAttribute("data-status") =='preActiveIndex'){
             if(state.status=='preActiveIndex') return false;
             else{
               this.props.orderChangeStatus('preActiveIndex');
             }
          }  
         else {
               if(state.status=='nextActiveIndex') return false;
               else{
                  this.props.orderChangeStatus('nextActiveIndex');
                  setTimeout(()=>{
                    this.props.orderLoad({
                       StartCreateTime:'', 
                       EndCreateTime:Math.floor((curDate*100-30*24*3600*1000*100)/100), 
                       PageIndex:state.nextOrderObj.PageIndex,
                       PageSize:state.nextOrderObj.PageSize,
                       OrderStatus:-1
                 })},0);
               }
         }
      }


      //链接到详情
      _goDetail=(orderID)=>{
        location.href=window.pagePath.orderDetail+"?OrderID=" + orderID;
      }

     render() {
            let {state}=this.props;
            let preorderList=[];
            let nextorderList=[];
            if(!state.status ||state.status=='preActiveIndex'){
                if(state.preOrderObj.preOrderList && state.preOrderObj.preOrderList.length>0){
                    preorderList=state.preOrderObj.preOrderList.map((item,index)=>{
                      return(
                         <div class="transMess" onClick={()=>{this._goDetail(item.OrderID)}}>
                             <div class="status">接送机<span>{getOrderStatus(item.OrderStatus)}</span></div>
                             <div class="transBox">{item.DepartAddress && item.TransferType==1 ? item.DepartAddress+'接机':(item.TransferType==2 ? item.DepartAddress+'送机':'') }
                             <span>{item.DepartTime}</span>
                             </div>
                             <div class='transBox'>订单金额<b>¥{item.OrderAmount}</b>
                             <a href="javascript:void(0)"  className={item.NextState==1 ? "orderStatus" :'orderStatus hideCss'} onClick={(e)=>{ e.stopPropagation();this._goPay(item.OrderID)}}>去支付</a>
                             </div>
                         </div>
                        );
                     });
                    }
                 }
              else if(state.status=='nextActiveIndex'){
                  if(state.nextOrderObj.nextOrderList && state.nextOrderObj.nextOrderList.length>0){
                      nextorderList=state.nextOrderObj.nextOrderList.map((item,index)=>{
                      return(
                         <div class="transMess" onClick={()=>{this._goDetail(item.OrderID)}}>
                             <div class="status">接送机<span>{getOrderStatus(item.OrderStatus)}</span></div>
                             <div class="transBox">{item.TransferType==1 ? item.DepartAddress+'接机':(item.TransferType==2 ? item.DepartAddress+'送机':'') }
                             <span>{item.DepartTime}</span>
                             </div>
                             <div class="transBox">订单金额<b>¥{item.OrderAmount}</b>
                             </div>
                         </div>
                        );
                     });
                    }
              }
      return (
        <div>
          <div>
            <div>
              <div class="orderMess">
                <div class="menu">
                  <ul onClick={this._changeTitle}>
                    <li class={this.props.state.status =='preActiveIndex'  ? 'active':''} data-status='preActiveIndex'>一个月内</li>
                    <li class={this.props.state.status =='nextActiveIndex' ? 'active':''} data-status='nextActiveIndex'>一个月前</li>
                  </ul>
                </div>
                        { this.props.state.status=='preActiveIndex'? preorderList:nextorderList}
              </div>
            </div>
           </div>
        </div>
        )
    }
  }

  export default orderList

