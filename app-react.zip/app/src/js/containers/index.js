import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as homeAction from '../actions/home'
import Picker  from "Picker";
import Time  from "Time";
export const config={title:'接送机',isFirst:true};


function matchStateToProps(state) {
  return {
    state: state.homeReducer
  }
}

function matchDispatchToProps(dispatch){
  return bindActionCreators({
    ...homeAction
  }, dispatch)
}  

@connect(matchStateToProps, matchDispatchToProps)
 class Home extends React.Component{
 	constructor(...args) { //constructor是构造器，在实例化对象时调用
 		super(...args); //super调用了父类的constructor创造了父类的实例对象this，然后用子类的构造函数进行修改。
 		this.state={
 			picker:null
 		}
 	}

 	componentDidMount(){  //组件渲染之后调用，只调用一次。
    	this.props.initState();
		this.createPicker();
  	}

  	createPicker=()=>{
  		var date1 = new Date();
		//需求调整:当前弹出的时间需要往后延长分钟
		date1.setMinutes(date1.getMinutes()+120);
		var today={
			year:date1.getFullYear(),
			month:date1.getMonth(),
			date:date1.getDate(),
			hour:date1.getHours(),
			min:date1.getMinutes()
		}
		var date2 = new Date(date1);
        date2.setDate(date1.getDate()+30);
        var nextDay = {
        	year:date2.getFullYear(),
			month:date2.getMonth(),
			date:date2.getDate()
        }
        
		var time = new Time({
			startTime:new Date(today.year,today.month,today.date,today.hour,today.min),
			endTime:new Date(nextDay.year,nextDay.month,nextDay.date,12,55)
		});
		time.removeDate("now");
		var timeArr = time.getArr();
    	var date= [];  //天
		var hour = []; //时
		var min = [];  //分
		timeArr.forEach(function(item){
    		date.push({
    			text:item.month+"月"+item.date+"日  "+item.utc ,
    			value:{
    				year:item.year,
    				month:item.month,
    				date:item.date
    			}
			})
    	})
		var today = timeArr[0];
    	today.hours.forEach(function(item){
    		hour.push({
    			text:item.hour+"时" ,
    			value:item.hour	
    		})
    	})
    	var toHour = today.hours[0];
    	toHour.min.forEach(function(item){
    		min.push({
    			text:item+"分" ,
    			value:item
    		})
    	})
		//通过天数查出当天小时分钟数
    	function changeHourMin(index){
    		hour = [];
    		min =[];
    		var day = timeArr[index];
	    	day.hours.forEach(function(item){
				hour.push({
	    			text:item.hour+"时" ,
	    			value:item.hour	
	    		})
	    	})
	    	var firstHour = day.hours[0];
	    	firstHour.min.forEach(function(item){
    			min.push({
	    			text:item+"分" ,
	    			value:item
	    		})
    		})
    	}
    	var selectStatus = [0,0,0];

    	//通过天数和小时数查出分钟数
    	function changeMin(index){
    		min = [];
    		var dayStatus = selectStatus[0];
    		var day = timeArr[dayStatus];
    		var hour = day.hours[index];
    		hour.min.forEach(function(item){
    			min.push({
    				text:item+"分",
    				value:item
    			})
    		})
    	}


    	this.state.picker = new Picker({
			data: [date,hour,min],
			selectedIndex: [0, 0, 0],
			title: '日期选择'
		});
    	var picker = this.state.picker;
		this.state.picker.on('picker.change', function (index, selectedIndex){
			if (index === 0){
				changeHourMin(selectedIndex);
				selectStatus[0] = selectedIndex;
				picker.refillColumn(1,hour);
				picker.refillColumn(2,min);
				picker.scrollColumn(1, 0)
				picker.scrollColumn(2, 0)
			} else if (index === 1) {
				//changeHourMin(selectedIndex);
				changeMin(selectedIndex);
				picker.refillColumn(2,min);
				picker.scrollColumn(2, 0)
			}
		})
		this.state.picker.on("picker.cancel",function(){
			console.log(1);
		})
		var self = this;
		this.state.picker.on('picker.select', function (selectedVal, selectedIndex) {
			var date = new Date(selectedVal[0].year,selectedVal[0].month-1,selectedVal[0].date,selectedVal[1],selectedVal[2]);
			self.props.update({DepartureTime:date});
			
		})
  	}
  
  	onChangeFlightID=(ev)=>{
  		this.props.onChangeFlightID(ev.target.value)
  	}
  	onChangeTitle=(ev)=>{
  		if(ev.target.getAttribute("data-status") =="sj"){
  			this.props.onChangeStatus("sj")
  		}else{
  			this.props.onChangeStatus("jj")
  		};
  	}
  	selectDepartureTime=()=>{
  		this.state.picker.show();
  	}
  	onSubmitChange=()=>{
  		this.props.onSubmitChange();
  	}
	render() {

		
		let {state:{disMinute='none',DepartureTime}={}}=this.props;
		

        if(DepartureTime){
        	var date3 = new Date(DepartureTime);

			DepartureTime = date3.pattern('yyyy-MM-dd E HH:mm');

        }
		return (	
	<div>
		<div>		
		    <div class="banner">
		        <img src={`${window.cdnBasePath}/images/banner.jpg`}/>
		    </div>
		    <div class="main">
		        <div class="menu">
					<ul onClick={this.onChangeTitle} >
						<li class={this.props.state.status == "jj"?"active":""} data-status="jj">接机</li>
						<li class={this.props.state.status == "sj"?"active":""}  data-status="sj">送机</li>
					</ul>
				</div>
		        <div  class={this.props.state.status == "jj"?"mess active animated bounceInLeft":"mess animated bounceInLeft"} >
					<div class="messIn">
						<div class="messBox airLine">
							<input type="text" placeholder="请输入您的航班号" value={this.props.state.flightID } onChange={this.onChangeFlightID} />
						</div>
						<div class="messBox" onClick={this.selectDepartureTime}>
							<input type="text" readOnly='true' value={DepartureTime}  placeholder="请选择您的用车时间"/>
						</div>
						<div class="messBox">
							<a href={window.pagePath.chooseCity}>
								<input type="text" readOnly='true' placeholder="您从哪里出发" value={this.props.state.FromName}/>
							</a>
						</div>
						<div class="messBox">
							<a href={window.pagePath.address}>
								<input type="text" readOnly='true' placeholder="您要去哪里" value={this.props.state.ToName}/>
							</a>
						</div>
					</div>
		        </div>

		        <div  class={this.props.state.status == "sj"?"mess active animated bounceInRight":"mess animated bounceInRight"}>
					<div class="messIn">
						<div class="messBox airLine hideCss">
							<input type="text" placeholder="请输入您的航班号" value={this.props.state.flightID } onChange={this.onChangeFlightID} />
						</div>
						<div class="messBox" onClick={this.selectDepartureTime}>
							<input type="text" readOnly='true' placeholder="请选择您的用车时间" value={DepartureTime}/>
						</div>

						<div class="messBox">
							<a href={window.pagePath.address}>
								<input type="text" readOnly='true' placeholder="您从哪里出发" value={this.props.state.ToName}/>
							</a>
						</div>
						 <div class="messBox">
							<a href={window.pagePath.chooseCity}>
								<input type="text" readOnly='true' placeholder="您要去哪里"  value={this.props.state.FromName}/>
							</a>
						</div>
					</div>
				</div>
		    </div>
		    <div class="searchIndex" onClick={this.onSubmitChange}>
		        <a href="javascript:void(0)" class="searchBtn">搜索</a>
		    </div>
	    </div>
    </div>
			)
	}
}

export default Home

