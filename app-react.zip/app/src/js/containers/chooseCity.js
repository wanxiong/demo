import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as chooseCityAction from '../actions/chooseCity'

export const config={title:'机场选择',isFirst:false};

function matchStateToProps(state) {
    return {
        state: state.chooseCityReducer
    }
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({
        ...chooseCityAction
    }, dispatch)
}

@connect(matchStateToProps, matchDispatchToProps)

class chooseCity extends React.Component{

    componentWillMount(){
        this.props.cityLoad();
    }

    linkGo = (value) =>{
        let domNode = this.refs['city'+value];
        let scrollTop = domNode.offsetTop-200;
        window.scrollTo('0',scrollTop);
    }

    getLou = (v,i) =>{
        let params = {
            city: v,
            sug: i
        } || {}
        sessionStorage.setItem("cityName",v);
        this.props.forCustom(params);
    }
    setCity=(i)=>{
        console.log(i);
       this.props.setCity(i);
    }

    keywordOnchange=(e)=>{
        let keyword=e.target.value;
        this.props.updateState({keyword})
    }

    mapAddress=(address,keyword)=>{
        if(!keyword)return true;
        let isMap=false;
        ['Acronym','AirPortCode','AirPortName','CityCode','CityName','Pinyin'].some((key)=>{
            if(address[key].toLowerCase().indexOf(keyword.toLowerCase())>-1)
            {
                isMap=true;
                return true;
            }
        })
        return isMap;
    }

    emptyFill=(e)=>{
        this.props.updateState({keyword:''});
    }

    render() {
        let letters = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];//遍历字母
        
        let wrapLetters=[];
        let state = this.props.state||{};
        let keyword=state.keyword||'';
        let allCityArray=[];
        
        if(state.Data){
            letters.forEach((value,item) => {
                let count=0;
                let itemCity = [];
                state.Data.forEach((v,i) => {
                    if(v.Acronym.slice(0,1) === value&& this.mapAddress(v,keyword)){
                        let postAddress=()=>{
                            this.getLou(v.CityName,v.AirPortName+v.RoundTerminal);
                            this.setCity(v.CityName);
                        }
                        count++;
                        itemCity.push((
                            <p onClick={postAddress}>
                                <b>{v.CityName}</b>
                                <span>{v.AirPortName+v.RoundTerminal}</span>
                            </p>
                        ))
                    }
                });

                if(count==0)return;
                let clickFn=()=>{
                     this.linkGo(value);
                }

                wrapLetters.push((<li onClick={clickFn}>{value}</li>))

                allCityArray.push((
                    <div class="cityList" ref={'city'+value}>
                        <span>{value}</span>
                        <div class="cityName">
                            {itemCity}
                        </div>
                    </div>
                ))
            });

        }

        let inputFill=keyword?( <i onClick={this.emptyFill}></i>):null;

        return state.Data?(
        <div>
            <div>
                <div class="container">
                    <div class="address">
                        <div class="addChoose">
                            <input type="text" placeholder="北京／bei`jing／bj／中国" class="inputAddress" value={keyword} onChange={this.keywordOnchange} />
                            {inputFill}
                        </div>
                    </div>
                    
                    <div class="chooseCity">
                        {allCityArray}
                    </div>

                    <div class="letter">
                        <ul>
                            {wrapLetters}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        ):null;
    }
}

export default chooseCity

