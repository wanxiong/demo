import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as orderFillAction from '../actions/orderFill'
import app from '../utils/app'
import {sessionStorage} from '../utils/storage'
import {getCarType,getCarDes,message,getCarBox} from '../utils/utils-fn'
import SelectCoupon from '../components/selectCoupon'

export const config={title:'信息填写',isFirst:false};

function matchStateToProps(state) {
  return {
    state: state.orderFillReducer
  }
}

function matchDispatchToProps(dispatch){
  return bindActionCreators({
    ...orderFillAction
  }, dispatch)
}  

@connect(matchStateToProps, matchDispatchToProps)
class orderFill extends React.Component{
    constructor(...props) {
        super(...props);
        this.productKey=app.parse_url(location.href)['PreOrderkey'];
        // this.productKey="CAR_7179e41f-4ae5-42f7-a674-f962884ab7f8";
    }

    componentDidMount(){
        let {productKey}=sessionStorage.getJson('orderState')||{};
        if(productKey==this.productKey)
            this.props.initData();
        else
            this.props.loadData({"PreOrderkey":this.productKey});
    }

    saveState=()=>{
        sessionStorage.setJson('orderState',{productKey:this.productKey,state:this.props.state})
    }

    bindChange=(type)=>{
        return (e)=>{
            let key=e.target.type=='checkbox'?'checked':'value';
            this.props.updateData({[type]:e.target[key]})
        }
    }

    go=()=>{
        this.saveState();
        location.href=window.pagePath.bookMess;
    }

    submit=()=>{
        let {state}=this.props;
        let msg=this.verify(state);
        if(msg){
            message(msg);
        }else{
            this.saveState();
            let LotteryCode=this.getCoupon()['LotteryCode'];
            this.props.createOrder({
               PreOrderkey: this.productKey,
               ChannelCode: app.isInApp()?'APP':'H5',
               OrderUserName:state.name,
               OrderUserPhone:state.phone,
               isForOtherBooking:!!state.hasPassenger,
               PassengerName:state.hasPassenger?state.oName:state.name,
               PassengerPhone: state.hasPassenger?state.oPhone:state.phone,
               CouponCodeList:LotteryCode?[LotteryCode]:[],
               UsePointCount:state.hasPoint?state.point:0,
               IsNeedInvoice:!!state.hasInvoice,
               InvoiceModel:{
                  InvoiceTitle:state.invoiceTitle,
                  ReceiveAddress:state.invoiceAddress,
                  ReceiveName:state.name,
                  ReceivePhone:state.phone
               }
            });
        }
            
    }

    onOk=(couponIndex)=>{
        let {point='',CouponList=[],PointModel:{rate=0.025}={}}=this.props.state;
        let curCoupon=CouponList[couponIndex-1]?CouponList[couponIndex-1]['DiscountAmount']:0;
        let Point=this.getMaxPoint(couponIndex);

        point=point>Point?Point:point;
        
        this.props.updateData({'display':'none',couponIndex,point});
    }

    onCancle=()=>{
        this.props.updateData({'display':'none'});
    }

    selectInput=()=>{
        let {CouponList=[]}=this.props.state;
        if(CouponList.length==0)return;
        this.props.updateData({'display':'block'});
    }

    verify(state) {
        console.log(state);
        var msg='';
        if(!state.name)
            msg='订车人姓名不能为空！';
        else if(!this.verifyName(state.name))
            msg='订车人姓名格式错误！';
        else if(!state.phone){
            msg='订车人手机号码不能为空！'
        }else if(!this.verifyPhone(state.phone)){
            msg='订车人手机号码格式错误！'
        }
        else if(state.hasPassenger&&!state.oName)
            msg='乘车人姓名不能为空！'
        else if(state.hasPassenger&&! this.verifyName(state.oName))
            msg='乘车人姓名格式错误！'
        else if(state.hasPassenger&&!state.oPhone){
            msg='乘车人手机号码不能为空！'
        }else if(state.hasPassenger&&!this.verifyPhone(state.oPhone)){
            msg='乘车人手机号码格式错误！'
        }else if(state.hasInvoice&&!state.invoiceTitle)
            msg='发票抬头不能为空！'
        else if(state.hasInvoice&&!state.invoiceAddress)
            msg='发票寄送地址不能为空！'
        else if(!state.hasAgree)
            msg='请阅读并同意预定须知！';
        return msg;
    }

    verifyName(value){
        if(value==null||value=='')return true;
        if (value.match(/^([\u4e00-\u9fa5]){2,9}$/)||value.match(/^([a-zA-Z]{2,20})$/)||value.match(/^([\d]{12})$/))
            return true;
        else 
            return false;   
    }

    verifyPhone(phone){
        var reg=/^[\d]{11}$/;
        return reg.test(phone);
    }

    pointChange=(e)=>{
        let {point=''}=this.props.state;
        let curPoint=e?e.target.value:point; 
        if(curPoint!==''&&curPoint!=null&&!/^[0-9]*$/.test(curPoint))return;                
        if(curPoint!==''&&curPoint!=null){
            let Point=this.getMaxPoint();
            curPoint=curPoint>Point?Point:curPoint;
        }
        if(curPoint!==point){
            this.props.updateData({point:curPoint});
        }
    }

    getMaxPoint(index){
        let estimate_price=this.getEstimatePrice(); 
        let {point=0,PointModel={}}=this.props.state;
        let {Point=0,rate=0.025}=PointModel;
        let price=this.getPriceExCoupon(index);
        if(Math.floor(rate*Point*100)/100<=price){
            return Point;
        }else
            return Math.ceil(price/rate*100)/100;
    }

    getPriceExCoupon=(index)=>{
        let  estimate_price=this.getEstimatePrice(); 
        let priceCoupon=this.getCouponPrice(index);
        let price= estimate_price-priceCoupon ;
        return price>0?price:0;
    }

    showPriceDetail=()=>{
        this.props.updateData({showPriceDetail:true});
    }

    hidePriceDetail=()=>{
        this.props.updateData({showPriceDetail:false});
    }

    hide(isShow){
        return isShow?'':'hideCss';
    }

    getCoupon(index){
        let {couponIndex=0,CouponList=[]}=this.props.state;
        if(index!=undefined)couponIndex=index;
        return CouponList[couponIndex-1]||{};
    }

    getCouponPrice(index){
        let Coupon=this.getCoupon(index)
        return Coupon.DiscountAmount||0;
    }

    disInvoiceDes(){
        message('发票信息无法修改，行程三个月内递送');
    }

    getEstimatePrice(){
        let {estimate_price=0}=this.props.state;
        return estimate_price/100;
    }

    render() {
        let {FromName='',ToName='',Traffic_no='',hasInvoice=false,hasPassenger=false,hasPoint=false,ride_type,seats=0
            ,phone='',name='',oPhone='',oName='',point='',PointModel={},CouponList=[],TransferType=1,couponIndex=0
            ,invoiceTitle='',invoiceAddress='',hasAgree=false,display='none',showPriceDetail=false}=this.props.state;     
        let  estimate_price=this.getEstimatePrice(); 
        let {Point=0,rate=0.025}=PointModel;
        let carType=getCarType(ride_type);
        let carDes=getCarDes(ride_type);
        let pricePoint=Math.floor(rate*point*100)/100;
        pricePoint=hasPoint?pricePoint:0;
        let priceCoupon=this.getCouponPrice();
        let priceCouponTxt= CouponList&&CouponList.length>0?(this.getCoupon()['Title']||'未使用优惠券'):'暂无可用优惠券';
        let priceTotal=Math.ceil((estimate_price-priceCoupon-pricePoint)*100)/100;
        let transferTypeText=TransferType==1?'接机':'送机';
        let options={
            display,
            onOk:this.onOk,
            onCancle:this.onCancle,
            items:['--'].concat(CouponList),
            couponIndex
        }
        let selectCouponNode=options.items.length>1?(<SelectCoupon {...options}></SelectCoupon>):null;
        let priceDetail=showPriceDetail?(
                    <div class='cover' onClick={this.hidePriceDetail}>
                        <div class="priceDetail">
                            <h5>费用明细</h5>
                            <div class="priceBox">
                                <div class="firstBox">名称</div>
                                <div>价格</div>
                            </div>
                            <div class="priceBox">
                                <div class="firstBox">{transferTypeText}</div>
                                <div>¥{estimate_price}</div>
                            </div>
                            <div class={`priceBox ${this.hide(priceCoupon>0)}`}>
                                <div class="firstBox">优惠券</div>
                                <div>¥-{priceCoupon}</div>
                            </div>
                            <div class={`priceBox ${this.hide(pricePoint>0 && hasPoint)}`}>
                                <div class="firstBox">积分</div>
                                <div>¥-{pricePoint}</div>
                            </div>
                            <div class="priceBox priceAll">
                                <div class="firstBox">总价</div>
                                <div>¥{priceTotal}</div>
                            </div>
                        </div>
                    </div>
        ):null;
        return (
        <div>
            <div>
                <div class="container">
                    <div class={carType?"orderTop":"orderTop hideCss"}>
                        <div class="orderNum">
                            <div class="orderLeft">
                                <p><b>{carType}</b>{carDes}</p>
                            </div>
                            <div class="orderRight">
                                <span class="people">x<i>{seats}</i></span>
                                <span class="luggage">x<i>{getCarBox(ride_type)}</i></span>
                            </div>
                        </div>
                        <div class="startEnd">
                            <p>{FromName}</p>
                            <p class="endAddree">{ToName}</p>
                        </div>
                        <div class="timeGet">
                            <h5 className={TransferType==1 ? '':'hideCss'} >{ Traffic_no }</h5>
                            <p>如果航班晚点，司机将免费等待<br />本次服务由滴滴公司提供</p>
                        </div>
                        <div class="bookNotes" onClick={this.go}>预订须知</div>
                    </div>
                    <div class="information">
                        <div class="infoBox infoName">
                            <label>订车人</label>
                            <input type="text" placeholder="请填写订车人姓名" onChange={this.bindChange('name')} value={name} />
                        </div>
                        <div class="infoBox">
                            <label>手机号码</label>
                            <input type="text" pattern="[0-9]*" placeholder="接受短信通知" onChange={this.bindChange('phone')} value={phone} />
                        </div>
                    </div>
                    <div class="forCar">
                        <div class="carTop">
                            <p>帮人订车</p>
                            <div class="onoffswitch buleSwitch">
                                <input type="checkbox" name="agree" class="onoffswitch-checkbox" id="myonoffswitch" onChange={this.bindChange('hasPassenger')} checked={hasPassenger} />
                                <label class="onoffswitch-label" for="myonoffswitch">
                                    <div class="onoffswitch-inner">
                                        <div class="onoffswitch-active"></div>
                                        <div class="onoffswitch-inactive"></div>
                                    </div>
                                    <div class="onoffswitch-switch"></div>
                                </label>
                            </div>
                        </div>
                        <div class={`infoBox infoName ${this.hide(hasPassenger)}`}>
                            <label>乘车人</label>
                            <input type="text" placeholder="请填写订车人姓名" onChange={this.bindChange('oName')} value={oName} />
                        </div>
                        <div class={`infoBox ${this.hide(hasPassenger)}`}>
                            <label>手机号码</label>
                            <input type="text" pattern="[0-9]*" placeholder="接受短信通知" onChange={this.bindChange('oPhone')} value={oPhone} />
                        </div>
                    </div>
                    <div class="forCar">
                        <div class="carTop" onClick={this.selectInput}>
                            <p>优惠券</p>
                            <div class="coupop">{priceCouponTxt}</div>
                        </div>
                    </div>
                    <div class="forCar invoiceBox">
                        <div class="carTop">
                            <p>发票<i onClick={this.disInvoiceDes}></i></p>
                            <div class="onoffswitch buleSwitch">
                                <input type="checkbox" name="invoice" class="onoffswitch-checkbox" id="invoice" onChange={this.bindChange('hasInvoice')} checked={hasInvoice} />
                                <label class="onoffswitch-label" for="invoice">
                                    <div class="onoffswitch-inner">
                                        <div class="onoffswitch-active"></div>
                                        <div class="onoffswitch-inactive"></div>
                                    </div>
                                    <div class="onoffswitch-switch"></div>
                                </label>
                            </div>
                        </div>
                        <div class={`infoBox infoName ${this.hide(hasInvoice)}`}>
                            <label>发票抬头</label>
                            <input type="text" placeholder="请填写发票抬头" onChange={this.bindChange('invoiceTitle')} value={invoiceTitle} />
                        </div>
                        <div class={`infoBox ${this.hide(hasInvoice)}`}>
                            <label>寄送地址</label>
                            <input type="text" placeholder="请填写寄送地址" onChange={this.bindChange('invoiceAddress')} value={invoiceAddress}/>
                        </div>
                    </div>
                    <div class="forCar invoiceBox integralBox">
                        <div class="carTop">
                            <p>万里行积分</p>
                            <span>共{Point}分可用</span>
                            <div class="onoffswitch buleSwitch">
                                <input type="checkbox" name="point" class="onoffswitch-checkbox" id="integralNum" onChange={this.bindChange('hasPoint')} checked={hasPoint}/>
                                <label class="onoffswitch-label" for="integralNum">
                                    <div class="onoffswitch-inner">
                                        <div class="onoffswitch-active"></div>
                                        <div class="onoffswitch-inactive"></div>
                                    </div>
                                    <div class="onoffswitch-switch"></div>
                                </label>
                            </div>
                        </div>
                        <div class={`infoBox infoName ${this.hide(hasPoint)}`}>
                            <label>使用</label>
                            <input type="text" pattern="[0-9]*" value={point} onChange={this.pointChange} />
                            <span>积分 抵用<b><em>¥</em>{pricePoint}</b></span>
                        </div>
                    </div>
                    <div class="read">
                        <input type="checkbox" class={hasAgree?'choose':''} onChange={this.bindChange('hasAgree')} checked={hasAgree} id='agree' />
                        <label for='agree'>
                            我已阅读并同意<span  onClick={this.go}>《预订须知》</span>
                        </label>
                    </div>
                    <div class="toPay">
                        <div class="payLeft">
                            <p>总价<span><i>¥</i>{priceTotal}</span><b onClick={this.showPriceDetail}>明细</b></p>
                        </div>
                        <div class="payRight" onClick={this.submit}>去支付</div>
                    </div>
                    {priceDetail}
                </div>
            </div>
            {selectCouponNode}
            
        </div>
        )
    }
}

export default orderFill

