import Loading from '../components/loading'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as carSelectionAction from '../actions/carSelection'
import { getCarType,getCarDes} from '../utils/utils-fn'
import app from '../utils/app'


export const config={title:'车型列表',isFirst:false};

function matchStateToProps(state) {
  return {
    state: state.carSelectionReducer
  }
}

function matchDispatchToProps(dispatch){
  return bindActionCreators({
    ...carSelectionAction
  }, dispatch)
}

@connect(matchStateToProps, matchDispatchToProps)


class carSelection extends React.Component{
  constructor(...props) {
    super(...props);
    this.params=app.parse_url(location.href);
  }
  componentDidMount(){
    let {Traffic_date,Traffic_no,...option}=this.params;
    this.props.carLoad(option);
  }

  booking=(_reqBookingData)=>{
      return ()=>{
        let {image_url,...option}=_reqBookingData;
        this.props.carBooking({
          ...this.params,
          ...option
        });
      }      
  }

  render() {
    let carList=(this.props.state||{}).Data||[];
    let nodeList=carList.map((item,index)=>{
      return (
          <div class="carSelect">
             <div class="selectLeft">
                <div class="carBox"><img src={item.image_url} /></div>
                <p>{getCarType(item.ride_type)}</p>
             </div>
             <div class="selectRight">
                <p>最大可乘{item.seats}人(含儿童)</p>
                <p>{getCarDes(item.ride_type)}</p>
                <div class="price"><span>¥</span><b>{item.estimate_price/100}</b>/辆</div>
                <a href="javascript:void(0)"  onClick={this.booking(item)} class="booking">预定</a>
             </div>
          </div>
       );
   });
  
    return (
      <div>
          <div>
              <div>
                  <div class="container">
                    {nodeList}
                  </div>
              </div>
          </div>
      </div>
      )
  }
}

export default carSelection

