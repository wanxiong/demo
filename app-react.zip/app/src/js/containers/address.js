import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as addressAction from '../actions/address'
import {localStorage,sessionStorage} from '../utils/storage'

export const config={title:'地址筛选',isFirst:false};

function matchStateToProps(state) {
    return {
        state: state.addressReducer
    }
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({
        ...addressAction
    }, dispatch)
}

@connect(matchStateToProps, matchDispatchToProps)
class addressConponent extends React.Component{

    constructor(...props) {
        super(...props);
        var localcity = sessionStorage.getJson("userInfo").localCity;

            this.cityName=localStorage.getItem('cityName')||'上海';
            this.allCityHistory=localStorage.getJson('cityHistory')||{};
            this.cityHistory=this.allCityHistory[this.cityName]||[];

    }

    componentDidMount(){        
        this.props.update({keyword:''});
    }

    chooseAddress=(address)=>{
        return ()=>{
            if(!this.includeCity(address)){
                let cityHistory=this.cityHistory;
                cityHistory.unshift(address);
                if(cityHistory.lenth>5)
                    cityHistory.length=5;
                this.allCityHistory[this.cityName]=cityHistory;
                localStorage.setJson('cityHistory',this.allCityHistory);
            }
            var userInfo=sessionStorage.getJson('userInfo')||{};
            sessionStorage.setJson("userInfo",Object.assign(userInfo,{
                ToName:address.displayname,
                EndLat:address.lat,
                EndLng:address.lng,
                ToAddress:address.address
            }) );
            window.location.href = window.pagePath.index;
        }

    }

    chooseCity=()=>{
        location.href=window.pagePath.chooseAirport;
    }

    includeCity(address){
        var isInclude=false;
        this.cityHistory.some((item)=>{
            if(item.lng==address.lng&&item.lat==address.lat){
                return isInclude=true;
            }
        })
        return isInclude;
    }

    keywordChange=(e)=>{
        let value= e.target.value;
        this.props.update({keyword:value});
        clearTimeout(this.time);
        this.time=setTimeout(()=>{
         this.props.addressCurrent({city:this.cityName,sug:value});
        },300)
    }

    emptyFill=(e)=>{
        this.props.update({keyword:''});
    }

    render() {
        let {state:{keyword='',Data=[]}={}}=this.props;
        let hisAddress=this.cityHistory.map((item)=>{
            return (
                <div class="addressBox" onClick={this.chooseAddress(item)}>
                    <p>{item.displayname}</p>
                    <p>{item.address}</p>
                </div>
                )
        })
        let addressNode=(Data||[]).map((item)=>{
            return (
                <div class="addressBox" onClick={this.chooseAddress(item)}>
                    <p>{item.displayname}</p>
                    <p>{item.address}</p>
                </div>
                )
        })

        let Addrss,load;
        if(keyword){
            Addrss=(
                <div class="addressChoose">
                    <div class="location">
                        {addressNode}
                    </div>
                </div>
            )
        }
        else if(hisAddress.length>0){
            Addrss=(
                <div class="addressChoose">
                    <div class="location">
                        <h5>历史位置</h5>
                        {hisAddress}
                    </div>
                </div>
            )
            load=null;
        }else {
            load=(
                <img class="airlogo" src={`${window.cdnBasePath}/images/airlogo.png`}/>
            )
        }

        let inputFill=keyword?( <i onClick={this.emptyFill}></i>):null;

        return (
        <div>
            <div>
                <div class="container">
                    <div class="address">
                        <label onClick={this.chooseCity}>{this.cityName}</label>
                        <div class="addChoose">
                            <input type="text" placeholder="请输入地址" class="inputAddress" onChange={this.keywordChange} value={keyword}/>
                            {inputFill}
                        </div>
                    </div>
                    {load}
                    {Addrss}
                </div>
            </div>
        </div>
        )
    }
}

export default addressConponent

