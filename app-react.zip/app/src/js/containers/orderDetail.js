import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as orderDetailAction from '../actions/orderDetail'
import { getOrderStatus } from '../utils/utils-fn'
import { getCarType} from '../utils/utils-fn'
import app from '../utils/app'
import 'layerApp'
import 'layerAppCss'


export const config={title:'订单详情',isFirst:false};

function matchStateToProps(state) {
    return {
        state:state.orderDetailReducer
    }
}

function matchDispatchToProps(dispatch) {
        return bindActionCreators({
            ...orderDetailAction
        },dispatch);
}

@connect(matchStateToProps,matchDispatchToProps)

class orderDetail extends React.Component{


    constructor(...props){
      super(...props);
      this.orderID=app.parse_url(location.href)['OrderID'];
    }

    componentDidMount(){

    //获取订单详情
    this.props.orderGetData({"orderID":this.orderID});    
 }


     //取消订单
     _cancelOrder=(nextState,status)=>{
        if(status!=12){
             layerApp.open({
                    content: '您确定要取消订单吗？'
                    ,btn: ['确定', '取消']
                    ,yes:(index)=>{
                        this.props.orderCance({OrderID:this.orderID});
                    } 
                });
        }
       
     }

     //支付
     _goPay=()=>{
         this.props.goPay({OrderID: this.orderID,PayIndex:1});
     }

     //更新金额明细
     _updatePriceDetail=(detail)=>{
        this.props.updateData({priceDetail:detail});
     }
    render() {
        let{state}=this.props;

        let priceDetail=state.priceDetail;
        let orderData=[];
        if(state && state.view){
            let _orderDetail=state.view;
            let pricePoint=Math.floor(0.025*_orderDetail.OrderPoint*100)/100;
            orderData=(
                       <div>
                            <div>
                                <div class="container">
                                    <div class="orderDetail">
                                    <div class="detailLeft">
                                        <div class="detailNum"><span>订单详情</span>{this.orderID}</div>
                                        <p><span>创建时间:</span>{_orderDetail.OrderTime}</p>
                                        <p class="first"><span>订单金额:</span>¥<b>{_orderDetail.OrderAmount}</b><a href="javascript:void(0)"  onClick={()=>{this._updatePriceDetail(true)}}>金额明细</a></p>

                                          <div className={ priceDetail? 'cover':'cover hideCss' } onClick={()=>{this._updatePriceDetail(false)}} >
                                             <div class="priceDetail">
                                                 <h5>金额明细</h5>
                                                 <div class="priceBox">
                                                     <div class="firstBox">名称</div>
                                                     <div>价格</div>
                                                 </div>
                                                 <div className={_orderDetail.OrderAmount>0 ?'priceBox':'hideCss' }>
                                                     <div class="firstBox">{_orderDetail.TransferType==1? '接机金额':(_orderDetail.TransferType==2 ? '送机金额':'')}</div>
                                                     <div>¥{_orderDetail.OrderAmount}</div>
                                                 </div>
                                                 <div className={_orderDetail.Coupon && _orderDetail.Coupon.CouponValue>0 ?'priceBox':'hideCss' }>
                                                     <div class="firstBox">优惠券</div>
                                                     <div>¥-{_orderDetail.Coupon && _orderDetail.Coupon.CouponValue>0 ? _orderDetail.Coupon.CouponValue:0}</div>
                                                 </div>
                                                 <div className={pricePoint>0 ? 'priceBox':'hideCss'}>
                                                     <div class="firstBox">积分</div>
                                                     <div>¥-{pricePoint}</div>
                                                 </div>
                                                 <div class="priceBox priceAll">
                                                     <div class="firstBox">总价</div>
                                                     <div>¥{_orderDetail.RealPayAmount || 0 }</div>
                                                 </div>
                                             </div>
                                         </div>
                                        
                                    </div>
                                    <div class="detailRight" className={(_orderDetail.OrderStatus==1||_orderDetail.OrderStatus==3||_orderDetail.OrderStatus==4 || _orderDetail.OrderStatus==7)?'detailRight ok':'detailRight' }  >
                                        {getOrderStatus(_orderDetail.OrderStatus)}
                                    </div>
                                </div>
                                <div  className={ _orderDetail.NextState==1 ? 'gotoPay' :'hideCss'}  >
                                    <a href="javascript:void(0)"  onClick={ ()=>{this._cancelOrder(_orderDetail.NextState,_orderDetail.OrderStatus)} }  className={_orderDetail.OrderStatus==12 ? 'payBtn':'payBtn payCancel'}>取消订单</a>
                                    <a href="javascript:void(0)"  onClick={ this._goPay} class='payBtn payCancel' >去支付</a>
                                </div>
                                <div className={(_orderDetail.DriverName||_orderDetail.DriverPhone || _orderDetail.CarName ||_orderDetail.LicenseNumber)  ? 'orderMain':'hideCss'}>
                                    <div class="orderContain">
                                        <p className={_orderDetail.DriverName ? '' : 'hideCss'}><span>司机:</span>{_orderDetail.DriverName}</p>
                                        <p className={_orderDetail.DriverPhone ? '' : 'hideCss'}><span>电话:</span>{_orderDetail.DriverPhone}</p>
                                        <p className={_orderDetail.CarName ? '': 'hideCss'}><span>车型:</span>{_orderDetail.CarName}</p>
                                        <p className={_orderDetail.LicenseNumber ? '':'hideCss'}><span>牌照:</span>{_orderDetail.LicenseNumber}</p>
                                    </div>
                                </div>
                                <div class="orderMain">
                                    <div class="orderTime">{_orderDetail.DepartTime }  {_orderDetail.TransferType==1 ? ' 接机 ':(_orderDetail.TransferType==2 ? ' 送机 ':'') }  {_orderDetail.RideType}</div>
                                    <div class="orderContain">
                                        <p className={_orderDetail.DepartAddress ? '' : 'hideCss'}><span>出发地点:</span>{_orderDetail.DepartAddress}</p>
                                        <p className={_orderDetail.DestinAddress ? '':  'hideCss'}><span>目的地:</span>{_orderDetail.DestinAddress}</p>
                                        <p className={_orderDetail.UserName ? '' : 'hideCss' }><span>订车人:</span>{_orderDetail.UserName}</p>
                                        <p className={_orderDetail.UserPhone? '': 'hideCss'}><span>电话:</span>{_orderDetail.UserPhone}</p>
                                        <p className={_orderDetail.PassengerName? '':'hideCss'}><span>乘车人:</span>{_orderDetail.PassengerName}</p>
                                        <p className={_orderDetail.PassengerPhone? '' : 'hideCss' }><span>电话:</span>{_orderDetail.PassengerPhone}</p>
                                    </div>
                                </div>
                                <div  className={_orderDetail.Invoice ? "orderMain invoiceName" :"hideCss"}>
                                    <div class="orderTime">发票</div>
                                    <div class="orderContain">
                                        <p><span>抬头:</span>{_orderDetail.Invoice ? _orderDetail.Invoice.InvoiceTitle:''}</p>
                                        <p><span>收件人:</span>{_orderDetail.Invoice ? _orderDetail.Invoice.ReceiveName:''}</p> 
                                        <p><span>电话:</span>{_orderDetail.Invoice ? _orderDetail.Invoice.ReceivePhone:''}</p>
                                        <p><span>地址:</span>{_orderDetail.Invoice ? _orderDetail.Invoice.ReceiveAddress:''}</p>
                                    </div>
                                </div>
                                <div className={ _orderDetail.NextState==2 ? "orderStatus" :'hideCss'}>
                                    <a href="javascript:void(0)"  onClick={ ()=>{this._cancelOrder(_orderDetail.NextState,_orderDetail.OrderStatus)} }  className={_orderDetail.OrderStatus==12 ?'orderBtn ':'orderBtn cancelOrder'}>取消订单</a>
                                </div>
                            </div>
                        </div>
                    </div>
                );
             }

    return (

          <div>
               {orderData}
          </div>

           
           
      )
    }
}

export default orderDetail

