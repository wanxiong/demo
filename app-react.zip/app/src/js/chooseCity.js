import app from './utils/app'
import Container,{config} from './containers/chooseCity'
import 'layerApp';
import 'layerAppCss';

app.init(Container,config);
