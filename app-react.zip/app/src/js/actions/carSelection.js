import {get,post} from '../utils/fetch.js';

export const CAR_GETDATA='CAR_GETDATA';
export const CAR_BOOKING='CAR_BOOKING';


//车型列表
export const carLoad=(data)=>{
	return {
		type:CAR_GETDATA,
		payload:post('api/DDForAPP/DDProductWithPrice',data)
	}
}

//车型预定
export const carBooking=(data)=>{
	return {
		type:CAR_BOOKING,
		payload:post('api/DDForAPP/SavePreOrder',data)
	}
}
