import { get,post }from '../utils/fetch'

export const CITY_LOAD = 'CITY_LOAD'
export const STATE_UPDATE='CITY_STATE_UPDATE'

export const cityLoad = () => {
    return {
        type: CITY_LOAD,
        payload:  get('api/DDForAPP/GetDDSupportAirportList')
    }
}

export const updateState=(data)=>{
	return {
		type:STATE_UPDATE,
		data
	}
}
