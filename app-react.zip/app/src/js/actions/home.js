export const UPDATE_STATE='UPDATE_STATE'
export const INIT_STATE = "INIT_STATE"
export const CHANGE_GLIGHTID = "CHANGE_GLIGHTID"
export const CHANGE_STATUS = "CHANGE_STATUS"
export const SUBMIT_CHANGE = "SUBMIT_CHANGE"

export function update(data){
	return {
		type:UPDATE_STATE,  //action是一个对象，其中type属性是必须的，同时可以传入一些数据。
		data:data
	}
}
//数据初始化
export function initState(){
	return {
		type:INIT_STATE
	}
}
//改变航班号
export function onChangeFlightID(data){
	return {
		type:CHANGE_GLIGHTID,
		data:data
	}
}
//改变接送机状态
export function onChangeStatus(data){
	return {
		type:CHANGE_STATUS,
		data:data
	}
}


//提交搜索验证
export function onSubmitChange(){
	return {
		type:SUBMIT_CHANGE,

	}
}