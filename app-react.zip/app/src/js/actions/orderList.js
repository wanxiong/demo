import {get,post} from '../utils/fetch.js';
import app from '../utils/app'
export const ORDLIST_GETDATA='ORDLIST_GETDATA';
export const ORDLIST_GETMOREDATA='ORDLIST_GETMOREDATA';
export const ORDLIST_CHANGSTASTUS='ORDLIST_CHANGSTASTUS';
export const ORDLIST_INITSTATUS='ORDLIST_STASTUS';
export const ORDLIST_GOPAY='ORDLIST_GOPAY';


//获取首页订单列表
export const orderLoad=(data)=>{
	return {
		type:ORDLIST_GETDATA,
		payload: post('api/DDForAPP/OrderListView',data)
	}
}


//获取更多订单列表
export const orderLoadMoreData=(data)=>{
	return {
		type:ORDLIST_GETMOREDATA,
		payload: post('api/DDForAPP/OrderListView',data)
	}
}


//去支付
export const orderGoPay=(params)=>{
	return {
		type:ORDLIST_GOPAY,
		payload: post('api/DDForAPP/GetOrderPayUrl',params)
	}
}


//tab状态初始化
export const orderInitStatus=()=>{
	return{
		type:ORDLIST_INITSTATUS
	}
}

//改变tab切换
export const orderChangeStatus=(data)=>{
	return{
		type:ORDLIST_CHANGSTASTUS,
		data:data
	}
}







