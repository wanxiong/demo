import { get,post }from '../utils/fetch'
export const LOAD_DATA='ORDER_LOAD_DATA'
export const CREATE_ORDER='CREATE_ORDER'
export const INIT_DATA='ORDER_INIT_DATA' 
export const UPDATE_DATA='ORDER_UPDATE_DATA'


export const loadData=(data)=>{
	return {
		type:LOAD_DATA,
		payload:post('api/DDForAPP/GetPreOrder',data),
		...data
	}
}

export const createOrder=(data)=>{
	return {
		type:CREATE_ORDER,
		payload:post('api/DDForAPP/DDCreateOrder',data)
	}
}

export const initData=()=>{
	return {
		type:INIT_DATA
	}
}

export const updateData=(data)=>{
	return {
		type:UPDATE_DATA,
		data
	}
}