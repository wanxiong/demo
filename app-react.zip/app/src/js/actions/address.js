import { get,post }from '../utils/fetch'

export const ADDRESS_CURRENT = 'ADDRESS_CURRENT'
export const ADDRESS_UPDATE = 'ADDRESS_UPDATE_ATATE'

export const addressCurrent =(data)=>{
   return {
       type: ADDRESS_CURRENT,
       payload: post('api/DDForAPP/DDPOI',data,{hasLoading:false})
   }
}

export const update=(data)=>{
	return {
		type:ADDRESS_UPDATE,
		data:data
	}
}

