import { get,post }from '../utils/fetch'

export const CITY_LOAD = 'CITY_LOAD'
export const FORCUSTOM = 'FORCUSTOM'
export const STATE_UPDATE='AIRPORT_STATE_UPDATE'
export const SET_CITY = "SET_CITY"
export const cityLoad = () => {
    return {
        type: CITY_LOAD,
        payload: get('api/DDForAPP/GetDDSupportAirportList')
    }    
}


export const forCustom = (params) => {

    return {
        type: FORCUSTOM,
        payload:  post('api/DDForAPP/DDPOI',params),
        data:1
    }
}
export  const  setCity = (city)=>{
    return {
        type:SET_CITY,
        city:city
    }
}


export const updateState=(data)=>{
	return {
		type:STATE_UPDATE,
		data
	}
}



