import {get,post} from '../utils/fetch.js';
export const ORD_GETDATA='ORD_Detail'
export const ORD_CANCE='ORD_CANCE';
export const ORD_GOPAY='ORD_GOPAY';
export const ORD_UPDATEDATA='ORD_UPDATEDATA';

//获取订单详情
export const orderGetData=(data)=>{
	return{
		type:ORD_GETDATA,
		payload:post('api/DDForAPP/OrderView',data)
	}
}

//支付
export const goPay=(data)=>{
	return{
		type:ORD_GOPAY,
		payload:post('api/DDForAPP/GetOrderPayUrl',data)
	}
}

//取消订单
export const orderCance=(data)=>{
	return{
		type:ORD_CANCE,
		payload:post('api/DDForAPP/UserCancelOrder',data)
	}
}


//更新数据
export const updateData=(data)=>{
	return {
		type:ORD_UPDATEDATA,
		data
	}
}




