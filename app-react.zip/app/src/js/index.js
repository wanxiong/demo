import app from './utils/app'
import Container,{config} from './containers/index'
app.init(Container,config);