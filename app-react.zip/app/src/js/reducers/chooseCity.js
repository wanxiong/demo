import { CITY_LOAD,FORCUSTOM,STATE_UPDATE,SET_CITY} from '../actions/chooseCity'

import  {sessionStorage,localStorage} from "../utils/storage"
import  {message} from "../utils/utils-fn"

export function chooseCityReducer(state={},action){
    switch(action.type){
        case `${CITY_LOAD}_SUCCESS`:
            return Object.assign({},state,action.payload);
        case `${CITY_LOAD}_ERROR`:
            return state;

        case  `${FORCUSTOM}_SUCCESS`:
            console.log(action);
            var data = action.payload.Data;
            if(!data||data.length ==0){

                message("该机场暂不支持接送机");
                return state;
            }else{
                console.log();
                var cityname = sessionStorage.getItem("cityName");
                localStorage.setItem('cityName',cityname);
                var userInfo=sessionStorage.getJson('userInfo')||{};
                sessionStorage.setJson("userInfo",Object.assign(userInfo,{
                            FromName:data[0].displayname,
                            StartLat:data[0].lat,
                            StartLng:data[0].lng,
                            FromAddress:data[0].address
                        }) );
               window.location.href = window.pagePath.index;
                return Object.assign({},state,{
                    FromName:data[0].displayname,
                    StartLat:data[0].lat,
                    StartLng:data[0].lng,
                    FromAddress:data[0].address
                });
            }
        case SET_CITY:


            return state;
        case STATE_UPDATE:
            return Object.assign({},state,action.data);
        default:
            return state;
    }
}



