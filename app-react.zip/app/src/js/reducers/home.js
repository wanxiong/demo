import  {
	UPDATE_STATE,
	INIT_STATE,
	CHANGE_GLIGHTID,
	CHANGE_STATUS,
	SUBMIT_CHANGE
} from  '../actions/home'
import  {sessionStorage} from "../utils/storage"
import {message} from '../utils/utils-fn'

//reducer是一个函数，它接受一个state和一个action，根据action的type返回一个新的state。

export function homeReducer(state={},action){
	switch(action.type){
		case UPDATE_STATE:
			sessionStorage.extendJson("userInfo",{
				DepartureTime:action.data.DepartureTime
			});

			return Object.assign({},state,action.data) ;
		case INIT_STATE:
			var data = sessionStorage.getJson("userInfo");

			if(data){
				return Object.assign({},state,data);
			}else{

				sessionStorage.setJson("userInfo",{
					status:"jj"
				});
				return Object.assign({},state,{
					status:"jj"
				}); 
			}
		case CHANGE_STATUS:
			sessionStorage.extendJson("userInfo",{
					status:action.data
				});
			return Object.assign({},state,{status:action.data}); 	
		case CHANGE_GLIGHTID:
			sessionStorage.extendJson("userInfo",{
					flightID:action.data
				});
			return Object.assign({},state,{flightID:action.data});
		case SUBMIT_CHANGE:

			let {StartLat,StartLng,FromName,EndLat,EndLng,ToName,DepartureTime,status,FromAddress,ToAddress,flightID}=state;
			if(status!=='jj'){
				[StartLat,StartLng,FromName,FromAddress,EndLat,EndLng,ToName,ToAddress]=[EndLat,EndLng,ToName,ToAddress,StartLat,StartLng,FromName,FromAddress]
			}else{
				if(!flightID){
					message("请输入航班号");
					return state;
				}	
			}
			if(!DepartureTime){
				message("请选择用车时间");
			}else if(!FromName){
				message("请选择出发地");
			}else if(!ToName){
				message("请选择目的地");
			}else{
				if(flightID == undefined){
					flightID = "";
				};
				location.href=`${window.pagePath.carSelection}?
				StartLat=${StartLat}
				&StartLng=${StartLng}
				&FromName=${FromName}
				&FromAddress=${ToAddress}
				&EndLat=${EndLat}
				&EndLng=${EndLng}
				&ToName=${ToName}
				&ToAddress=${FromAddress}
				&TransferType=${status=='jj' ?'1':'2'}
				&DepartureTime=${+new Date(DepartureTime)}
				&Traffic_date=${+new Date(DepartureTime)}
				&Traffic_no=${flightID}`
			}
			return state;
		default:
			return state;
	}
}

