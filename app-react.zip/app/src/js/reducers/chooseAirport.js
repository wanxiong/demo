import { CITY_LOAD,STATE_UPDATE} from '../actions/chooseAirport'

export function cityLoad(state={},action){
    switch(action.type){
        case `${CITY_LOAD}_SUCCESS`:
            return Object.assign({},state,action.payload);
        case STATE_UPDATE:
            return Object.assign({},state,action.data);
        default:
            return state;
    }
}

