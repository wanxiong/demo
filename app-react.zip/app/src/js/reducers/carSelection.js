import { CAR_GETDATA,CAR_BOOKING } from '../actions/carSelection'
import {message}  from '../utils/utils-fn'

export const  carSelectionReducer=(state={},action)=>{	
	switch(action.type){
		case `${CAR_GETDATA}_SUCCESS`:
			return Object.assign({},state,action.payload);
		case `${CAR_BOOKING}_SUCCESS`:	
			let {Data}=action.payload;
			if(!Data||!Data.PreOrderkey){
				message('预定失败！');
				return;
			}
			location.href=`${window.pagePath.orderFill}?PreOrderkey=${Data.PreOrderkey}`;	
			return Object.assign({},state);
		default :
			return state;
	}
}


