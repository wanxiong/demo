import {ORDLIST_GETDATA,ORDLIST_GETMOREDATA,ORDLIST_GOPAY,ORDLIST_INITSTATUS,ORDLIST_CHANGSTASTUS} from '../actions/orderList'
import  {sessionStorage} from "../utils/storage"
import app from '../utils/app'
const initialState={
            status:'preActiveIndex',
            //一个月内
            preOrderObj:{
                PageIndex:1,
                PageSize:1000,
                StartCreateTime:null,
                EndCreateTime:null,
                totalPage:null,
                pageCount:0,
                preOrderList:[],
                loading:false,
                status:'preActiveIndex'
            },
            //一个月前
            nextOrderObj:{
                PageIndex:1,
                PageSize:1000,
                StartCreateTime:null,
                EndCreateTime:null,
                totalPage:null,
                pageCount:0,
                nextOrderList:[],
                loading:false,
                status:'nextActiveIndex'
            }
        }



export const orderListReducer=(state=initialState,action)=>{
        switch(action.type){
          case `${ORDLIST_GETDATA}_SUCCESS`:
                 return loadData(state,action.payload.Data);
          case `${ORDLIST_GOPAY}_SUCCESS`:
                var data=Object.assign({},state, action.payload.Data);
                return goPay(data);
          case ORDLIST_CHANGSTASTUS:
                state.status=action.data;
                return Object.assign({},state);
          default :
                return state;
    }
}

//加载首页数据
function  loadData(state,data) {
            var content=data.OrderList||[];
            //一个月内
            if(content && state.status=='preActiveIndex'){
                // state.preOrderObj.totalPage=data.Paging.TotalPage;
                // state.preOrderObj.pageCount=data.Paging.TotalCount;
                state.preOrderObj.preOrderList=content;
                // state.preOrderObj.PageIndex+=1;

                //state.preOrderObj.loading=false;
            }
            //一个月前
            else if(content && state.status=='nextActiveIndex'){
                // state.nextOrderObj.totalPage=data.Paging.TotalPage;
                // state.nextOrderObj.pageCount=data.Paging.TotalCount;
                state.nextOrderObj.nextOrderList=content;
                //state.nextOrderObj.PageIndex+=1;

                //state.nextOrderObj.loading=false;
            }
        return Object.assign({},state, data);

}




function goPay(state) {

    var url=state.PaymentUrl;
    if(url){
        if(app.isInApp()){
           url+=(url.indexOf('?')>-1?'&':'?')+'p='+app.getP();
        }
        location.href=url;
    }
    return state;

}




/*//获取更多数据
function loadMoreData(state,data,status) {

        //一个月内
        if(status=='preActiveIndex'){
                state.preOrderObj.loading=true;
                var content=data.OrderList ||[];
                if(content){
                   for (var i = 0; i < content.length; i++) {
                       state.preOrderObj.OrderList.push(content[i]);
                   }
                   state.preOrderObj.PageIndex+=1;
                }
                state.preOrderObj.loading=false;
        }
        //一个月前
        else if(status=='nextActiveIndex'){
                state.nextOrderObj.loading=true;
                var content=data.OrderList ||[];
                if(content){
                   for (var i = 0; i < content.length; i++) {
                       state.nextOrderObj.OrderList.push(content[i]);
                   }
                   state.nextOrderObj.PageIndex+=1;
                }
                state.nextOrderObj.loading=false;
        }
        return Object.assign({},state, {status:status},data);
}
*/



//tab切换
// function tabChange(state,data,status){
//      if(state.status==status){
//        return Object.assign({},state,data);
//      }else{
//           loadData(state,data,status);
//      }
// }




