import {ORD_GETDATA,ORD_CANCE,ORD_GOPAY,ORD_UPDATEDATA} from '../actions/orderDetail'
import  {sessionStorage} from "../utils/storage"
import app from '../utils/app'
export const orderDetailReducer=(state={priceDetail:false},action)=>{
	 switch(action.type){
          case `${ORD_GETDATA}_SUCCESS`:
             return Object.assign({},state,action.payload.Data);
           case `${ORD_CANCE}_SUCCESS`:
                location.href=location.href;
             return Object.assign({},state,action.payload.Data);
          case `${ORD_GOPAY}_SUCCESS`:
            var pay=Object.assign({},state,action.payload.Data);
             return goPay(pay);
          case ORD_UPDATEDATA:
             return Object.assign({},state,action.data);;
          default :
             return state;
    }
}
//获取订单详情
function loadData(state) {
      state.NextState=3;
      return state;
}

//取消订单失败
function orderCanceError(state) {
    state.view.OrderStatus=13;
    return state;
 
}



//支付回调
function goPay(state) {

    var url=state.PaymentUrl;
    if(url){
        if(app.isInApp()){
           url+=(url.indexOf('?')>-1?'&':'?')+'p='+app.getP();
        }
        location.href=url;
    }
    return state;

}

//更新金额明细状态
function orderUpdate(state) {
     return state;


}



