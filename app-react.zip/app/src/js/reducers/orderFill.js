import  {LOAD_DATA,CREATE_ORDER,INIT_DATA,UPDATE_DATA} from  '../actions/orderFill'
import app from '../utils/app'
import {sessionStorage} from '../utils/storage'

export function orderFillReducer(state={},action){
	switch(action.type){
		case `${LOAD_DATA}_SUCCESS`:
			return loadData(state,action);
		case `${CREATE_ORDER}_SUCCESS`:
			return createOrder(state,action);
		case INIT_DATA:
			return initData(state,action);
		case UPDATE_DATA:
			return Object.assign({},state,action.data);
		default:
			return state;
	}
}

function loadData(state,action){
	return Object.assign({},state,action.payload.Data);
}

function createOrder(state,action){
	let {Data:{PaymentUrl}={}}=action.payload;
	if(PaymentUrl){
		if(app.isInApp()){
			PaymentUrl+=(PaymentUrl.indexOf('?')>-1?'&':'?')+'p='+app.getP();
		}
		location.href=PaymentUrl;
	}
	return state;
}

function initData(state,action){
	let {productKey}=app.parse_url(location.href);
	let cacheData=sessionStorage.getJson('orderState');
	return Object.assign({},state,cacheData.state);
}

