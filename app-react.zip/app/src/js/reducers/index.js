import { combineReducers } from 'redux';

import * as home from './home';
import * as chooseCity from './chooseCity';
import * as chooseAirport from './chooseAirport';
import * as address from './address';
import * as orderFill from './orderFill';
import * as orderList from './orderList';
import * as orderDetail from './orderDetail';
import * as carSelection from './carSelection';

const reducers  = combineReducers({
  ...home,
  ...chooseCity,
  ...chooseAirport,
  ...address,
  ...orderFill,
  ...orderList,
  ...orderDetail,
  ...carSelection
})

export default reducers
