import BaseFetch from 'BaseFetch'
import app from './app'
import {message} from './utils-fn'

class Fetch extends BaseFetch{
	constructor(...args){
		super(...args)
	}

	checkCode(response){
		//可以根据后端返回的code 进行处理
		switch(response.HttpCode*1){
			case 401://code=401代表未登录，调用登陆方法
				this.login(response);
				return Promise.reject(response);
			case 200://code=200成功 调用resolve
				return Promise.resolve(response);
			case 500://code=500提示返回的message
				if(response.ErrorMessage)
					message(response.ErrorMessage);
				return Promise.reject(response);
		}
		return Promise.resolve(response);
	}

	login(response){
		if(app.isInApp())
		 	app.hybirdLogin(location.href);
	 	else{
	 		let {Data:{LoginUrl}={}}=response;
	 		if(LoginUrl)
	 			location.href=LoginUrl;
	 	}
	}

	/*@description 添加url参数,此方法需子类重写*/
	addParams(option){
		option.params=option.params||{};
		Object.assign(option.params,{p:app.getP()});
	}
	/*@description 添加body参数,此方法需子类重写*/
	addData(option){
		let RedirectUrl;
		if(!app.isInApp())
			RedirectUrl=location.href;
		
		option.data=option.data||{};
		Object.assign(option.data,{RedirectUrl});
	}
	/*@description 对url进行处理,此方法需子类重写*/
	handleUrl(url){
		url=(window.apiBase||'')+url;
		return url;
	}


	showLoading(){
		var loding=document.querySelector('#loading');
		if(loding)
			loding.style.display='';
		else{
			var divNode= document.createElement('div');
			divNode.innerHTML=`
				<div class="cover loading" id="loading">
            		<img src="${window.cdnBasePath}/images/loading.gif" />
        		</div>
			`
			document.body.appendChild(divNode);
		}

	}

	hideLoading(){
		var loding=document.querySelector('#loading');
		if(loding)
			loding.style.display='none';
	}

}

const fetchInstance=new Fetch({
	configs:{
		credentials:'include',//cookies是否发送服务端 "omit"（默认）,"same-origin"以及"include"
		mode:"cors",//是否跨域 属性值为 same-origin ， no-cors （默认）以及 cors
		headers:{}//请求报文的头信息
	}	
});

export default fetchInstance;
export const post=fetchInstance.post.bind(fetchInstance);
export const get=fetchInstance.get.bind(fetchInstance);
export const fetch=fetchInstance.fetch.bind(fetchInstance);
