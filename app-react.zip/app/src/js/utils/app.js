import 'ga'
import BaseApp from 'baseApp'
import ReactDOM from 'react-dom'
import fastclick from 'fastclick'
import store from './store'
import {Provider} from 'react-redux'

class App extends BaseApp{
	constructor(props) {
		super(props);
		this.hasInit=false;
	}

	init(Container,{isFirst,title}){
		if(this.hasInit)return;
		this.hasInit=true;

		let url=location.href,
		params=this.parse_url(url);
		this.saveAppParam(params);//保存app 参数值
		
		document.addEventListener('DOMContentLoaded', ()=> {
			fastclick.attach(document.body);
		}, false);

		window.addEventListener('load', ()=> {  
			this.bindBack(isFirst);
			title&&this.setHeader(title); 
			if(Container){
				ReactDOM.render(
					<Provider store={store}>
					<Container></Container>
					</Provider>
					,document.querySelector('.container'));
			}      	    		
		}, false);

		// document.body.addEventListener('touchmove', function(e) {
		// 	e.preventDefault();
		// },false);

	}

}

const app= new App();

export default app;

// window.pagePath={
//  	address:'address.html',
//  	carSelection:'carSelection.html',
//  	chooseCity:'chooseCity.html',
//  	chooseAirport:'chooseAirport.html',
//  	index:'index.html',
//  	orderDetail:'orderDetail.html',
//  	orderFill:'orderFill.html',
//  	orderList:'orderList.html',
//     bookMess:'bookMess.html'
//  }

window.pagePath={
	address:'Address',
	carSelection:'CarSelection',
	chooseCity:'ChooseCity',
	chooseAirport:'ChooseAirport',
	index:'Index',
	orderDetail:'OrderDetail',
	orderFill:'OrderFill',
	orderList:'OrderList',
	bookMess:'BookMess'
}

window.cdnBasePath=window.cdnBasePath||'';


Date.prototype.pattern=function(fmt) {         
    var o = {         
    "M+" : this.getMonth()+1, //月份         
    "d+" : this.getDate(), //日         
    "h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时         
    "H+" : this.getHours(), //小时         
    "m+" : this.getMinutes(), //分         
    "s+" : this.getSeconds(), //秒         
    "q+" : Math.floor((this.getMonth()+3)/3), //季度         
    "S" : this.getMilliseconds() //毫秒         
    };         
    var week = {         
    "0" : "周日",         
    "1" : "周一",         
    "2" : "周二",         
    "3" : "周三",         
    "4" : "周四",         
    "5" : "周五",         
    "6" : "周六"        
    };         
    if(/(y+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));         
    }         
    if(/(E+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "/u661f/u671f" : "/u5468") : "")+week[this.getDay()+""]);         
    }         
    for(var k in o){         
        if(new RegExp("("+ k +")").test(fmt)){         
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));         
        }         
    }         
    return fmt;         
} 

