import 'layerApp';
import 'layerAppCss';

export function getCarType(type){
	var types={
		'compact':'舒适型',
		'luxury':'豪华型',
		'premium':'商务型'
	}
	return types[type];
}

export function getCarBox(type){
	var types={
		'compact':'2',
		'luxury':'3',
		'premium':'4'
	}
	return types[type];
}

export function getCarDes(type){
	var des={
		'compact':'帕萨特/天籁/本田雅阁等类似车型',
		'luxury':'奥迪A6/宝马5系等类似车型',
		'premium':'别克GLB/瑞风商务等车型'
	}
	return des[type];
}


export function getOrderStatus(type){
   let orderStatus={
   	    0:'待支付',
   	    1:'待派单',
   	    2:'无应答',
		3:'已接单',
		4:'司机已到达',
		5:'已上车',
		6:'已完成',
		7:'司机取消',
		8:'乘客取消',
		10:'失败订单',
		12:'已取消',
		13:'取消失败'
	}

	return orderStatus[type];
}
    
export function message(txt,time=1500){
	layerApp.open({
        content: txt,
        skin: 'msg',
        time: time
    });	
}