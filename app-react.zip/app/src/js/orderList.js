import app from './utils/app'
import Container,{config} from './containers/orderList'
app.init(Container,config);

