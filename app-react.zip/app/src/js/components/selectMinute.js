import ReactIScroll from 'react-iscroll'
import iscroll from 'iscroll'

class SelectMinute extends React.Component{

	static defaultProps = {
		options:{
					mouseWheel: false,
					snap: 'li',
					scrollY:true,
					scrollX:false
				}
  	}

	constructor(...args) {
		super(...args);
		this._init();
	}

  	onOk=()=>{
  		let {onOk}=this.props;
  		if(typeof onOk=='function')
  			onOk(this._val());
  	}

  	onCancle=()=>{
  		let {onCancle}=this.props;
  		if(typeof onCancle=='function')
  			onCancle();  		
  	}

  	_init(){
  		let {items=[],display,value}=this.props;
  		this.index=0;
  		this._val(value);
  	}

  	_val(value){
  		let {items=[],_value}=this.props;
  		if(value!=null){
  			let index=items.indexOf(value);
  			this.index=index>=0?index+2:2;
  		}else{
  			return items[this.index];
  		}
  	}

  	_setIndex(y){
  		let h=this.refs.firstLi.offsetHeight||0;
  		if(y!=null)
  			this.index=Math.round((y/h)*-1)
  		else 
  			return -(this.index)*h
  	}

  	onScrollEnd=(...args)=>{
  		let [{y}]=args;
  		let {onScrollEnd}=this.props;
  		this._setIndex(y);
  		if(typeof onScrollEnd=='function'){
  			onScrollEnd.apply(...args);
  		}
  	}

  	onRefresh=(iScrollInstance)=>{
  		iScrollInstance.scrollTo(0,this._setIndex());
  	}

	render() {
		let {items=[],display,onOK,onCancle,...options}=this.props;
		let liNode=items.map((item,index)=>(<li key={index}>{item}</li>));
			options={
				onRefresh:this.onRefresh,
				display,
				...options,
				onScrollEnd:this.onScrollEnd
			};
		return (
		<div ref='iContainer' style={{display:display}}>
			<div class="cover" ></div>
	    	<div class="chooseTime">
		        <div class="timeTop">
		            <div class="leftBtn" onClick={this.onCancle}>取消</div>
		            <div class="timeCh">选择用车时间</div>
		            <div class="rightBtn" onClick={this.onOk}>确定</div>
		        </div>
		        <div class="timeTab">		            
		           
		            <ReactIScroll ref='IscrollRef' class="timeTabIn" iScroll={iscroll} {...options} {...this.props.style}>
		                <ul class="timeMain">
		                	<li ref='firstLi'>&nbsp;</li>
		                	<li>&nbsp;</li>
		                    {liNode}
		                    <li>&nbsp;</li>
		                    <li>&nbsp;</li>
		                </ul>
	                </ReactIScroll >
		            
		            <div class="bB">
		                <div>到达后</div>
		                <div class="midd">10</div>
		                <div class="bBRight"><span>分</span>分钟</div>
		            </div>
		        </div>
	        </div>
        </div>
			)
	}
}

export default SelectMinute