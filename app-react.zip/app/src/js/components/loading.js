import React from 'react';

function Loading() {
    return (
        <div class="cover loading hideCss" id="loading">
            <img src="images/loading.gif" />
        </div>
    );
}

export default Loading;