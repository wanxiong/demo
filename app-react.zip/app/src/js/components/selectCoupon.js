import ReactIScroll from 'react-iscroll'
import iscroll from 'iscroll'

class SelectCoupon extends React.Component{

	static defaultProps = {
		options:{
					mouseWheel: false,
					snap: 'li',
					scrollY:true,
					scrollX:false
				}
  	}

	constructor(...args) {
		super(...args);
		this._init();
	}

  	onOk=()=>{
  		let {onOk}=this.props;
  		if(typeof onOk=='function')
  			onOk(this._val());
  	}

  	onCancle=()=>{
  		let {onCancle}=this.props;
  		if(typeof onCancle=='function')
  			onCancle();  		
  	}

  	_init(){
  		let {items=[],display,value}=this.props;
  		this.index=0;
  		this._val(value);
  	}

  	_val(value){
  		let {items=[],_value}=this.props;
  		if(value!=null){
  			let index=value;
  			this.index=index>=0?index+2:2;
  		}else{
  			return this.index;
  		}
  	}

  	_setIndex(y){
  		let h=this.refs.firstLi.offsetHeight||0;
  		if(y!=null)
  			this.index=Math.round((y/h)*-1)
  		else 
  			return -(this.index)*h
  	}

  	onScrollEnd=(...args)=>{
  		let [{y}]=args;
  		let {onScrollEnd}=this.props;
  		this._setIndex(y);
  		if(typeof onScrollEnd=='function'){
  			onScrollEnd.apply(...args);
  		}
  	}

  	onRefresh=(iScrollInstance)=>{
  		iScrollInstance.scrollTo(0,this._setIndex());
  	}

  	eventFn=(e)=>{
  		e.preventDefault();
  	}

	bindScroll(isAdd){
		// if(isAdd===false&&this.stopScroll){
		// 	document.body.removeEventListener('touchmove',this.eventFn,false);
		// 	this.stopScroll=false;
		// }
		// else if(!this.stopScroll){
		// 	this.stopScroll=true;
		// 	document.body.addEventListener('touchmove',this.eventFn,false);
		// }
	}  

	render() {
		let {items=[],display,onOK,onCancle,...options}=this.props;
		display=='none'?this.bindScroll(false):this.bindScroll();
		let liNode=items.map((item,index)=>{
			let txt=index==0?item:item.Title;
			return(<li key={index}>{txt}</li>)
		});
			options={
				onRefresh:this.onRefresh,
				display,
				...options,
				onScrollEnd:this.onScrollEnd
			};
		return (
		<div ref='iContainer' class={display}>
			<div class="cover" ></div>
	    	<div class="chooseTime">
		        <div class="timeTop">
		            <div class="leftBtn" onClick={this.onCancle}>取消</div>
		            <div class="timeCh noPadding">选择优惠券</div>

		            <div class="rightBtn" onClick={this.onOk}>确定</div>
		        </div>
		        <div class="timeTab">		            
		           <div class="bB">
		                <div></div>
		                <div class="midd"></div>
		                <div class="bBRight"><span>分</span></div>
		            </div>
		            <ReactIScroll ref='IscrollRef' class="timeTabIn" iScroll={iscroll} {...options} {...this.props.style}>
		                <ul class="timeMain">
		                	<li ref='firstLi'>&nbsp;</li>
		                	<li>&nbsp;</li>
		                    {liNode}
		                    <li>&nbsp;</li>
		                    <li>&nbsp;</li>
		                </ul>
	                </ReactIScroll >
		            
		            
		        </div>
	        </div>
        </div>
			)
	}
}

export default SelectCoupon