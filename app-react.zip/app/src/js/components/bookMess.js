class bookMess extends React.Component{


	render() {

		return (
			<div>
				<div class="bookMessage">
					<h5>乘车须知</h5>
					<p>1、一口价已包含高速费、停车费等所有费用，无需额外付费给司机。若收取多收费用将双倍赔偿。</p>
					<p>2、最晚在2016-11-11 20:00前告知派车信息；</p>
					<p>3、若您提供航班号，航班延误免费等候，航班抵达后司机最长免费等候1小时。</p>
				</div>
				<div class="bookMessage">
					<h5>取消规则</h5>
					<p>2016-11-10 08:40前可免费取消，超时取消将收取订单全额费用。订单不支持修改。</p>
				</div>
			</div>
			)
	}
}

export default bookMess