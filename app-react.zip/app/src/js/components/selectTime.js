import ReactIScroll from 'react-iscroll'
import iscroll from 'iscroll'


class SelectDateTime extends React.Component{

	static defaultProps = {
		options:{
			mouseWheel: false,
			snap: 'li',
			scrollY:true,
			scrollX:false
		}
	}

	constructor(...args) {
		super(...args);
		this._init();
	}

	onOk=()=>{
		let {onOk}=this.props;
		if(typeof onOk=='function')
			onOk(this._val());
	}

	onCancle=()=>{
		let {onCancle}=this.props;
		if(typeof onCancle=='function')
			onCancle();
	}

	_init(){
		let {display,value,startDate,endDate}=this.props;
		this.index=[0,0,0];
		this.startDate=this._initStartDate(startDate);
		this.endDate=endDate;
		this.value=value;
		this.v=0;
	}

	_initStartDate(startTime){
		var mint=startTime.getMinutes();


		if(50<mint&&mint<=59){
			startTime=new Date(+startTime+1000*60*(60-mint));
		}
		return startTime;
	}

	_getDayItmes(){
		//获取每天的数据
		let {startDate,endDate}=this;
		let i=0;

		startDate=new Date(startDate);
		this.dayItems=[];
		while(+startDate+1000*60<=+endDate){
			this.dayItems.push(new Date(startDate));
			// if(this._initDateTime(startDate)==this._initDateTime(this.value))
			// 	this.index[0]=index+2;

			startDate=new Date(startDate.setDate(startDate.getDate()+1));
			i++;
		}

		this.mapDayIndex();
	}

	_getHourItems(){
		let {startDate,endDate}=this;
		let newHours=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],
			min=newHours[0],max=newHours[newHours.length-1],
			indexDay=this.index[0];

		if(indexDay==0){
			min=startDate.getHours();
		}

		if(indexDay==this.dayItems.length-1){
			max=endDate.getHours();
		}

		this.hourItems = newHours.filter(function(item){
			return item>=min&&item<=max;
		})

		this.mapHourIndex();
	}

	_getMinuteItems(){
		let {startDate,endDate}=this;
		let newMinutes=[0,10,20,30,40,50],
			min=newMinutes[0],
			max=newMinutes[newMinutes.length-1],
			indexDay=this.index[0],
			indexHour=this.index[1];
		if(indexDay==0&&indexHour==0){
			min=startDate.getMinutes();
		}

		if((indexDay==this.dayItems.length-1)&&(indexHour==this.hourItems.length-1)){
			max=endDate.getMinutes();
		}

		this.minuteItems= newMinutes.filter(function(item){
			return item>=min&&item<=max;
		})

		this.mapMinuteIndex();
	}

	mapDayIndex(){
		if(!this.value)this.index[0]=0;
		let index=0;
		this.dayItems.some((item,i)=>{
			if(+this._initDateTime(item)==+this._initDateTime(this.value))
				index=i;
		});
		this.index[0]=index;
	}

	mapHourIndex(){
		if(!this.value)this.index[1]=0;
		let index=0;
		this.hourItems.some((item,i)=>{
			if(item==this.value.getHours())
				index=i;
		});
		this.index[1]=index;
	}

	mapMinuteIndex(){
		if(!this.value)this.index[2]=0;
		let index=0;
		this.minuteItems.some((item,i)=>{
			if(item==this.value.getMinutes())
				index=i;
		});
		this.index[2]=index;
	}

	_initDateTime(date){
		if(!date)return date;
		if(typeof date=='number'||typeof date=='string')
			date=new Date(date);
		let year=date.getFullYear();
		let month=date.getMonth();
		let day=date.getDate();
		return new Date(year,month,day);
	}

	_val(){
		let curDate=this.dayItems[this.index[0]];
		let year=curDate.getFullYear();
		let month=curDate.getMonth();
		let day=curDate.getDate();
		let minute=this.minuteItems[this.index[2]];
		let hour=this.hourItems[this.index[1]];
		return this.value=new Date(year,month,day,hour,minute);
	}

	_setIndex(i,y){
		let h=this.refs['firstLi'+i].offsetHeight||0;
		if(y!=null){
			this.index[i]=Math.round((y/h)*-1);
			this.value=this._val();
		}
		else
			return -(this.index[i])*h
	}

	onScrollEnd=(i)=>(...args)=>{
		let [{y}]=args;
		this._setIndex(i,y);
		if(i<=1){
			this.setState({v:this.v++});
			// setTimeout(()=>{
			// 	if(i==0){
			// 		this.refs.IscrollRef1._iScrollInstance.refresh();

			// 	}
			// },1000)
		}
	}

	onRefresh=(i)=>(iScrollInstance)=>{
		iScrollInstance.scrollTo(0,this._setIndex(i));
	}

	componentDidUpdate(){
		// if(this.refs.IscrollRef1._iScrollInstance)
		// 	this.refs.IscrollRef1._iScrollInstance.refresh();
		console.log('update');
	}

	render() {
		this._getDayItmes();
		this._getHourItems();
		this._getMinuteItems();
		let {items=[],display,onOK,onCancle,...options}=this.props;
		let	options_0={
			onRefresh:this.onRefresh(0),
			display,
			...options,
			onScrollEnd:this.onScrollEnd(0)
		};
		let	options_1={
			onRefresh:this.onRefresh(1),
			display,
			...options,
			onScrollEnd:this.onScrollEnd(1)
		};
		let	options_2={
			onRefresh:this.onRefresh(2),
			display,
			...options,
			onScrollEnd:this.onScrollEnd(2)
		};
		let dayNode=this.dayItems.map((item,i)=>{
			let weeks=['周日','周一','周二','周三','周四','周五','周六'];
			let month=(item.getMonth()+1).toString();
			let day=item.getDate().toString();
			let week=weeks[item.getDay()];
			month=month.length==1?'0'+month:month;
			day=day.length==1?'0'+day:day;
			let text=`${month}月${day}日 ${week}`;
			return (
				<li key={'1'+i}>{text}</li>
			)
		});
		let hourNode=this.hourItems.map((item,i)=>{
			item=item.toString().length==1?'0'+item:item;
			return (
				<li key={'1'+i}>{item}时</li>
			)
		});

		let minuteNode=this.minuteItems.map((item,i)=>{
			return (
				<li key={'1'+i}>{item}分</li>
			)
		});
		return (
			<div class={display}>
			<div onClick={this.onCancle} class="cover"></div>
			<div class="chooseTime" >
				<div class="timeTop">
					<div class="leftBtn" onClick={this.onCancle}>取消</div>
					<div class="timeCh">选择用车时间</div>
					<div class="rightBtn" onClick={this.onOk}>确定</div>
				</div>
				<div class="timeTab">
					<div class="bB"></div>
					<div class="songJi">
						<ReactIScroll class="songLeft" ref='IscrollRef0' iScroll={iscroll} {...options_0}>
							<ul>
								<li ref='firstLi0'>&nbsp;</li>
								<li>&nbsp;</li>
								{dayNode}
								<li>&nbsp;</li>
								<li>&nbsp;</li>
							</ul>
						</ReactIScroll >

						<ReactIScroll class="songCenter" ref='IscrollRef1' iScroll={iscroll} {...options_1}>
							<ul>
								<li ref='firstLi1'>&nbsp;</li>
								<li>&nbsp;</li>
								{hourNode}
								<li>&nbsp;</li>
								<li>&nbsp;</li>
							</ul>
						</ReactIScroll >

						<ReactIScroll class="songRight" ref='IscrollRef2' iScroll={iscroll} {...options_2}>
							<ul>
								<li ref='firstLi2'>&nbsp;</li>
								<li>&nbsp;</li>
								{minuteNode}
								<li>&nbsp;</li>
								<li>&nbsp;</li>
							</ul>
						</ReactIScroll >


					</div>
					
				</div>
			</div>
			</div>
		)
	}
}

export default SelectDateTime
