const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}
// 时间格式转换   20180111121212 =》 2018/01/11
// flg 默认 false 
const formData = (n, Type,flg) => {
  var str = n + '';
  if(flg) {
    return str.substring(0, 4) + Type + str.substring(4, 6) + Type + str.substring(6, 8)
  } else {
    return str.substring(2, 4) + Type + str.substring(4, 6) + Type + str.substring(6, 8)
  }
  
}
//时间格式转换  20180111121212 =》  2018/01/11 10:10:10
const formData1 = (n, Type) => {
  var str = n + '';
  return str.substring(0, 4) + Type + str.substring(4, 6) + Type + str.substring(6, 8) + ' ' + str.substring(8, 10) +':' + str.substring(10, 12) +':' + str.substring(12, 14)
}
//去除首尾空格
const trim = str => {
  if (typeof str == 'string' || typeof str == 'number') {
    var str = str + '';
        str = str.replace(/^\s+|\s+$/g, '')
    return str
  }
  return str;
}
//支付方式名字匹配
//支付方式(必须) 01：内卡；02：外卡；03：支付宝；04：微信；05：抵用券；06：银行入金；07：储值卡；08：现金 
const payName = {
  "01":"内卡",
  "02":"外卡",
  "03":"支付宝",
  "04":"微信",
  "05":"抵用券",
  "06":"银行入金",
  "07":"储值卡",
  "08":"现金"
}
/* 长度匹配验证
* @params {String value } 验证的字符
* @params {Number len }   验证的长度
* return {Bolean } 返回Boolean
*/

const leng = (value,len) => {
  if( value.length == len) {
    return true
  } 
  return false
}
//不能为空
const required = (value) => {
  if (value != '') {
    return true
  }
  return false
}
//匹配数字和字母组合
const validate = (value) => {
  let reg = /^[a-zA-Z0-9]+$/ ;
  return reg.test(value)
}



module.exports = {
  formatTime: formatTime,
  trim,
  formData,
  formData1,
  payName,
  leng,
  required,
  validate
}
