// pages/webview/webview.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    var base = 'https://passport.muji.com.cn/alipay.sw/muji_news/20180419_1524133819/',
    ruleUrl = 'https://passport.muji.com.cn/alipay.sw/api/html/refund_rule.html',
    _this = this ;
    if(options.page){
      _this.setData({
        url: base + options.page + '/' + options.page  + '.html'
      })
    }
    if ( options.ruleHtml) {
      _this.setData({
        url: ruleUrl
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  }

})