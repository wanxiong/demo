import { trim, getData, formData } from '../../utils/util'
const app = getApp()
const startTimeYear = '2018' //小票开始时间，定值
const startTime = '20180118000000' //小票开始时间，定值
const getNewsYear = new Date().getFullYear();
let ticketCount = 3 //API请求失败尝试重试的最大次数
let TicketTimer = null //定时器
// pages/information/information.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url:'pages/information/information', //当前页面的url
    dateValue: getNewsYear, //当前显示的日期，默认值2018  单位年
    startTime: startTimeYear, //日期最小上限时间 默认值 2018 单位年
    endTime: getNewsYear,  //日期最大上限时间 默认值  单位年
    tabShowOne:true,   //默认选中状态是店铺查找
    inputValue:'',    //检索输入框的值
    inputPlaceHolder:'店铺名称 · 店番', //
    originData : '', //Api一开始加载的数据，即原始数据
    searchTime : [], //按照时间查找的数据展示源
    searchShop : [], //按照店铺查找的数据展示源
    shopOrigin: [],  // 当前所有的查找店铺筛选源
    searchOrigin: [], //当前所有的查找总数筛选源
    copyData  : [] , //备份一份原始数据 ，降序
    limit : 20,        //默认加载条数  20条
    endlimitLeft: 20,        //每条数据的最大上限  20条
    endlimitRight: 20,        //每条数据的最大上限  20条   
    ticketAmount : 0,  // 现有小票总数
    hasData:true ,//是否有数据  展示提示框
    isLoadMore : true,  //当前是否处于还可以加载状态
    showLoadMore:false, // 是否一开始拉区API就没有数据
    upShowFlg : false, //店铺上拉是否可以加在更多  默认 false
    upTimeFlg : false , // 时间上拉是否可以加在更多 默认false
    initTpl:true , //一开始显示加载文言，请求结束即可删除
    ticketFirst:false //第一次进入
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this ; 
    //页面刚出来显示遮罩
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    if (app.hasAuthorization ) { //用户授权过
      var inter = null, countT = 1, _this = this;
      
      
      
    }
 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this 
    app.cardIsFirst = false
    if (!app.hasAuthorization) {
      wx.showModal({
        title: '提示',
        content: '由于您暂未授权，此功能暂未对您开放,如需重新授权，需在微信【发现】——【小程序】——删掉【无印良品MUJI】，重新搜索授权登录，方可使用',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log(getCurrentPages()[0].route)
            if (_this.data.url == getCurrentPages()[0].route ) {
              //点击确定 不点导航tabbar时跳转pages/home/home月面
              console.log('点击确定')
              wx.switchTab({
                url: '/pages/home/home',
              })
            } else {
              console.log('点击tabbar')
            }
            //点击tabbar直接切换走，不点击确定按钮时候
          }
        }
      })
    } else {
      
      if (_this.data.ticketFirst) return ;
      var inter = null, countT = 1;
      _this.setData({ ticketFirst: true, initTpl:true})
      inter = () => { //定时器方法
        countT++
        if (app.unionid) {
          clearInterval(TicketTimer)
          _this.initData();
        } else {
          if (countT > 100) {
            //还没拿到，应该重新去啦API啦，我就当这样默认了，
            wx.hideLoading()
            wx.showToast({
              title: '出错了，请重试',
              icon: 'success',
              image: './../../image/icon-3.png',
              mask: true,
              duration: 1000
            })
            clearInterval(TicketTimer)
            setTimeout(() => {
              wx.switchTab({
                url: '/pages/home/home'
              })
            }, 1000)
           }
        }
      }
      //
      TicketTimer = setInterval(inter, 100)
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    //清楚多余的定时器
    clearInterval(TicketTimer)
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

    if (!this.data.isLoadMore || this.data.originData.length <= this.data.limit) return false ;
    console.log('上拉完毕')
    //上啦分区间。店铺上拉还是时间上啦
    var a = this.data.copyData,
    _this = this,
    flg = this.data.tabShowOne; 
    if (flg ) { //左边店铺加载更过
      if (!this.data.upShowFlg) return ;
      //店铺可以加在更过，拿取数据源直接push
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      _this.setData({upShowFlg: false})
      var list = _this.data.shopOrigin,
      limi = _this.data.endlimitLeft;
      _this.setData({ 
        searchShop: list.slice(0, limi),
        endlimitLeft: limi + _this.data.limit,
        upShowFlg: list.length > limi ? true : false
      })
      setTimeout(()=>{
        wx.hideLoading()
      },600)
      
      return 
    } else { //右边时间查找
      if (!this.data.upTimeFlg) return;
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      _this.setData({ upTimeFlg: false })
      var list = _this.data.searchOrigin,
      limi = _this.data.endlimitRight;
      _this.setData({
        searchTime: list.slice(0, limi),
        endlimitRight: limi+_this.data.limit,
        upTimeFlg: list.length > limi ? true : false
      })
      setTimeout(() => {
        wx.hideLoading()
      }, 500)
      return 
    }
  },
  /**
   * 日期选择 
   */ 
  bindDateChange(e) {
    var _this = this;
    var v = e.detail.value ;
    _this.setData({
      dateValue: v,
      endlimitLeft: _this.data.limit,
      endlimitRight:_this.data.limit,  
      isLoadMore: true
    })
    if (!this.data.ticketAmount) return ;//0条数据
    //按照年限查找的数据重新刷新
    _this.selectYear(v, _this.data.inputValue)
  },
  /**
   *  切换tab按钮
   */
  switchTabBtn(e) {
    var _this = this ;
    if( e.target.id == '1' ) { //点击查找按钮
      _this.setData({
        tabShowOne:false
      })
    } else { //点击店铺按钮
      _this.setData({
        tabShowOne: true
      })
    }
  },
  /** 
   *  跳转至店铺一览
   */
  openShopList(e) {
    var _this = this ;
    var params = e.currentTarget.dataset.value ;
    wx.navigateTo({
      url: `./../ticket/shopList/shop_list?shopCd=${params.shopCd}&count=${params.count}&year=${_this.data.dateValue}&shopName=${params.shopName}`,
    })
  },
  /**
   *  跳转至详情页
   */ 
  openDetail(e) {
    var _this = this;
    var params = e.currentTarget.dataset.value;
    params.realAmt = parseFloat(params.realAmt);
    params.payNames[0].pay = params.payNames[0].pay.toFixed(2);
    var isRefund = params.saleType;
    var json = JSON.stringify(params)
    if (isRefund == '0') {
        //退货
      wx.navigateTo({
        url: `./../ticket/refundShop/refundShop?params=${json}`
      })
    } else {
      //销售
      wx.navigateTo({
        url: `./../ticket/shopDetail/shop_detail?params=${json}`
      })
    }
    
  },
  /**
   *  输入框输入监听
   */
  inputChange(e) {
    //如果输入完全为空，那就重置
    var _this = this;
    var v = trim(e.detail.value);
      this.setData({ 
          inputValue: v,
          endlimitLeft: _this.data.limit,
          endlimitRight: _this.data.limit,  
          isLoadMore: true
      })
      if (!this.data.ticketAmount) return ; //0条数据
      this.selectShop(v)
    
  },
  /**
   *  输入框点击确定
   */
  confirm(e) {
    var _this = this ;
    var v = trim(e.detail.value)
    _this.setData({ 
        inputValue: v,
        limit: _this.data.limit,
        endlimitLeft: _this.data.limit,
        endlimitRight: _this.data.limit,
        isLoadMore: true
    })
    if (!this.data.ticketAmount) return ; //0条数据
    _this.selectShop(v)
  },
  /**
   * 初次加载获取API 
   */ 
  initData() {
    var _this = this ;
    var local = wx.getStorageSync('ticketData');
    console.log(local)
    if ( local ) {
        //本地是否存在缓存，有做差分 
      _this.getSaleInfo(app.unionid, local[0].checkoutDate, _this.hasCache, local)
    } else { //初次拉取API,有错必须提示，因为本地没任何数据
      _this.getSaleInfo(app.unionid, startTime,_this.noCache,[])     
    }
  },
  /**  用户没有缓存第一次执行的方法
   *   @params { Array list } //第一次返回的数据LIst
   * */
  noCache(list) {
    var _this = this ;
    if( !list.length) {
      //用户没有信息 显示提示信息
      _this.setData({ showLoadMore : true })
      wx.hideLoading()
    } else {
      //用户有过消费的信息
      var data = list;
      wx.setStorageSync('ticketData', data)
      _this.setData({ originData: data })
      //拷贝数组
      var copyData = data.slice();
       _this.setData({ copyData: copyData, })
      // 赋值20条  店铺归类
       var a = copyData.length;
       _this.initListFun( copyData)
       wx.hideLoading()
    }
  },
  /**  当用户第二次进来，并且已经有缓存的情况下
   *   @params { Array list } //差分返回的数据LIst
   *   @params { Array localList } // 本地获取的LIst
   *   @params { String lastTime } // 差分的时间
   **/ 
  hasCache(list,localList,lastTime) {
      var _this = this;
      //由于时间是大于等于当前最新时间，所以可能在毫秒之内取得好几条数据，拉去的肯定有重复的，需要去重。
      var a=[];
      //去重拿去本地有的数据
      for (let i = 0; i < localList.length ; i++){
        if (localList[i].checkoutDate == lastTime ){
          a.push(localList[i])
        } else {
          break;
        }
      }// 
      //去重
      for (let g = list.length - 1 ; g >= 0  ; g--) {
        if (list[g].checkoutDate == lastTime ){
            for( let h = 0 ; h < a.length ; h ++){
              if (a[h].saleId == list[g].saleId){
                //有重复的数据
                list.splice(g,1)
              }
            }
        } else {
          break;
        }
      }
      //
      if( !list.length) {
          //为空的话 读取本地数据
          var data = localList;
          _this.setData({
            originData: data
          })
          //拷贝数组
          var copyData = data.slice();
          _this.setData({
            copyData: copyData,
          })
          // 赋值20条  店铺归类
          var a = copyData.length;
          _this.initListFun(copyData)
      } else {
          //有差分的话，更新差分
          var mergeList = [...list, ...localList];
          _this.setData({
            originData: mergeList
          })
          //拷贝数组
          var copyData = mergeList.slice();
          _this.setData({
            copyData: copyData,
          })
          // 赋值20条  店铺归类
          var a = copyData.length;
          _this.initListFun(copyData)
      }
      wx.hideLoading()
  },
  /** 按照时间查找检索 
   *  @params {String time }   单位 年
   *  @params {String value }  输入框中的值
   */ 
  selectYear(time, value) {
    var _this = this, list = [], shopList = [];
    var data = _this.data.copyData;
    for (let i = 0; i < data.length ; i++) {
      var year = parseInt(data[i].checkoutDate.substring(0, 4));
      if (time == year) {
        data[i].realAmt = parseFloat(data[i].realAmt).toFixed(2)
        data[i].fromCheckoutDate = formData(data[i].checkoutDate, '/')
        list.push(data[i] )
      }
    }
    
    if (value ) {
      _this.selectShop(value);
    } else {
      //在去判断是否输入过检索文字
      var limit = _this.data.endlimitRight,
        sliceList = '';
      if (list.length > limit) { //分页
        _this.setData({
          searchOrigin: list,
          endlimitRight: limit + limit,
          upTimeFlg: true
        });
        sliceList = list.slice(0, limit)
      } else { //不分页
        _this.setData({
          searchOrigin: list,
          upTimeFlg: false
        });
        sliceList = list
      }
      //
      shopList = _this.fromShop(data, _this.data.dateValue, value)
      //检索到了 & 赋值
      _this.setDataList(sliceList, shopList)   
    }
    
    
  },
  /**  按照店铺名称或者店番
   *  @params {String  value}  输入的内容
  */
  selectShop(value) {
    var _this = this, 
        list = [],
        shopList = [];
    var data = _this.data.copyData, 
        nowYear = _this.data.dateValue,
        limit = _this.data.limit;
    if( value ) {
      //有值   根据当前年月份来重新赋值 && 拿取原始数据
      for (let i = 0; i < data.length; i++) {
       
        var year = parseInt(data[i].checkoutDate.substring(0, 4));
        if ((data[i].shopName.indexOf(value) != -1 || data[i].shopCd.indexOf(value) != -1 ) && year == nowYear) {
            data[i].realAmt = parseFloat(data[i].realAmt).toFixed(2)
          //if (list.length >= limit) break; //已经达到条数的要求
            data[i].fromCheckoutDate = formData(data[i].checkoutDate, '/')
            list.push(data[i])
          }
          //再去统计店铺归类
      }
      //在去判断是否输入过检索文字
      var limit = _this.data.endlimitRight,
        sliceList = '';
      if (list.length > limit) { //分页
        _this.setData({
          searchOrigin: list,
          endlimitRight: limit + limit,
          upTimeFlg: true
        });
        sliceList = list.slice(0, limit)
      } else { //不分页
        _this.setData({
          searchOrigin: list,
          upTimeFlg: false
        });
        sliceList = list
      }
      //检索
      shopList = _this.fromShop(data, nowYear, value)
      //赋值
      _this.setDataList(sliceList, shopList)
      
    } else {
      //没值 根据当前年月份来重新赋值 && 拿取原始数据
      _this.selectYear(nowYear)
    }
  },
  /** 店铺查找处理
   *  @params {Array list }    所有的数据源
   *  @params {String nowYear } 当前年份
   *  @params {String value }   当前输入框的值
   *  return Array     当前归类好的数据
   */ 
  fromShop(list, nowYear , value) {
    var _this = this, year, nameCodeString= {},shopMap = [];
    value = value || '';
    if ( list.length ){//数据源不为空
      for( let i = 0 ; i < list.length ; i ++) {
        year = parseInt(list[i].checkoutDate.substring(0, 4));
        if ((list[i].shopName.indexOf(value) != -1 || list[i].shopCd.indexOf(value) != -1) && year == nowYear) {
          if (!nameCodeString[list[i].shopCd]) {
              //相同的店铺code只记录一次最新的，因为降序，不用去比较了,取第一次即可
              shopMap.push({
                shopName:list[i].shopName,
                shopCd: list[i].shopCd ,
                checkoutDate: formData(list[i].checkoutDate,'/',true)
              })
              //默认当前的店铺小票数加1
              nameCodeString[list[i].shopCd] = 1
          } else {
            //后续加1
            nameCodeString[list[i].shopCd]++;
          }
        }
      }
      //count添加进去
      for (let i = 0; i < shopMap.length ; i++ ) {
        let cd = shopMap[i].shopCd;
        shopMap[i].count = nameCodeString[cd];
      }
      var limit = _this.data.endlimitLeft;
      if (shopMap.length > limit ) {
        _this.setData({
          shopOrigin: shopMap,
          endlimitLeft: limit + limit,
          upShowFlg: true
        });
        return shopMap.slice(0, limit)
      }
      _this.setData({
        shopOrigin: shopMap,
        upShowFlg: false
      });
      return shopMap;
    } else { //没查到数据
      return []
    }
  },
  /** 店铺和查询赋值共同处理
   * @params {Array searchTime } 时间查找的内容LIST
   * @params {Array searchShop } 店铺查找的内容LIST
  */
  setDataList(searchTime, searchShop) {
    var _this = this ;
    var flg = searchTime.length ? true : false ;
    _this.setData({
      hasData: flg,
      searchTime: searchTime || [],
      searchShop: searchShop || []
    })
   
  },
  /** 页面初次加载的时候 显示数据
   * @params {Array  copyData } 数据源copy数据
   * **** 此方法默认就走一次  小程序生成的时候
  */
  initListFun(copyData) {
    var _this=this,list = [], shopCd = [], shopList = [];
    //赋值20条 时间查找 
    for (let i = 0; i < copyData.length; i++) {
      var year = parseInt(copyData[i].checkoutDate.substring(0, 4));
      if (getNewsYear == year) { 
        // if (!copyData[i] || list.length >= limit) break;
        copyData[i].realAmt = parseFloat(copyData[i].realAmt).toFixed(2)
        //日期转换 
        copyData[i].fromCheckoutDate = formData(copyData[i].checkoutDate, '/')
        //店铺名字重新构成数组
        shopCd.push(copyData[i].shopName)
        //赋值
        list.push(copyData[i]);
      }
    }
    //
    shopList = _this.fromShop(copyData, _this.data.dateValue, trim(_this.data.inputValue))

    //检索到了 & 赋值
    if (list.length == 0) { //空数组 
      //提示tips 切店铺数据 && 时间查找数据 应该也为空
      _this.setData({
        hasData: false,
        searchTime: [],
        searchShop: [],
        ticketAmount: copyData.length,
      })
    } else {
        //
        var sliceList = '',
          limit = _this.data.endlimitRight;
        if (list.length > limit) { //分页
          _this.setData({
            hasData: true,
            searchTime: list.slice(0, limit),
            searchShop: shopList,
            searchOrigin: list,
            ticketAmount: copyData.length,
            endlimitRight: limit + limit,
            upTimeFlg: true
          })
        } else { //不分页
          _this.setData({
            hasData: true,
            searchTime: list,
            searchShop: shopList,
            ticketAmount: copyData.length,
            searchOrigin: list,
            upTimeFlg: false
          })
        }
    }

  },
  /**  小票头信息取得API
   *   @params { String unionid } API認証キー(必须)
   *   @params { String barcodeNo } バーコードNO(必须)
   *   @params { String barcodePin } バーコードPIN(必须)
   *   @params { String startTime }  所需查询时间段的开始时间 格式: YYYYMMDDHHmmss
   *   @params { String endTime }  所需查询时间段的结束时间 格式: YYYYMMDDHHmmss
   *   @params { Function callback } 成功的回调
   *   @params { Array  localList } 本地的数据
   **/
  getSaleInfo(unionid, startTime, callback, localList ) {
    var _this = this;
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getSaleInfo}`,
      method: 'POST',
      data: {
        unionID:unionid,
        startTime	
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        if( res.data.code == 400) {
          //有缓存进来报错，只掉用一次
          if (localList && localList.length) {
            callback && callback([], localList, startTime)
            _this.setData({ ticketFirst: true })
            return false;
          }
          _this.setData({ ticketFirst: false })
          //报错重试
          var c = ticketCount
          if (c > 1 ) { //重试三次
            ticketCount--
            _this.getSaleInfo(unionid, startTime, callback, localList)
          } else { //三次之后 隐藏load框
            wx.hideLoading()
            _this.ShowErrerTemplate('出错了', '1000', './../../image/icon-3.png')
          }
        } else if( res.data.code == 201 ){ //还不是会员
          _this.setData({ ticketFirst: true })
          callback && callback([])
         
        }else { //成功
          _this.setData({ ticketFirst: true })
          var list = res.data.data.sales;
          //
          callback && callback(list, localList, startTime)
        }
      },
      fail(res) {
        if (localList.length) {
          callback && callback([], localList, startTime)
          return false;
        }
        _this.setData({ ticketFirst: false })
        console.log(res)
        var c = ticketCount
        if (c > 1) { //重试三次
          ticketCount--
          _this.getSaleInfo(unionid, startTime, callback, localList)
        } else { //三次之后 隐藏load框
          wx.hideLoading()
          _this.ShowErrerTemplate('出错了', '1000', './../../image/icon-3.png')
        }
        
      },
      complete() {
        _this.setData({ initTpl: false })
        if (localList.length) {
          callback && callback([], localList, startTime)
          return false;
        }
       
        //结束
       // setTimeout(function () { wx.hideLoading() }, 500)
        
      }
    })
  },
  /**@params 请求出错
  * {@String text } 自定义文言，显示错误的提示语   *必填
  * {@String time } 自定义提示时间，单位毫秒      *必填
  * {@String icon } 自定义icon，显示错误的提示icon  
  */
  ShowErrerTemplate(text, time, icon) {
    var T = parseInt(time) || 0
    var icon = icon || ''
    wx.showToast({
      title: `${text}`,
      icon: 'success',
      image: `${icon}`,
      mask: true,
      duration: T
    })
    //
    setTimeout(() => {
      wx.switchTab({
        url: '/pages/home/home'
      })
    }, T)
  },
})