// pages/lottery_award_list/lottery_award_list.js
const app = getApp()
let nowIndex = '';  //当前点击的按钮标识
Page({

  /**
   * 页面的初始数据
   */
  data: {
      list:[] //获奖一览
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    wx.showLoading({
      title: '加载中',
      mask: true
    })

   this.lotteryAwardList()

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },
  //点击领卡
  getCard(e) {
    console.log('领卡界面')
     let index = e.currentTarget.dataset.index ;
     let json = e.currentTarget.dataset.json;
     nowIndex = index
     this.lotteryGetSign(json, this.addCard)
  },
  /** 获取当前用户中奖一览信息
   *  @params { OBject 获取签名时返回的id } API返回的参数
  */
  lotteryAwardList() {
    console.log(`${app.configApi.baseUrl}${app.configApi.getLotteryList}`)
    let _this =this;
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getLotteryList}`,
      method: 'POST',
      data: {
        unionid: app.unionid,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading()
        console.log(res)
        if (res.data.code == 200) {//成功
          _this.setData({ list : res.data.list});
        } else if (res.data.code == 400) {//出错了
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png',()=>{
            wx.navigateBack({
              delta:1
            })
          })
        }
      },
      fail(err) {
        wx.hideLoading()
        _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png',() => {
          wx.switchTab({
            url: '/pages/home/home'
          })
        })
      }
    })
  },
  /** 更新领卡接口  不接收回调，直接发送请求
   *  @params { OBject 获取签名时返回的id } API返回的参数
  */
  lotteryUpdateAward(id) {//过个几秒在消失 并且按钮重置变为不可点击状态
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    var arr = this.data.list;
    arr[nowIndex].receiveFlag = 1
    this.setData({ list: arr})
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getLotteryUpdate}`,
      method: 'POST',
      data: {
        unionid: app.unionid,
        id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success() {

      }
    })
    setTimeout( () => {
      wx.hideLoading()
    } ,1500 )
  },
  /** 获取当前卡code的签名
   *  @params { OBject res } API返回的参数
   *  @params { Func callbakc } 成功的回调
  */
  lotteryGetSign(data, callbakc) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    var _this = this;
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getLotterySign}`,
      method: 'POST',
      data: {
        unionid: app.unionid,
        id: data.id,
        level: data.prizeLevel,
        code: data.couponNo
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data.code == 200) {
          res.data.id = data.id
          callbakc && callbakc(res.data)
        } else {
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        }
      },
      fail() {
        _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
      },
      complete() { //完成
        wx.hideLoading()
      }
    })
  },
  /* 添加卡券
  * @params {Object data} 打开领卡界面的参数
  */
  addCard(data) {
    var _this = this;
    wx.addCard({
      cardList: [{
        cardId: data.cardId,
        cardExt: JSON.stringify(data.cardext)
      }],
      success: function (res) {
        console.log(res)
        if (res.cardList[0].isSuccess && res.cardList[0].code) {
          _this.lotteryUpdateAward(data.id);
        } else {
          //失败
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        }
      },
      fail(res) {
        if (!res.errMsg == 'addCard:fail cancel') {
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        }
      }
    })
  },
  /**@params 请求出错，跳转index首页
 * {@String text } 自定义文言，显示错误的提示语   *必填
 * {@String time } 自定义提示时间，单位毫秒      *必填
 * {@String icon } 自定义icon，显示错误的提示icon  
 * {@Function callback } 回调函数
 */
  ShowErrerTemplate(text, time, icon,callback) {
    var T = parseInt(time) || 0
    var icon = icon || ''
    wx.showToast({
      title: '出错了',
      icon: 'success',
      image: `${icon}`,
      mask: true,
      duration: T
    })
    if (callback ) {
      setTimeout( () => {
        callback()
      }, T)
    }
  },
})