import { trim, formData1, payName } from './../../../utils/util'
var barcode = require('./../../../utils/barcode')
//获取应用实例
const app = getApp()
let timer = null //定时器
// pages/ticket/shopDetail/shop_detail.js
//支付方式(必须) 01：内卡；02：外卡；03：支付宝；04：微信；05：抵用券；06：银行入金；07：储值卡；08：现金 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    paramsJson:[] , //上个界面传递的值
    SaleInfoDetail: [], //销售明细信息
    canvasWidth:'',
    canvasHeight5:'',
    SaleDynamicInfo:{}, //商家相关信息
    screenBrightPercent:'', //默认屏幕的亮度值
    isGetBright : false, //点击仍和区域亮度还原，防止获取失败，默认加此flg 
    isFirst:true, //是否第一次点击高亮
    itemIds: [], //小票内商品的ID
    specialItemIds1:[],
    specialItemIds2:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    var _this = this;
    var params = JSON.parse(options.params)
    params.fromCheckoutDate = formData1(params.checkoutDate,'-')
    params.payNames[0].fromPayName = payName[params.payNames[0].payName]
    _this.setData({ paramsJson: params })
    //设置Canvas的一些宽度
    var w = this.windowSize(40,40);
    this.setData({ 
      canvasWidth:w.w + 'px',
      canvasHeight:w.h + 'px'
    })
    this.barc('barcode', params.saleId, w.w, w.h,20);
    //拉区API信息
    this.getSaleInfoDetail( params.saleId, params.shopCd, _this.getSaleDynamicInfo )
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function (options) {
    
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log('页面隐藏')
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log('页面卸载')
    //当用户高亮屏幕的时候，退出即可还原高亮
    var _this = this;
    var v = _this.data.screenBrightPercent;
    clearTimeout(timer); //清空定时器
    if (v) {
      _this.setScreenBright(v)
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },
  /**
   * 返回上一页
   */ 
  go_back() {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   *  显示页面
   */ 
  ruleHtml() {
    wx.navigateTo({
      url: `./../../webview/webview?ruleHtml=true`
    })
  },
 
  /**
   *  生成条形码 
  */
  barc(id, code, width, height, padding) {
    barcode.code128(wx.createCanvasContext(id), code, width, height, padding)
  },
  /**  获取屏幕的宽高
   *   @params { String 需要减去的宽度 }  屏幕宽度的百分比
   *   @params { String 需要显示的高度 }  屏幕高度的百分比
   */ 
  windowSize(wprecent, hprecent) {
    var win = wx.getSystemInfoSync();
    // return {
    //   w: Math.round(win.windowWidth * wprecent),
    //   h: Math.round(win.windowHeight * hprecent)
    // }
    return {
      w: Math.round(win.windowWidth - wprecent),
      h:  hprecent
    }
  },
  /** 小票动态信息取得API 礼品。已开发票。退货。根据NEC的sale_flag判断 
   *  @params {String saleId }  销售单号(必须)
   *  @params {Array itemIds }  小票内商品jan list(必须)
   *  @params {String shopCd }  店铺code(必须)
   **/ 
  getSaleDynamicInfo( saleId, itemIds, shopCd) {
    var _this = this;
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getSaleDynamicInfo}`,
      method:'POST',
      data: {
        saleId,
        itemIds,
        shopCd
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        if( res.data.code == 400) {
          console.log('出错了')
        } else {
          var obj = res.data.data;
          //obj.flagType = [0,1,2]
          var a = {} , b = {} ;
          for (var i = 0; i < itemIds.length ; i ++) {
            for (let h = 0; h < obj.specialItemIds1.length ; h++){
              if (obj.specialItemIds1[h] == itemIds[i] ){
                a[i] = i + ''
                break;
                //匹配到即可退出循环
              }
            }
            for (let g = 0; g < obj.specialItemIds2.length; g++) {
              if (obj.specialItemIds2[g] == itemIds[i]) {
                b[i] = i + ''
                break;
                //匹配到即可退出循环
              }
            }
          }
          _this.setData({ 
            SaleDynamicInfo: obj,
            specialItemIds1:a,
            specialItemIds2:b
          });
        }
      },
      fail(res) {

        console.log(res)
        _this.ShowErrerTemplate('出错了', '2000', './../../../image/icon-3.png')
      }
    })
  },
  /** 小票明细信息取得API 中的商品ID/商品名称/购入件数/
销售价格/打折率.
   * 印章图片 == 此商品恕不退换/此商品已检查/ getSaleDynamicInfo动态获取
   * 店铺地址和电话    getSaleDynamicInfo动态获取
   *  @params {String saleId } 销售单号(必须)
   *  @params {String shopCd } 店铺code(必须)
   *  @params {Function callback } 调用成功的回调
  */
  getSaleInfoDetail( saleId, shopCd ,callback) {
    var _this = this ;
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getSaleInfoDetail}?saleId=${saleId}`,
      method: 'GET',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        if( res.data.code == 400) {
          _this.ShowErrerTemplate('出错了', '2000', './../../../image/icon-3.png')
        } else {
          var list = res.data.data.items
          var itemIds = list.map((e) => {
            if (e.itemId) return e.itemId;
          })
          _this.setData({ 
              SaleInfoDetail: list,
              itemIds
          })
          callback && callback(saleId, itemIds, shopCd)
          setTimeout(() => {
            wx.hideLoading()
          }, 500)
        }
       
      },
      fail(res) {
        console.log(res)
        _this.ShowErrerTemplate('出错了', '2000', './../../../image/icon-3.png')
        
      }
    })
  },
  /**@params 请求出错
  * {@String text } 自定义文言，显示错误的提示语   *必填
  * {@String time } 自定义提示时间，单位毫秒      *必填
  * {@String icon } 自定义icon，显示错误的提示icon  
  */
  ShowErrerTemplate(text, time, icon) {
    var T = parseInt(time) || 0
    var icon = icon || ''
    wx.showToast({
      title: `${text}`,
      icon: 'success',
      image: `${icon}`,
      mask: true,
      duration: T
    })
  },
  /** 点击条形码  屏幕高亮 默认为1
   *  @params { String value} 屏幕设置的高度值
   **/ 
  setScreenBright(value) {
    var _this = this ;
    var value = value || _this.data.screenBrightPercent ;
    console.log('高亮的值' + value)
    wx.setScreenBrightness({
      value:value,
      success(){
        console.log( '高亮成功')
        clearTimeout(timer);
        _this.setTime();
      },
      fail() {
        clearTimeout(timer);
      },
      complete() {
        _this.setData({ isGetBright: false })
      }
    })
  },
  /** 得到屏幕的高度
   *  @params { Function callback }  获取屏幕亮度成功的回调
   * */ 
  getScreenBright(callback ){
    var _this = this ;
    wx.getScreenBrightness({
      success(e) {
        var v = parseFloat(e.value).toFixed('5');
        _this.setData({ screenBrightPercent: v})
        callback && callback(1,true)
      }
    })
  },
  /** 点击条形码页方法
   *   
   **/
  screenBright() { //
    var _this = this ; 
    if (_this.data.isGetBright ) return false;
    _this.setData({ isGetBright: true });
    clearTimeout(timer); //清空定时器
    if( _this.data.isFirst ) { //第一次
      this.setData({ isFirst: false})
      this.getScreenBright( _this.setScreenBright );
    } else { //第二次以上
      this.setScreenBright(1)
    }
  },
  setTime() {
    var _this = this;
    timer = setTimeout(_this.setScreenBright,5000)
  }
  
})