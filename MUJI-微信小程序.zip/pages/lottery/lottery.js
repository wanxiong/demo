// pages/lottery/lottery.js
import { leng, required, validate } from '../../utils/util';
const app = getApp()
let AnimFrame = null;
let rotateCount = 6;//转动的圈数
let eleCount = 6;//物品的总个数
let status = 0;
let stop = null;
let handelObj = null;
let i = 0;
let that = null
let lotteryTime = 300 //转动时间
let lotteryTimer = null //定时器
let canUrlLink = true //能否点击获奖记录和活动详情的flg
let awardListData = {
  "1":"0",
  "2":"5",
  "3":"3",
  "4":"2",
  "5":"1",
  "6":"4",
} //中奖对应的下标 顺时针
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url: 'pages/lottery/lottery', //当前页面的url
    rotate: '0deg',
    btnImage: {},
    lotteryValue: "0",
    lotteryName: "1",
    isShow:false,   //抽奖显示flg
    awardIsShow: false,  //中奖显示flg
    isTipsBoolText:"", //提示文言
    isTipsBool:false, //是否显示提示框
    value:'', //输入码的值
    isLoading:false,  //显示loading 层
    awardData:{},   //API返回抽奖码的数据
    lotteryFirst: false ,//第一次进入
    awardText:'恭喜您获得' //用户获奖之后的页面文言
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.popUpLottery = this.selectComponent(".changeAward");
    this.popUpGetAward = this.selectComponent(".getAward");
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this
    app.cardIsFirst = false
    if (!app.hasAuthorization) {
      wx.showModal({
        title: '提示',
        content: '由于您暂未授权，此功能暂未对您开放,如需重新授权，需在微信【发现】——【小程序】——删掉【无印良品MUJI】，重新搜索授权登录，方可使用',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            if (_this.data.url == getCurrentPages()[0].route) {
              //点击确定 不点导航tabbar时跳转pages/home/home月面
             // console.log('点击确定')
              wx.switchTab({
                url: '/pages/home/home',
              })
            } else {
            //  console.log('点击tabbar')
            }
            //点击tabbar直接切换走，不点击确定按钮时候
          } else {
            wx.switchTab({
              url: '/pages/home/home',
            })
          }
        }
      })
    } else {

      if (_this.data.lotteryFirst) return;
      var inter = null, countT = 1;
      _this.setData({ lotteryFirst: true})
      wx.showLoading({
        title: '加载中',
        mask:true,
      })
      inter = () => { //定时器方法
        countT++
        if (app.unionid) {
          clearInterval(lotteryTimer)
          wx.hideLoading()
        } else {
          if (countT > 100) {
            //还没拿到，应该重新去啦API啦，我就当这样默认了，
            wx.hideLoading()
            wx.showToast({
              title: '出错了，请重试',
              icon: 'success',
              image: './../../image/icon-3.png',
              mask: true,
              duration: 1000
            })
            clearInterval(lotteryTimer)
            setTimeout(() => {
              wx.switchTab({
                url: '/pages/home/home'
              })
            }, 1000)
          }
        }
      }
      //
      lotteryTimer = setInterval(inter, 100)
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    //清楚多余的定时器
    clearInterval(lotteryTimer)
    this.setData({ lotteryFirst: false })
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },
  //抽奖转盘完成的回调  参数重置
  lotteryEnd() {
    //console.log('转盘完成')
    //中奖文言显示
    //显示中奖结果，
    this.popUpGetAward.openBox()
    canUrlLink = true //按钮恢复可点击状态
  },
  //唤醒抽奖界面
  start(event) {
    if (!app.unionid ) return ;
    this.popUpLottery.openBox()
  },
  //
  toDo() {
    var s = that.bseBase(handelObj.p0, handelObj.p1, handelObj.p2, handelObj.p3, i / lotteryTime).y;
    that.setData({ rotate: `${s * 10}deg` })
    if (i < lotteryTime) {
      i++;
    } else {
      status = 0;
      that.lotteryEnd()
      return false;
    }
    stop = AnimFrame(that.toDo)
  },
  //
  rand(value, name) {
    //贝塞尔控制点 p2 p3 控制速度
    var ele = value;
    var eleName = name;
    var jiaodu = (rotateCount * 360) + 360 + (ele) * (360 / eleCount)
    var p0 = { x: 0, y: 0, name: 'p0' }
    var p1 = { x: 300, y: 33, name: 'p1' }
    var p2 = { x: 0, y: jiaodu /10, name: 'p2' }
    var p3 = { x: 600, y: jiaodu / 10, name: 'p3' }
    return { p0, p1, p2, p3, eleName }
  },
  //
  bseBase(p0, p1, p2, p3, t) {
    var x = p0.x * (1 - t) * (1 - t) * (1 - t) + p1.x * 3 * t * (1 - t) * (1 - t) + p2.x * 3 * t * t * (1 - t) + p3.x * t * t * t;
    var y = p0.y * (1 - t) * (1 - t) * (1 - t) + p1.y * 3 * t * (1 - t) * (1 - t) + p2.y * 3 * t * t * (1 - t) + p3.y * t * t * t;
    return { x: x, y: y }
  },
  clear() {
    if (cancelAnimationFrame) {
      cancelAnimationFrame(stop);//可以取消该次动画。
    }
    if (stop) {
      clearTimeout(stop)
    }
    this.setData({ rotate: '0deg' })
    stop = null;
    i = 0;
  },
  //序列帧
  requestAnimFrame() {
//requestAnimationFrame ||
    return function (callback) {
        setTimeout(callback, 1000 / 60);
      };
    
  },
  // 输入框输入 点击键盘完成建触发的方法
  inputConfirm() {

  },
  // 中奖纪录点击去 一栏
  go_award_list() {
    if (!app.unionid) return;
    if (!canUrlLink) return false;
    wx.navigateTo({
      url: './../lottery_award_list/lottery_award_list',
    })
  },
  //去活动详情界面
  go_detail() {
    if (!app.unionid) return;
    if (!canUrlLink ) return false;
    wx.navigateTo({
      url: '../lottery_detail/lottery_detail'
    })
  },
  //popup被关闭的监听出
  closePop() {
    //console.log('我监听到关闭啦')
  },
  //暂不兑换
  reset() {
    //console.log('暂不兑换')
    this.setData({ value : ''})
    this.popUpLottery.hideBox()
  },
  //立即抽奖
  startAward() {
    //console.log('立即抽奖')
    if ( !canUrlLink) return false;
    if (!app.unionid) return;
    let v = this.data.value;
    console.log(v)
    if ( !required(v) ) {//为空
      this.setData({ isTipsBoolText: "请输入6位数的抽奖码", isTipsBool: true})
      this.closeToast(1000)
      return 
    }
    if ( !leng(v, 6) ) { //长度不够6位
      this.setData({ isTipsBoolText: "请输入6位数的抽奖码", isTipsBool: true })
      this.closeToast(1000)
      return 
    }
    if (!validate(v) ) { //数字和英文组合
      this.setData({ isTipsBoolText: "请输入正确格式的抽奖码", isTipsBool: true })
      this.closeToast(1000)
      return 
    }
    //发起请求
    this.lotteryRequest(v)
  },
  maxStartPla() {

  },
  //中奖成功 开始转动转盘
  animaEnd() {
    that = this;
    this.setData({ rotate: '0deg', value: '' })
    i = 0;
    canUrlLink = false //运动期间不可点击外部链接按钮
    var value = awardListData[this.data.awardData.userPrize.prizeLevel]
    var name = `恭喜您获得${this.data.awardData.userPrize.name}`
    this.setData({ awardText:name})
    AnimFrame = this.requestAnimFrame()
    handelObj = this.rand(value, name);
    this.toDo()
  },
  /* toast 关闭弹出层
  * @params { Number timer } 时间
  */
  closeToast(timer) {
    setTimeout( () => {
      this.setData({ isTipsBool: false })
    } , timer)
  },
  //输入框变更时，同步记录 ，不用form表单来提交
  changeInput(e) {
    this.setData({value: e.detail.value})
  },
  //唤醒中奖pop展示页面
  openGetAward() {

  },
  //立即领取
  getCard() {
    //发请求打开微信领卡界面 //成功之后关闭页面
   // console.log( '立即领取')
    //this.popUpGetAward.hideBox()
    //调用API去拿取签名，去微信端领卡
    this.lotteryGetSign(this.data.awardData.userPrize, this.addCard);
  },
  //返回首页  reset_two popup2 中奖显示界面
  reset_two() {
    //console.log('返回首页')
    this.popUpGetAward.hideBox()
  },
  /* 请求API 去抽奖
  *  @params {String code } 对应抽奖的code码
  */
  lotteryRequest(code) {
    this.setData({ isLoading: true });
    var _this = this ;
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getLotterySelect}`,
      method: 'POST',
      data: {
        prizeVoucherNo: code,
        unionid: app.unionid,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) { //成功400 错误 300已抽过 200 成功 404 未找到 301 请重试
        _this.setData({ isLoading: false });
        if( res.data.code == 200 ) { //领取成功
          _this.setData({ awardData: res.data })
          _this.popUpLottery.hideBox(_this.animaEnd)
        } else if (res.data.code == 300){ //已经领取过
          _this.setData({ isTipsBoolText: "您已经参与过抽奖了", isTipsBool: true })
          _this.closeToast(1000)
        } else if (res.data.code == 301  ) { //请重试
          _this.setData({ isTipsBoolText: "系统繁忙，请重试", isTipsBool: true })
          _this.closeToast(1000)
        } else if (res.data.code == 400) { //请重试
          _this.setData({ isTipsBoolText: "系统繁忙", isTipsBool: true })
        } else if (res.data.code == 404 ) { //抽奖号码不存在
          _this.setData({ isTipsBoolText: "无效的抽奖兑换码", isTipsBool: true })
          _this.closeToast(1000)
        }
      },
      fail() { //网络错误
        _this.setData({ isLoading: false });
        _this.setData({ isTipsBoolText: "出错了，请重试", isTipsBool: true })
        _this.closeToast(1000)
      },
      // complete() { //完成
      //   _this.setData({ isLoading: false });
      // }
    })
  },
  /** 更新领卡接口  不接收回调，直接发送请求
   *  @params { OBject 获取签名时返回的id } API返回的参数
  */
  lotteryUpdateAward(id) {
    this.reset_two();
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getLotteryUpdate}`,
      method: 'POST',
      data: {
        unionid: app.unionid,
        id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(data) {
      }
    })
    setTimeout( ()=> {
      this.setData({ isLoading: false });
    } ,1500)
  },
  /** 获取当前卡code的签名
   *  @params { OBject res } API返回的参数
   *  @params { Func callbakc } 成功的回调
  */
  lotteryGetSign(data, callbakc) {
    this.setData({ isLoading: true });
    var _this = this;
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getLotterySign}`,
      method: 'POST',
      data: {
        unionid: app.unionid,
        id: data.id,
        level: data.prizeLevel,
        code: data.couponNo
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if( res.data.code == 200 ) {
          res.data.id = data.id
          callbakc && callbakc(res.data)
        } else {
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        }
      },
      fail() {
        _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
      },
      complete() { //完成
        _this.setData({ isLoading: false });
      }
    })
  },
  /* 添加卡券
  * @params {Object data} 打开领卡界面的参数
  */
  addCard(data) {
    var _this = this;

    wx.addCard({
      cardList: [{
        cardId: data.cardId,
        cardExt: JSON.stringify(data.cardext)
      }],
      success: function (res) {
        if (res.cardList[0].isSuccess && res.cardList[0].code) {
          _this.setData({ isLoading: true });
          _this.lotteryUpdateAward(data.id);
        } else {
          //失败
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        }
      },
      fail(res) {
        if (!res.errMsg == 'addCard:fail cancel') {
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        }
        

      }
    })
  },
  /**@params 请求出错，跳转index首页
 * {@String text } 自定义文言，显示错误的提示语   *必填
 * {@String time } 自定义提示时间，单位毫秒      *必填
 * {@String icon } 自定义icon，显示错误的提示icon  
 */
  ShowErrerTemplate(text, time, icon) {
    var T = parseInt(time) || 0
    var icon = icon || ''
    wx.showToast({
      title: '出错了',
      icon: 'success',
      image: `${icon}`,
      mask: true,
      duration: T
    })

  },
})