

# 不同小程序对应的appid请重置，此处保存的appid为teamLab小程序id  

# 卡券功能需要用到appid,针对不同小程序,需要此功能者,请手动更改app.js中appId字段

# https://wechat.muji.com.cn 	MUJI-API-域名

# https://20160829.team-lab.cn  TeamLab-API-域名

# 外链 web-view , 业务域名指向 https://passport.muji.com.cn/,外链都是微信公众号那边代码转成html文件，里面部分A链接跳转是没有配置业务域名的，所以里面A链接所有二次跳转的链接，统一js代码禁止跳转即可

# 所有外链公众号的链接，默认CSV去转 【 http://192.168.1.8/documents/2819 】 wiki文档 *** 和支付宝的一样 ***


# 20180316 最近提交记录

	# 对应的小票功能是在stg分支直接提交发布的，代码有合并到master分支，如master有问题，请移至stg分支