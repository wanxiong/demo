export var imgUrl = 'http://jiu.dxcqp.com/'
export var uploadUrl = 'http://jiu.dxcqp.com:8089/'
export var downloadUrl = 'http://jiu.dxcqp.com:8089/'

