Page({
  data: {
    dataItem:[
      
    ],
    selectActiveClass:null , //当前选中的日期index索引
    year:'',
    nowActive:false ,//当前天 选中的样式
    month:'',
    dayName: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
    dataLen:42  //默认最大6组 每组 7个  = 42
  },
  /**
* 生命周期函数--监听页面初次渲染完成
*/
  onReady: function () {
    
    this.initDate()
  },
  /**
	   * 日期转化为字符串， 4位年+2位月+2位日
	   */
	  getDateStr(date) {
    var _year = date.getFullYear();
    var _month = date.getMonth() + 1;    // 月从0开始计数
    var _d = date.getDate();
	     
    _month = (_month > 9) ? ("" + _month) : ("0" + _month);
    _d = (_d > 9) ? ("" + _d) : ("0" + _d);
    return _year + _month + _d;
  },
  //
  changeDate(e) {
    console.log(e)
    console.log('当前时间~~~' + e.currentTarget.dataset.yyyy.YYYYMMDD)
    var index = e.currentTarget.dataset.index
    e.currentTarget.dataset.index = 66
    this.setData({
      selectActiveClass : index
    })
  },
  nexMonth() {
    var month = this.data.month + 1;
    var year = this.data.year;
    if( month > 12 ){
      year = year - 0+ 1;
      month = 1
    }
    this.setData({
      month,
      year,
      selectActiveClass:null
    })
    
    //画面日期重构
    this.initDate({
      year,
      month
    })
  },
  /*@params options 参数
  * String { year }   当前日期的年份 默认非必须
  * String { month }  当前日期的月份 默认非必须
  *  year && month  同时存在
  **/
  initDate(options) {
    var options = options || {};
    var d1 = new Date();  // 获取当前系统时间 我现在的时间是 2016年4月25日 星期一
    var _year = options.year || d1.getFullYear();    // 获取年信息
    var _month =  options.month || d1.getMonth() + 1;      // 获取月信息（从0开始 范围：0-11）
    var _day = d1.getDate();      // 获取天信息 此处结果：25
    var dataCopy = []
    var _firstDay = new Date(_year, _month - 1, 1);  // 当前月第一天
    var _firstDayWeek = _firstDay.getDay()//星期几  0- 6
    var _firstDayStr = this.getDateStr(_firstDay)
    this.setData({
      year: _firstDayStr.substr(0, 4),
      month: _month
    })
    var showTop = _firstDayWeek == '0' ? -6 : 1
    for (let i = 0; i < this.data.dataLen; i++) {
      var _thisDay = new Date(_year, _month - 1, i + showTop - _firstDayWeek )
      var _thisDayStr = this.getDateStr(_thisDay)
      if (_thisDayStr.substr(0, 6) == _firstDayStr.substr(0, 6)) {
   
        //当前月份
        dataCopy.push({
          day: _thisDay.getDate(),
          YYYYMMDD: _thisDayStr,
          click: true
        })
    
      } else {
        //上个月 或者上一年
        dataCopy.push({
          day: _thisDay.getDate(),
          YYYYMMDD: _thisDayStr,
          click: false
        })
      }

    }
    this.setData({ dataItem: dataCopy })
  }
  
    
})