 
 let filters = {
 	input : val => {
 		console.log('input')
 	},
 	clear : val => {
 		console.log('input')
 	}
 }
 
 export default filters