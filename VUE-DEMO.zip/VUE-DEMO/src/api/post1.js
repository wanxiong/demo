import axios from './require-post'

// QQ音乐的接口，存在域名拦截     https://c.y.qq.com/splcloud/fcgi-bin/fcg_get_diss_by_tag.fcg
// QQ音乐的接口，存在域名拦截     https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg

export const loginAPi = (params) => {
	let url = 'http://20150915.team-lab.cn/api/darwin_login.do'
	return axios.post(url,params).then((res) =>{
		return Promise.resolve(res)
	}).catch((respone) => {
		console.log(respone)
	})
}



