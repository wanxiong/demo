<template>
	<div>
		恭喜你来到登录页面
	</div>
</template>
<script type="text/javascript"></script>
<style type="text/css">
	div{
		font-size: 30px;
		text-align: center;
	}
</style>