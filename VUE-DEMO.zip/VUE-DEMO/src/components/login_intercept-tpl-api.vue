<template>
	<div>
		<div class="tit">api请求案例</div>
		<button @click="test()">测试1</button>
	</div>
</template>
<script type="text/javascript">
	import {loginAPi } from '@/api/post1'
	export default {
		data () {
			return {

			}
		},
		methods:{
			test() {
				let params = {
					"mobilephone":"13851111121",
					"password":"1111",
					"device":"1",
					"isPcFlag":true,
					"countryCd":"86",
					"authCd":"ba7905e37cb4cb6290f595e66a304fa2",
				}
				loginAPi(params).then(res => {
					console.log(res)
				})
			}
		}
	}
</script>
<style type="text/css">
	.tit{text-align: center;font-size: 30px;}
</style>