<template>
	<div class="tabs">
		 <router-link tag="span" class="tab-item" to="/validator">
		 	表单验证的案例
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/proxyTable">
		 	本地跨域的案例
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/login_intercept">
		 	登录拦截登出功能的案例-路由拦截
		 </router-link>
		 <router-link tag="span" class="tab-item" to="/login_intercept_api">
		 	API请求拦截设置
		 </router-link>
	</div>
</template>
<script type="text/javascript">
	
</script>
<style type="text/css">
	.tabs span{
		margin: 0 30px;
		cursor: pointer;
		border-bottom: 1px solid red;
	}
</style>