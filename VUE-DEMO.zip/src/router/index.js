import Vue from 'vue'
import Router from 'vue-router'
import change from '@/components/change'   
import validator from '@/components/validator-tpl'   
import proxyTable from '@/components/proxyTable-tpl'   
import login_intercept from '@/components/login_intercept-tpl'   
import login_interceptA from '@/components/login_intercept-tpl-A'   
import login_interceptB from '@/components/login_intercept-tpl-B'   
import login_intercept_login from '@/components/login_intercept-tpl-login'   
import login_intercept_api from '@/components/login_intercept-tpl-api'   
import LOGIN from '@/components/login'   
import swiperTemplate from '@/components/swiper_tpl'   
import lazyloadTemplate from '@/components/lazyload_tpl'   
import waterfallTemplate from '@/components/waterfall-tpl'   
import infiniteTemplate from '@/components/infinite-scroll'
import transitionTemplate from '@/components/transition-tpl'
import transitionGroupTemplate from '@/components/transition-group-tpl'
import transitionAnimateTemplate from '@/components/transition-animate-tpl'
import vuexTemplate from '@/components/vuex-demo-tpl'
import vuexTemplateOk from '@/components/vuex-demo-ok'
import componentTemplate from '@/components/component-tpl'
Vue.use(Router)

const router =  new Router({
  routes: [
  	{
      path: '/',
      name: 'change',
      component: change
    },
    {
      path: '/validator',
      name: 'validator',
      component: validator
    },
    {
      path: '/proxyTable',
      name: 'proxyTable',
      component: proxyTable
    },
    {
      path: '/login_intercept',
      name: 'login_intercept',
      component: login_intercept,
      children:[{
        path: '/login_intercept/A',
        name: 'login_intercept_A',
        meta:{
            isAuth:false
        },
        component: login_interceptA
      },{
        path: '/login_intercept/B',
        name: 'login_intercept_B',
        meta:{
            isAuth:false
        },
        component: login_interceptB
      },{
        path: '/login_intercept/login',
        name: 'login_intercept_login',
        meta:{
            isAuth:true
        },
        component: login_intercept_login
      }]
    },
    {
      path: '/login_intercept_api',
      name: 'login_intercept_api',
      component: login_intercept_api
      
    },
    {
      path: '/login',
      name: 'login',
      component: LOGIN
      
    },{
      path: '/vue-swiper',
      name: 'vue-swiper',
      component: swiperTemplate
    },{
      path: '/vue-lazyload',
      name: 'vue-lazyload',
      component: lazyloadTemplate
    },{
      path: '/vue-waterfall',
      name: 'vue-waterfall',
      component: waterfallTemplate
    },{
      path: '/vue-infinite-scroll',
      name: 'vue-infinite-scroll',
      component: infiniteTemplate
    },{
      path:'/vue-transition',
      name:'vue-transition',
      component: transitionTemplate
    },{
      path:'/vue-transition-animate',
      name:'vue-transition-animate',
      component: transitionAnimateTemplate
    },{
      path:'/vue-transition-group',
      name:'vue-transition-group',
      component: transitionGroupTemplate
   },{
    path:'/vuex',
    name:'vuex',
    component:vuexTemplate,
    children:[{
       path:'/vuex/ok',
       name:'vuex/ok',
       component:vuexTemplateOk
    }]
   },{
    path:'/add-component',
    name:'加载组件例子',
    component:componentTemplate
    
   }
    
    
  ]
})

/**
* to          即将要进入的目标 路由对象
* from        当前导航正要离开的路由
* next()      进行管道中的下一个钩子。如果全部钩子执行完了，则导航的状态就是 confirmed （确认的）。
* next(false) 中断当前的导航。如果浏览器的 URL 改变了（可能是用户手动或者浏览器后退按钮），那么 URL 地址会重置到 from 路由对应的地址。
* next('/')   或者 next({ path: '/' }): 跳转到一个不同的地址。当前的导航被中断，然后进行一个新的导航。
*/

router.beforeEach((to, from, next) => {//建议cookie判断是否登录状态
  if (to.meta.isAuth) {  // 判断该路由是否需要登录权限
        // next({
        //     path: '/login',
        //     query: {redirect: to.fullPath}  // 将跳转的路由path作为参数，登录成功后跳转到该路由
        // })
        //next()
        alert('你已经没有权限了，重新登录吧')
        next({
            path: '/login'
              // 将跳转的路由path作为参数，登录成功后跳转到该路由
        })
    }
    else {
        next()
    }
})

export default router;