<template>
	<div>
		<div>hello vincentwan </div>
		<transition-group tag="div" enter-active-class="animated " leave-active-class="animated bounceOut">
            <p v-show="show" class="bounceInDown" :key="1">haha</p>
            <p v-show="show" class="bounceInDown" :key="2">hihi</p>
        </transition-group>
        <button @click="show=!show">transition</button>
	</div>
</template>

<script type="text/javascript">
	import '@/assets/style/animate.css'
	export default {
		data() {
			return {
				show:false
			}
		}
	}
</script>
<style type="text/css" lang="scss">
	
</style>