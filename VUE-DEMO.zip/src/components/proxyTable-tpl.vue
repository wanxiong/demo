<template>
	<div>
		<span @click="one">发送请求splcloud/fcgi-bin/fcg_get_diss_by_tag.fcg'</span>
		</br>
		<span @click="two">发送请求lyric/fcgi-bin/fcg_query_lyric_new.fcg</span>
		</br>
		<span @click="token">发送请求getToken</span>
	</div>
</template>
<script type="text/javascript">
	import {testAjaxPostOne , testAjaxPostTwo , getToken} from '@/api/post'
	export default {
		data () {
			return {

			}
		},
		methods : {
			token() {
				getToken().then(res => {
					console.log(res)
				})
			},
			one() {
				testAjaxPostOne().then(res => {
					console.log(res)
				})
			},
			two() {
				testAjaxPostTwo().then(res => {
					console.log(res)
				})
			}
		}
	}
</script>
<style type="text/css">
	span{
		text-align: left;
		display: inline-block;
		line-height: 30px;
		width: 500px;
	}
</style>