<template>
	<div>
		<div>
			<input class="name" v-model="Name" type="text" name="" placeholder="请输入你的名字" value='name'>
		</div>
		<br>
		<div>
			<input class="age" type="text" v-model="Age" name="" placeholder="请输入你的年龄" value="age">
		</div>
		<br>
		<div>
			<button @click="saveParams">确认保存</button>
		</div>
		<router-view class="box" ></router-view>
	</div>
</template>
<script type="text/javascript">
	import {mapState , mapActions} from 'vuex'
	export default {
		data (){
			return {
				Name:'',
				Age:''
			}
		},
		created() {
			let _this = this
			_this.Name = _this.name
			_this.Age = _this.age
			
		},
		computed:{
			...mapState([
				'name',
				'age',
			])
		},
		methods:{
			saveParams() {
				console.log(name)
				let exp = /(^\s*)|(\s*$)/g
				let n = this.Name.replace(exp, "")
				let a = this.Age.replace(exp, "")
				if(n == '') {
					alert(`请输入你的名字` );
					return 
				}
				if(a == '') {
					alert(`请输入你的年龄` );
					return 
				}
				this.saveVuex(n, a)
			},
			saveVuex (name,age) {
				let data = {
					name,
					age,
					callback:this.goSucPage
				}
				this.setName(data)
				this.setAge(data)
			},
			goSucPage () {
				this.$router.push({path:'/vuex/ok'})
			},
			...mapActions([
				'setName',
				'setAge'
			])

		},
		watch: {
      		name(now, old) {
      			console.log(`new===${now}====old${old}`)
      		},
      		age(now, old) {

      		}
		}
	}
</script>
<style type="text/css" lang="scss">
	.name,.age{
		text-indent: 10px;
	}
	.box{
		position: absolute;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		background-color: #fff;
	}
</style>
