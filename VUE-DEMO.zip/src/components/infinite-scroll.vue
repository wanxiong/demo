<template>
	<div class="infinite-scroll">
		<div >infinite-scroll</div>
		<div class="item-box" v-infinite-scroll="loadMore" infinite-scroll-disabled="busy" infinite-scroll-distance="disY">
		  <div class="item" v-for="item in data">{{item}}</div>
		</div>
		<div v-show="loadFlg" class="modal">玩命加载中</div>
	</div>
</template>
<script type="text/javascript">
	import Vue from 'vue'
	import infiniteScroll from 'vue-infinite-scroll'   //API请转移至 https://www.npmjs.com/package/vue-infinite-scroll
	Vue.use(infiniteScroll) //注入
	/*nfinite-scroll-disabled	如果该属性的值为true，则将禁用无限滚动。
	infinite-scroll-distance	
			数字(默认值= 0)——在执行v -infinite- scroll方法之前，元素底部和viewport底部之间的最小距离。
	infinite-scroll-immediate-check	
		布尔值(默认值= true)表示该指令应该在绑定后立即检查。如果可能，内容不够高，不足以填满可滚动的容器。
	infinite-scroll-listen-for-event	当事件在Vue实例中发出时，无限滚动将再次检查。
	infinite-scroll-throttle-delay	下次检查和这次检查之间的间隔(默认值= 200)*/
	export default {
		data() {
			return {
				busy:false,
				disY:10, //距离底部多少是开始出发函数
				data:[],
				x:0,
				loadFlg:false
			}
		},
		methods:{
			loadMore() {
				this.busy = true
				this.loadFlg =true
				for(let i = 0 ; i < 10 ; i ++){
					this.data.push(this.x++)
				}
				setTimeout(() =>{
					this.busy = false
					this.loadFlg =false
				},2000)
				console.log('加载更多')
			}
		},
		created() {
			for(let i = 0 ; i < 10 ; i ++){
				this.data.push(this.x++)
			}
			
		}
	}
</script>
<style type="text/css" lang="scss">
	.infinite-scroll{
		> div:nth-of-type(1){
			font-size: 30px;
			text-align: center;
		}
	}
	.item-box{
		height: 200px;
		border: 1px solid red;
		overflow-y:scroll; 
	}
	.item-box .item{
		line-height: 30px;
		font-size: 24px;
	}
	.modal{
		position: absolute;
		width: 100%;
		height: 100%;
		display: block;
		background-color: rgba(0,0,0,.9);
		color: #fff;
		font-size: 30px;
		top: 0;
		left: 0;
		line-height: 500px;
	}
</style>