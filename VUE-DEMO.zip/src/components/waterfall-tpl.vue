<template >
	<div>
		<div class="vue-waterfall-easy">vue-waterfall展示</div>
		<div class="waterfall-img">
			<waterfall :line-gap="200" :watch="imgsArr">
			  <!-- each component is wrapped by a waterfall slot -->
				<waterfall-slot class="water-box"
				    v-for="(item, index) in imgsArr"
				    :width="item.width"
				    :height="item.height"
				    :order="index"
				    :key="item.id"
				  >
				  <img v-lazy="item.url" src="">
				  </waterfall-slot>
			</waterfall>
		</div>
		<div @click="loadMore">点击加载更多</div>
	</div>
</template>
<script type="text/javascript">
	import Waterfall from 'vue-waterfall/lib/waterfall'
	import WaterfallSlot from 'vue-waterfall/lib/waterfall-slot'
	import  Vue from 'vue'
	import VueLazyload from 'vue-lazyload'  
	//等多参数请移步  https://github.com/hilongjw/vue-lazyload
	//配置图片懒加载
	Vue.use(VueLazyload, {
		//error: 'dist/error.png',//这个是请求失败后显示的图片
		loading: require('@/assets/default.png'),//这个是加载的loading过渡效果
		try: 2, // 这个是加载图片数量,
		// preload:1.3,//预加载的宽高
		//attempt:3,//尝试加载的次数
		//listenEvents: [ 'scroll' ]
	    // filter: { //滤图片的路径，默认{ }
	    //   webp ({ src }) {
	    //   	  console.log('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
	    //   	  console.log(src)
	    //       return src
	    //   }
	    // }
	})
	export default {
		data() {
			return {
				imgsArr: [],         //存放所有已加载图片的数组（即当前页面会加载的所有图片）
      			fetchImgsArr: []     //存放每次滚动时下一批要加载的图片的数组
			}
		},
		created() {
			this.initImg()
		},
		methods:{
			initImg() {
				this.imgsArr = [{
						url:'http://imgcno.nos.netease.com/img/R1N2VWIyZFFQMzBEWWIra2FVay9sQkZ4SEpRSUkxdkpTU1BrQWVpdkRoZ1pqUFJ4MC9rYlZBPT0.jpg',
						width:'150',
						height:'100'
					},{
						url:'http://imgcno1.nos.netease.com/img/R1N2VWIyZFFQMzJzOFdaazFnRVVvQ3FyYkFGWi9wVmttTHl3ZTNQc01yYTI0Vk1YSytpQ2FRPT0..jpg',
						width:'100',
						height:'200'
					},{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzFOWFpjUmllY013VUEvd3FvSnREdDJaY2dZTmF5NnhiWjNYMmlsM2pCZU9nPT0.jpg',
						width:'230',
						height:'180'
					},{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzBVeWVvcGlLZWtObktCVm1adWRVRml5NmhZOHZ4L0RaMEhkT3AxdWtUMXFBPT0..jpg',
						width:'290',
						height:'400'
					},{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzBrbmtyQ2VxRjJVb0dEbVpXaW0vWnlINDd3U1hLL2lXSXNiSEgwaDg3eUtBPT0..jpg',
						width:'500',
						height:'200'
					},{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzFKemt2R1JTdFJTZlUvUE9VZHR3Q1c0Ull6b25SY3hvaXJHNkYwWk0yTUt3PT0.jpg',
						width:'300',
						height:'150'
					},{
						url:'http://imgcno.nos.netease.com/img/R1N2VWIyZFFQMzBmeC85SFdaT1VjTnVRdjFPN0pSZWlmbE9WYzBObXhrNkZsTUx2Tlc1RG53PT0..jpg',
						width:'180',
						height:'330'
					},{
						url:'http://imgcno0.nos.netease.com/img/R1N2VWIyZFFQMzBrWEwrYW9BbjdveDJiRXZXc1oyUlpHZi94dGxEY29ja2pXcW14SFdodnd3PT0..jpg',
						width:'260',
						height:'230'
					},{
						url:'http://imgcno1.nos.netease.com/img/R1N2VWIyZFFQMzJ1MEhnNnNOTzNXdFlqVStjVHVZQVU4TmZITm5BUWZSbzhCVHI2a3BXQzl3PT0.jpg',
						width:'290',
						height:'300'

					}
				]
			},
			addImg() {
				this.fetchImgsArr = [{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzNrdzdNZzVxS1ZaRzBZTjZZRUhTN09HL2FXQmdnamNaYms5WURISnFiZENnPT0..jpg',
						width:'200',
						height:'300'
					},{
						url:'http://imgcno0.nos.netease.com/img/R1N2VWIyZFFQMzI3ZjcvNHIvd1A5Rk85aGQya0F4VVJiU3VDdFFnaUdZM0xIRTdleGVnZFN3PT0..jpg',
						width:'300',
						height:'500'
					},{
						url:'http://imgcno1.nos.netease.com/img/R1N2VWIyZFFQMzJFSUd6OEZVYzdzMVY1NkFiQStIdEQ0clF5dXQ1VTZ2bit2dTRXOHZNK3FBPT0..jpg',
						width:'300',
						height:'500'
					},{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzIvcnV6Qmo2VXRCaEw4K3AwYitBZU9qQUI5SUt3ZFMwZWhtZkhaNzRzZVdnPT0.jpg',
						width:'400',
						height:'930'
					},{
						url:'http://imgcno0.nos.netease.com/img/R1N2VWIyZFFQMzIya3h6NHlmemN0bFJ5M1Jhb2hnZHFaYlM5VzF3OFhabmw2WTZlUW8xWHpRPT0..jpg',
						width:'300',
						height:'100'
					},{
						url:'http://imgcno1.nos.netease.com/img/R1N2VWIyZFFQMzB5UWZvcnpqczRxMTlsRE1BWnliSXU1cGJiVVI5SnpPUVlDbEJIcHRiL01RPT0..jpg',
						width:'400',
						height:'700'
					},{
						url:'http://imgcno.nos.netease.com/img/R1N2VWIyZFFQMzNSV3BJVjJuR3BIZWJ2b1RUR25yZ0tLUWtuSkdjQTJTNVV6dHZlUjRGQTRBPT0.jpg',
						width:'400',
						height:'500'
					},{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzEwVnBjMEJML0I2RUdoeEhhSTNhWWxnT29KVjhNSHZBR1R3WE45RDFrY2JRPT0.jpg',
						width:'300',
						height:'600'
					},{
						url:'http://imgcno1.nos.netease.com/img/R1N2VWIyZFFQMzBHakNzaFZOZ0NOemwzYXRHZ2UvalFabGJCenFFK2FpOUd2UU1uQ05nS3NBPT0..jpg',
						width:'800',
						height:'900'
					},{
						url:'http://imgcno1.nos.netease.com/img/R1N2VWIyZFFQMzBZdGNtbmNqb1g1NGo0S3daNGlxcDJSdHlRUE10SjZLNGJRMkczLzVSVnNnPT0..jpg',
						width:'600',
						height:'900'
					},{
						url:'http://imgcno0.nos.netease.com/img/R1N2VWIyZFFQMzEzVkdmbWdSb2gwczFISDc5SndBLzNBMDdZOE5kV0RnVDhtOC8vTDNlaHpBPT0.jpg',
						width:'500',
						height:'700'
					},{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzB6MkM4R0FMOW1WeUkwSTZEcit5MUNYSUYzM0tWelF1VEFDSFRlWWZMU3VRPT0..jpg',
						width:'600',
						height:'800'
					},{
						url:'http://imgcno2.nos.netease.com/img/R1N2VWIyZFFQMzJFdEs4RzZjb1drc0FsdThIL0hEaGVBZ0ZtUi82NnBzQVdqNE5uUkpyNVFBPT0..jpg',
						width:'900',
						height:'200'
					}
				]
			},
			loadMore() {
				this.addImg()
			    for( let i of this.fetchImgsArr) {
			    	console.log(1111)
			    	this.imgsArr.push(i)
			    }
				
			}
		},
		components:{
			Waterfall,
    		WaterfallSlot
		}
	}
</script>
<style type="text/css">
	.vue-waterfall-easy{
		font-size: 30px;
		text-align: center;
	}
	.waterfall-img img{
		display: block;
		width: 100%;
		height: 100%;

	}
	.water-box{
		padding: 5px !important;
	}
</style>