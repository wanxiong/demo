<template>
	<div>
		<transition 
		enter-active-class="animated zoomInUp" 
		leave-active-class="animated fadeOutRightBig"
		>
            <div v-if="isShow" class="hello-you">你好明天</div>
        </transition>
		<button class="animate-btn" @click="toggle">toggle</button>
		<!-- <div class="animate-con">看我的style</div> -->
	</div>
</template>
<script type="text/javascript">
	import '@/assets/style/animate.css'
	export default {
		data() {
			return {
				isShow:false
			}
		},
		methods:{
			toggle() {
				this.isShow = !this.isShow
			}
		},
		 //页面挂载完毕时更改状态
        mounted(){
            this.isShow = true;
        }
	}
</script>
<style type="text/css" lang="scss">
	.animate-div{
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: #e9d8d8;
		line-height: 500px;
		font-size: 50px;
	}
	.animate-btn{
		position: absolute;
		z-index: 99;
		left: 50%;
		top: 50%;
		transform:translate(-50%,-80%);
		font-size: 26px;
	}
	.animate-con{
		position: absolute;
		z-index: 99;
		left: 50%;
		top: 60%;
		transform:translate(-50%,-80%);
		font-size: 26px;
	}
	.hello-you{
		font-size: 40px;
	}
</style>