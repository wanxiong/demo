import * as types from './type'
//存储名字
export const setName = ({commit,aaa} , params) => {
	commit(types.NAME , params)
}
//存储年龄
export const setAge = ({commit,aaa} , params) => {
	commit(types.AGE , params)
}