
let state  = {
	name:'', //名字
	age:'',  //年龄
}
export default state
