import Vue from 'vue'
import axios from 'axios'

// QQ音乐的接口，存在域名拦截     https://c.y.qq.com/splcloud/fcgi-bin/fcg_get_diss_by_tag.fcg
// QQ音乐的接口，存在域名拦截     https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg

export const testAjaxPostOne = () => { 
	return axios.post('/api/splcloud/fcgi-bin/fcg_get_diss_by_tag.fcg').then((res) =>{
		return Promise.resolve(res)
	}).catch((respone) => {
		console.log(respone)
	})
}
export const testAjaxPostTwo = () => {
	return axios.post('/api/lyric/fcgi-bin/fcg_query_lyric_new.fcg').then((res) =>{
		return Promise.resolve(res)
	}).catch((respone) => {
		console.log(respone)
	})
}

export const getToken = () => {
	return axios.get('/api/getToken').then((res) =>{
		return Promise.resolve(res)
	}).catch((respone) => {
		console.log(respone)
	})
}


