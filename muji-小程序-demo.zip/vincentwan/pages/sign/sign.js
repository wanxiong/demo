
//获取应用实例
const app = getApp()

Page({
  data: {
    url: 'pages/sign/sign', //当前页面的url
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
 
  onLoad: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.cardIsFirst = false
    var _this = this
    if (!app.hasAuthorization) {
      wx.showModal({
        title: '提示',
        content: '由于您暂未授权，此功能暂未对您开放,如需要重新授权，请退出小程序重新进入',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log(_this.data.url)
            console.log(getCurrentPages()[0].route)
            if (_this.data.url == getCurrentPages()[0].route) {
              //点击确定 不点导航tabbar时跳转pages/home/home月面
              console.log('点击确定')
              wx.switchTab({
                url: '/pages/home/home',
              })
            } else {
              console.log('点击tabbar')
            }
            //点击tabbar直接切换走，不点击确定按钮时候
          }
        }
      })
    }
  }
})
