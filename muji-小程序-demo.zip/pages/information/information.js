const app = getApp()
// pages/information/information.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url:'pages/information/information' //当前页面的url
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this 
    app.cardIsFirst = false
    if (!app.hasAuthorization) {
      wx.showModal({
        title: '提示',
        content: '由于您暂未授权，此功能暂未对您开放,如需要重新授权，请退出小程序重新进入',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log(_this.data.url)
            console.log(getCurrentPages()[0].route)
            if (_this.data.url == getCurrentPages()[0].route ) {
              //点击确定 不点导航tabbar时跳转pages/home/home月面
              console.log('点击确定')
              wx.switchTab({
                url: '/pages/home/home',
              })
            } else {
              console.log('点击tabbar')
            }
            //点击tabbar直接切换走，不点击确定按钮时候
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {
  
  // }
})