// pages/unopened/unopened.js
//获取应用实例
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url: 'pages/unopened/unopened', //当前页面的url
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var _this = this
    if (!app.hasAuthorization) {
      wx.showModal({
        title: '提示',
        content: '由于您暂未授权，此功能暂未对您开放,如需重新授权，需在微信【发现】——【小程序】——删掉【无印良品MUJI】，重新搜索授权登录，方可使用',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
              wx.switchTab({
                url: '/pages/home/home',
              })
            //点击tabbar直接切换走，不点击确定按钮时候
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {
  
  // }
})