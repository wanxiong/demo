import { trim, getData, formData } from '../../../utils/util'
// pages/ticket/shopList/shop_list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    count:"--",  //小票总数
    shopCd:"",   //店铺code
    shopName:"", //店铺名字
    year:"",  //选择的年份
    limit:20,
    startLimit:20,
    loadMore:false, //是否可以加在更多
    listData:[],  //渲染数据源
    allListData:[] //全部的数据
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this;
    var params = options;
    this.setData({
      count: params.count,
      shopName: params.shopName,
      year: params.year,
      shopCd: params.shopCd
    })
    _this.initData(params.shopCd, params.year )
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var _this = this;
    if (!this.data.loadMore ) return false ;
    var limit = _this.data.startLimit,
        defaultLimit = _this.data.limit,
        allData = _this.data.allListData,
        list = [] ;
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    list = allData.slice(0, limit);
    if (allData.length > limit) {
      //可分页
      this.setData({
        startLimit: _this.data.startLimit + defaultLimit,
        loadMore: true
      })

    } else {
      //不可分页
      this.setData({loadMore: false})
    }
    
    this.setData({ listData: list })
    setTimeout(() => {
      wx.hideLoading()
    }, 500)
  },
  /**
   * 打开详情页面 
   */ 
  openDetail(e) {
    var _this = this;
    var params = e.currentTarget.dataset.value;
    var isRefund = params.saleType;
    params.realAmt = parseFloat(params.realAmt);
    params.payNames[0].pay = params.payNames[0].pay.toFixed(2);
    var json = JSON.stringify(params)
    if (isRefund == '0') {
      //退货
      wx.navigateTo({
        url: `./../refundShop/refundShop?params=${json}`
      })
    } else {
      //销售
      wx.navigateTo({
        url: `./../shopDetail/shop_detail?params=${json}`
      })
    }
  },
  /**  本地拿取数据渲染
   *  @params { String shopcd}   当前店铺的shopcode
   *  @params { String year}     当前的年份
  */
  initData(shopcd , oldyear) {
    var localdata = wx.getStorageSync('ticketData');
    var list = [], newyear,sliceList = [],_this = this;
    for (let i = 0; i < localdata.length ; i++) {
      newyear = parseInt(localdata[i].checkoutDate.substring(0, 4));
      if (localdata[i].shopCd == shopcd && oldyear == newyear ) {
        localdata[i].realAmt = localdata[i].realAmt.toFixed(2)
        localdata[i].fromCheckoutDate = formData(localdata[i].checkoutDate, '/')
        list.push(localdata[i])
      }
    }
    //赋值
    var limit = _this.data.limit ;
    if (list.length > limit) { 
        //可分页
        sliceList = list.slice(0, limit)
        this.setData({
          startLimit: _this.data.startLimit + limit,
          allListData: list,
          loadMore : true
        })

    } else {
        //不可分页
        sliceList = list.slice(0, limit)
        this.setData({
          loadMore: false
        })
    }
    
    this.setData({ listData: sliceList })
  }
})