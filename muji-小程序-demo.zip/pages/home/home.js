import NumberAnimate from './../../utils/NumberAnimate'
var WXBizDataCrypt = require('./../../utils/RdWXBizDataCrypt');
// pages/API/API.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 开始角度
    startAngle: -(1 / 2 * Math.PI),  //顶部出现 默认0deg的时候三点钟方向
    // 偏移角度
    xAngle: Math.PI / 80,
    // 结束角度  miles
    endAngleMiles: '',
    // 结束角度  Points
    endAnglePoints:  0,
    //用户头像
    avatarUrl:'',
    //能否点击图片
    tapClick:true,
    //图片的宽高适配
    initImg :{
      width:'0',
      height:'0'
    },
    miles: '--',
    points: '--',
    num1Complete: '',
    num2Complete: '',
    topTips: [], //顶部tip轮播
    //轮播区域数据
    imageList:[
      './../../image/1.jpg'
    ],//
    indicatorDots: false,  //是否显示面板指示点
    autoplay: false,  //是否自动切换
    interval: 5000,   //自动切换时间间隔
    duration: 1000,   //滑动动画时长 
    indicatorColor:'#fff',   //指示点颜色
    indicatorActiveColor: '#858988',  //当前选中的指示点颜色
    mode: 'scaleToFill', //可以完整地将图片显示出来  类似=>cover scaleToFill
    circular: true,    //是否过渡衔接
    leaveImg:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    if (options.q !== undefined) {
      var url = decodeURIComponent(options.q);
      console.log(url)
    }
    console.log('监听页面加载 主页')
    var _this = this;
    //获取头像
    this.getUserInfo()
    //最上层白色
    this.canvasStaticArc('miles-top', '#ffffff',40,40,40,40,30,0,2 * Math.PI)
    this.canvasStaticArc('points-top', '#ffffff', 40, 40, 40, 40, 30, 0, 2 * Math.PI)
    //中层灰色
    this.canvasStaticArc('miles-bottom','#871b20',40,40,40,40,40,0,2 * Math.PI)
    this.canvasStaticArc('points-bottom', '#871b20', 40, 40, 40, 40, 40, 0, 2 * Math.PI)
    //绘制文字
    this.canvasText('miles-text','#9d0102',40,40,'里程')
    this.canvasText('points-text', '#9d0102', 40, 40, '积分')
    //miles
    
    //points
   // _this.rander('points-center', animFrame, cxt_arc, endAnglePoints,xAngle, templeAngle)
    //this.initInfo({ "accountInfo": { "stageName": "铜级", "mile": 2001, "point": 200, "nextStageName": "银级", "nextStageMile": 3000, "nextStagePoint": "100", "nextBorderMile": 500, "nextBorderPoint": 50, "nearPointExpireDate": "20171231", "nearPointExpireAmount": 200, "mileExpireDate": "20171231", "stageExpireDate": "", "gender": "1", "birthday": "19950101", "accountType": "1","stageCode":2, "resultCode": 0, "errorMessage": "" }, "code": 200, "messageList": "距获得50积分，还需500里程,您有200积分在2017/12/31到期,您有0里程在2017/12/31到期" })
  
  },
   /** 画静态环 
   * @params { String canvasId } canvas节点ID   *
   * @params { String color }    圆圈的颜色填充  *
   * @params { String moveX }    移动X轴距离     *
   * @params { String moveY }    移动Y轴距离     *
   * @params { String x }        圆的中心的 x 坐标。 *
   * @params { String y }        圆的中心的 y 坐标。 *
   * @params { String r }        圆的半径。         *
   * @params { String sAngle }   起始角，以弧度计。  *
   * @params { String eAngle }   结束角，以弧度计。  *
   * @params { String text }     绘制文字           可选
   */
   canvasStaticArc(canvasId,color,moveX,moveY,x,y,r,sAngle,eAngle) {
      var canvasId = canvasId 
      var color = color 
      var moveX = moveX  || 50
      var moveY = moveY  || 50
      var X = x || 50
      var Y = y || 50
      var R = r || 50
      var sAngle = sAngle || 0
      var eAngle = eAngle || 2 * Math.PI
      var cxt_arc = wx.createContext();
      cxt_arc.beginPath();
      cxt_arc.setFillStyle( color )
      cxt_arc.moveTo(moveX, moveY);
      cxt_arc.arc(X, Y, R, sAngle, eAngle)
      cxt_arc.closePath();
      cxt_arc.fill();
      cxt_arc.closePath();
     
      wx.drawCanvas({
         canvasId: canvasId,
         actions: cxt_arc.getActions()
      })

   },
   canvasText(canvasId, color, moveX, moveY,text) {
      var cxt_arc = wx.createContext();
      cxt_arc.beginPath();
      cxt_arc.setFontSize(20)
      cxt_arc.setFillStyle(color)
      cxt_arc.setTextAlign('center')
      cxt_arc.setTextBaseline('middle')
      cxt_arc.fillText(text, moveX, moveY)
      cxt_arc.closePath();
      wx.drawCanvas({
        canvasId: canvasId,
        actions: cxt_arc.getActions()
      })
   },
   initrequestAnimFrame () {
     //if (requestAnimationFrame) return requestAnimationFrame;

     return function (callback) {
         setTimeout(callback, 1000 / 60);
       };
   },
   /** 画动态圆的func
   * @params { String canvasId }    canvas-id对应的value 即ID   *
   * @params { Func animFrame }     定时器序列帧  
   * @params { Object cxt_arc }     canvas上下文  
   * @params { String endAngle }    结束角度
   * @params { String xAngle }      偏移角度
   * @params { String templeAngle } 开始角度
   * @params { String color }       当前进度的颜色值
   */
   rander(canvasId, animFrame, cxt_arc, endAngle, xAngle, templeAngle, color) {
     var _this = this;
     function drawInterval () {
        if (templeAngle >= endAngle) {
          return;
        } else if (templeAngle + xAngle > endAngle) {
            templeAngle = endAngle;
        } else {
            templeAngle += xAngle

        }
        cxt_arc.beginPath();
        //金级#d5ad3c
        //银级#e0dfe0
        //铜级#b18955
        //普通#666666
        //金级之后使用MUJI 红。

        //#7F0019 MUJI红，确认无误。
        cxt_arc.setFillStyle(color)
        cxt_arc.moveTo(40, 40);
        cxt_arc.arc(40, 40, 40, _this.data.startAngle, templeAngle)
        cxt_arc.closePath();
        cxt_arc.fill();
        cxt_arc.closePath();
        wx.drawCanvas({
          canvasId: canvasId,
          actions: cxt_arc.getActions()
        })
        animFrame(drawInterval);
     }
     //_this.drawFrame(animFrame)
     animFrame(drawInterval);
   },
   //数字添加逗号
   toThousands(num) {
     var result = [], counter = 0;
     num = (num || 0).toString().split('');
     for (var i = num.length - 1; i >= 0; i--) {
       counter++;
       result.unshift(num[i]);
       if (!(counter % 3) && i != 0) { result.unshift(','); }
     }
     return result.join('');
   }, 
   /* 数字滚动 
   * @params { String miles }  里程
   * @params { String points } 分数
   * */
   animateNumber(miles, points) {
     var _this = this
     if ( parseInt( miles ) != 0  ){
       var speed = parseInt(miles) < 20 ? 50 * parseInt(miles) : 2000;
      let n1 = new NumberAnimate({
        from: miles,
        speed: speed,
        refreshTime: 50,
        decimals: 0,
        onUpdate: () => {
          var value = _this.toThousands(n1.tempValue)
          this.setData({
            miles: value
          });
        },
        onComplete: () => {
          //  this.setData({
          //    num1Complete: " 完成了"
          //  });
        }
      });
     } else { this.setData({miles: 0}) } ;

     if (parseInt( points ) != 0) {
       var speed = parseInt(points) < 20 ? 50 * parseInt(points) : 2000;
      let n2 = new NumberAnimate({
        from: points,
        speed: speed,
        refreshTime: 50,
        decimals: 0,
        onUpdate: () => {
          var value = _this.toThousands(n2.tempValue)
          this.setData({
            points: value
          });
        },
        onComplete: () => {
          //  this.setData({
          //    num1Complete: " 完成了"
          //  });
        }
      });
     } else { this.setData({ points: 0 }) }     

   },
   //获取用户头像等信息
   getUserInfo() {
     var _this = this 
     wx.getUserInfo({
       success: function (res) {
         app.hasAuthorization = true //有权限
         _this.setData({
           avatarUrl:JSON.parse(res.rawData).avatarUrl
         })
         //同意拉去API
         var timer
         app.userInfo = res
         function inter() {
            if( app.code != '') {
              _this.getSession()
              clearInterval(timer)
            }
         }
         timer = setInterval(inter, 100)
         
         //_this.getMilesData(_this.initInfo, res)
       },
       fail( res) {
         app.hasAuthorization = false //没权限
         console.log('用户拒绝获取信息')
         _this.noAuthorize()
       }
     })
   },
   //获取用户信息
   getMilesData(unionid) {
     var _this = this;
     wx.request({
       url: `${app.configApi.baseUrl}${app.configApi.miniInfo}`,
       method: 'GET',
       data:{
         unionid: unionid
       },
       header: {
         'content-type': 'application/json' // 默认值
       },
       success(res) {
         if ( res.data.code == 400 ) { //用户不存在
           console.log(`成功页面code的值${res.code}`)
         } else { //成功
           _this.initInfo(res.data)
         }
         
       },
       fail(res) {
         console.log('接口getMilesData调取失败')
         _this.ShowErrerTemplate('获取个人信息失败', 2000, './../../image/icon-3.png')
       },
       complete() {
         wx.hideLoading()
       }
     })
   },
   //获取session_key
   getSession(callback) {
     var _this = this
     wx.showLoading({
       title: '加载中',
       mask: true
     })
     console.log('~~~~~~~~~~华丽的分割线')
     console.log(wx.getStorageSync('unionidObj'))
     //因为此API获取session_key这个接口在微信那边存在频繁调用限制，所以 本地缓存起来
     if (!wx.getStorageSync('unionidObj') ) {//用户不存在缓存
       wx.request({
         url: `${app.configApi.baseUrl}${app.configApi.getUserInfo}?code=${app.code}`,
         method: 'GET',
         success(res) {
           console.log(res)
           var session_key = res.data.data.session_key
           var obj = {}
           //open id
           console.log(session_key + '~session_key')
           app.openid = res.data.data.openid
           obj.openid = res.data.data.openid
           //如果unionid存在，就不用解密了
           if (res.data.data.unionid) {
             app.unionid = res.data.data.unionid
             obj.unionid = res.data.data.unionid
           } else { //反之去解密
             var newWXBiz = new WXBizDataCrypt(app.configApi.appId, session_key)
             console.log(newWXBiz)
             var data = newWXBiz.decryptData(app.userInfo.encryptedData, app.userInfo.iv)
             app.unionid = data.unionId
             obj.unionid = data.unionId
           }
           //存入本地记录
           wx.setStorageSync('unionidObj', obj)
           _this.getMilesData(app.unionid)
         },
         fail(ErrorMsg) {
           console.log(ErrorMsg)
           wx.hideLoading()
           _this.ShowErrerTemplate('获取id失败', 2000, './../../image/icon-3.png')
         }
       })
     } else {  //用户的信息有过记录
       var uniObj = wx.getStorageSync('unionidObj')
            app.openid = uniObj.openid
            app.unionid = uniObj.unionid
           _this.getMilesData(uniObj.unionid)
     }
    
   },
   //
   /** 初始化方法
   *  res 返回的个人数据信息
   */
   initInfo(res) {
      var _this = this 
      var cxt_arc = wx.createContext();
      var xAngle = _this.data.xAngle;
      var templeAngle = _this.data.startAngle;
      var endAnglePoints = _this.data.endAnglePoints;
      var animFrame = _this.initrequestAnimFrame()
      var percent, mile, stageCd, bgcolor,leaveImg;
      // 计算进度
      mile = res.accountInfo.mile || 0
      if (parseInt(mile) <= 0) {
        percent = 0;
      } else if (parseInt(mile) < 3000) {
        percent = ((parseInt(mile) % 500) / 500) ;
      } else if (parseInt(mile) < 8000) {
        percent = ((parseInt(mile) % 1000) / 1000) ;
      } else {
        percent = ((parseInt(mile) % 2000) / 2000) ;
      }
      //计算等级颜色 
      stageCd = res.accountInfo.stageCode
      //color = '#ff0000'
      leaveImg = './../../image/leave-1.png'
      if (parseInt(stageCd) == 2) {
        //color = "rgb(118,127,96)";
        leaveImg = './../../image/leave-2.png'
      } else if (parseInt(stageCd) == 3) {
        //color = "rgb(176,175,175)";
        leaveImg = './../../image/leave-3.png'
      } else if (parseInt(stageCd) == 4) {
        //color = "rgb(207,193,111)";
        leaveImg = './../../image/leave-4.png'
      }
      _this.setData({
        topTips: res.messageList.split(','),
        leaveImg: leaveImg,
        endAngleMiles: ((2 * Math.PI) * percent) - (Math.PI/2)
      })
      bgcolor = '#bd1c21'
      setTimeout(() => {
          var miles = res.accountInfo.mile || 0,
              points = res.accountInfo.point || 0;
          _this.animateNumber(miles, points)
        _this.rander('miles-center', animFrame, cxt_arc, _this.data.endAngleMiles, xAngle, templeAngle, bgcolor)
      }, 100)
   },
  /*
  * 用户拒获获取信息授权的回调处理
  */
  noAuthorize() {
    var _this = this ;
    wx.showModal({
      title: '警告',
      content: '若不授权登录微信，则无法使用领卡功能，点击重新获取授权，则可重新使用',
      confirmText: "授权",
      cancelText: "不授权",
      success: function (res) {
        if (res.confirm) {
          wx.openSetting({
            success: function (res) {
              if (res.authSetting["scope.userInfo"]) {
                app.hasAuthorization = true //没权限
                //这里是授权成功之后 填写你重新获取数据的js
                console.log(res)
                wx.getUserInfo({
                  success: function (res) {
                    app.hasAuthorization = true //有权限
                    _this.setData({
                      avatarUrl: JSON.parse(res.rawData).avatarUrl
                    })
                    //同意拉去API
                    app.userInfo = res
                    _this.getSession()
                    //_this.getMilesData(_this.initInfo, res)
                  },fail(res) {
                    console.log(res)
                  }
                })
              } else {
                app.hasAuthorization = false //没权限
                //调起界面还是不授权
                console.log('我还是没选中')
              }
            }
          })
        } else if (res.cancel) {
          app.hasAuthorization = false //没权限
          console.log('用户点击不授权')
        }
      }
    })
  },
    /**@params 请求出错，跳转index首页
  * {@String text } 自定义文言，显示错误的提示语   *必填
  * {@String time } 自定义提示时间，单位毫秒      *必填
  * {@String icon } 自定义icon，显示错误的提示icon  
  */
  ShowErrerTemplate(text, time, icon) {
    var icon = icon || ''
    wx.showToast({
      title: `${text}`,
      icon: 'success',
      image: `${icon}`,
      mask: true,
      duration: parseInt(`${time}`)
    })
  },
  /*
  *
  */
  addPoint(){
    var _this = this 
    if ( _this.data.tapClick ) {
      _this.setData({ tapClick: false })
      wx.request({
        url: `${app.configApi.baseUrl}${app.configApi.addPoint}?unionid=${app.unionid}`,
        method: 'GET',
        success(res) {
          if( res.code == 200 ) {
            _this.ShowErrerTemplate('积分添加成功', 1500, './../../image/icon-1.png')
          }else if ( res.code == 300 ) {
            _this.ShowErrerTemplate('您已经加过积分了', 1500, './../../image/icon-2.png')
          }
        },
        fail(res){
          _this.ShowErrerTemplate('添加积分失败', 1500,'./../../image/icon-3.png')
        },
        complete() {
          _this.setData({ tapClick: true })
        }
      })
      //
    }
  }, 
  /*
  * 图片自适应
  */
  imgLoad(e) {
    var _this = this
    var $width = e.detail.width,    //获取图片真实宽度
        $height = e.detail.height,
        ratio = $width / $height;
        console.log(e)
        if (app.systemInfo != '') {
          var w = app.systemInfo.windowWidth
          var thumbnailW = w
          var thumbnailH = parseInt(w / ratio)
          console.log(thumbnailW + '=======' + thumbnailH )
          _this.setData({
            initImg:{
              width: `${thumbnailW}px`,
              height: `${thumbnailH}px`
            }
          })
        }
  },
   /**
  * 生命周期函数--监听页面显示
  */
   onShow: function () {
    app.cardIsFirst = false
   }


})