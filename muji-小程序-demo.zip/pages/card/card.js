var WXBizDataCrypt = require('./../../utils/RdWXBizDataCrypt');
// pages/component/component.js
//获取应用实例
const app = getApp()
let Timer = null
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isOpenCard:false,//代表没打开过卡界面
    url: 'pages/card/card' //当前页面的url
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      console.log('加载页面加载 card')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.log('onReady card')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () { 
    console.log('卡券显示')
    var _this = this;
    if(!app.hasAuthorization) {
        //拒绝过授权调回主页
      _this.noAuthority()
        return false;
    }
    console.log(app.cardIsFirst)
    if (!app.cardIsFirst) { //为false 即加载
      wx.showLoading({
        title: '加载中'
      })
      _this.tapCard()
    }
    if (_this.data.isOpenCard ) { //如果当前页面打开过卡且界面显示
      _this.data.isOpenCard = false;
      //跳至主页
      wx.switchTab({
          url: '/pages/home/home'
      })
      

    } 
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var _this = this;
    console.log('on hide -card')
    //清楚多余的定时器
    clearInterval(Timer)
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {
  
  // },
   //点击卡按钮事件
  tapCard() {
    var _this = this;
    console.log('xiong wan tap')
    app.cardIsFirst = true
    //判断是否有unionid
    _this.hasUnionid();
    //判断是否创建过卡
    //_this.getCardJump()
    //添加卡
    //_this.getCardSign( _this.addCard )
    
    // setTimeout( ()=>{
    //   console.log('time out')
    //   wx.addCard({
    //     cardList: [
    //       {
    //         cardId: 'pUWdBvxD7BqbMueQZ5sUnTvbv_TY',
    //         cardExt: '{"signature":"6a7f2618b9a83e12de1c8abf4dd1b5e55a54f551","timestamp":"1513685414","nonce_str":"MTUxMzY4NTQxNA=="}'
    //       }],
    //     success: function (res) {
    //       console.log(res.cardList) // 卡券添加结果
    //     },
    //     fail(res) {
    //       console.log(res)
    //       wx.switchTab({
    //         url: '/pages/home/home'
    //       })
    //     },
    //     complete(res) {
    //       console.log(res)
    //     }

    //   })
    // },500)
  },
  //添加卡券
  addCard(res) {
    var _this = this ;
    wx.addCard({
      cardList: [{
        cardId: res.cardid,
        cardExt: JSON.stringify(res.cardext)
      }],
      success: function (res) {
        console.log(res)
        if (res.cardList[0].isSuccess && res.cardList[0].code) {
          //先去解密code，然后打开卡界面  目前只支持单卡
          _this.deCode(res.cardList[0], _this.openCard)
        } else {
          //失败
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        }
      },
      fail(res) {
        console.log(res)
        console.log('添加卡券失败')
        wx.switchTab({
          url: '/pages/home/home'
        })

      }
    })
  },
  //打开卡券
  openCard(res) {
    var _this = this ; 
    wx.openCard({
      cardList: [{
        cardId: res.cardid,
        code: res.code
        }
      ],
      success: function (res) {
        _this.setData({isOpenCard:true})//打开过openCard 界面
        console.log(res)
        // wx.switchTab({
        //   url: '/pages/home/home'
        // })
      },
      fail(res) {
        console.log(res)
        _this.ShowErrerTemplate('出错了，请重试', 2000, './../../image/icon-3.png')
      }
    })
  },
  /** 解密code  API
  * @params {Function callback } 对应回调
  * @params {String code } 对应addCard返回加密的code
  */
  deCode (res,callback) {
    var _this = this;
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getCode}?code=${encodeURIComponent(res.code)}`,
      method:'GET',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(respones) {
        if (respones.data.code == 400 ) {
           //失败
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        } else {
          //成功
          var json = {};
          json.code = respones.data.cardCode
          json.cardid = res.cardId
          console.log('解密之后' + json)
          callback && callback(json)
        }
        
      },
      fail(res) {
        console.log('解密失败')
        _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
      }
    })
  },
  //判断是否跳过addCard
  getCardJump() {
    var _this = this 
    wx.request({
      url: `${app.configApi.baseUrl}${app.configApi.getCardJump}?unionid=${app.unionid}&miniOpenid=${app.openid}`,
      method: 'GET',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log('接口getJump成功')
        console.log(res)
        if (res.data.code != 200) {
          console.log(`不成功页面code的值${res}`)
          _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
        } else {
          if (res.data.cardCode) {//opencard
            res.data.code = res.data.cardCode
            res.data.cardid = res.data.cardid
            _this.openCard(res.data)
          } else {//addCard
            setTimeout(()=>{
              _this.addCard(res.data)
            }, 500)
          }
        }
      },
      fail(res) {
        _this.ShowErrerTemplate('出错了，请重试', 1000, './../../image/icon-3.png')
      }
    })
  },
  /**@params 请求出错，跳转index首页
  * {@String text } 自定义文言，显示错误的提示语   *必填
  * {@String time } 自定义提示时间，单位毫秒      *必填
  * {@String icon } 自定义icon，显示错误的提示icon  
  */
  ShowErrerTemplate (text,time,icon) {
    var T = parseInt(time) || 0
    var icon = icon || ''
      wx.showToast({
      title: '出错了',
      icon: 'success',
      image: `${icon}`,
      mask: true,
      duration: T
    })
    setTimeout(() => {
      wx.switchTab({
        url: '/pages/home/home'
      })
    }, T)
  },
  //没授权处理函数
  noAuthority() {
    var _this = this
      wx.showModal({
        title: '提示',
        content: '由于您暂未授权，此功能暂未对您开放,如需重新授权，需在微信【发现】——【小程序】——删掉【无印良品MUJI】，重新搜索授权登录，方可使用',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log(_this.data.url)
            console.log(getCurrentPages()[0].route)
            if (_this.data.url == getCurrentPages()[0].route) {
              //点击确定 不点导航tabbar时跳转pages/home/home月面
              console.log('点击确定')
              wx.switchTab({
                url: '/pages/home/home',
              })
            } else {
              console.log('点击tabbar')
            }
            //点击tabbar直接切换走，不点击确定按钮时候
          }
        }
      })
    },
    /**
     * 检测unionid是否存在，不存在的话，等待2秒，还没用的话，重新发起请求
    */
    hasUnionid() {
      var inter=null ,countT= 1, _this = this ;
      if (app.unionid ) { //存在unionid
        _this.getCardJump();
      } else { //不存在 unionid
        inter = () => { //定时器方法
          countT ++
          if (app.unionid ) {
            clearInterval(Timer)
            _this.getCardJump();
          } else {
            if (countT > 100) {
              // 100 * 100 = 10000  => 10s
              clearInterval(Timer)
              //还没拿到，应该重新去啦API啦，我就当这样默认了，
              wx.hideLoading()
              wx.showToast({
                title: '出错了，请重试',
                icon: 'success',
                image: './../../image/icon-3.png',
                mask: true,
                duration: 1000
              })
              setTimeout(() => {
                wx.switchTab({
                  url: '/pages/home/home'
                })
              }, 1000)
            }
          }
        };
        Timer = setInterval(inter , 100)
      }
    }
})