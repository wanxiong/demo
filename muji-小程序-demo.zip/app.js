// var WXBizDataCrypt = require('./utils/RdWXBizDataCrypt');
//app.js
App({
  onLaunch: function () {
    console.log('app 刚启动')
    // 展示本地存储能力
    // var logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)
    var _this = this;
    wx.getSystemInfo({
      success(res) {
        _this.systemInfo = res
      }
    })
    // 登录
    wx.login({
      success: res => {
        console.log(res)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
       // _this.getuniId(res.code)
        _this.code = res.code
        
      },fail(res) {
        console.log(res)
      }
    })
    // wx.getSetting({
    //   success(res) {
    //     if (!res.authSetting['scope.userInfo']) {
    //       wx.authorize({
    //         scope: 'scope.userInfo',
    //         success(res) {
    //           console.log('scope.userInfo')
    //           console.log(res)
    //         },
    //         fail(res) {
    //           wx.showModal({
    //             title: '警告',
    //             content: '您不授权将无法正常体验程序，请您确认',
    //             confirmText:"授权",
    //             cancelText:"不授权",
    //             success: function (res) {
    //               if (res.confirm) {
    //                 wx.openSetting({
    //                   success: function (res) {
    //                     if (!res.authSetting["scope.userInfo"]) {
    //                       //这里是授权成功之后 填写你重新获取数据的js
    //                       console.log('这里是授权成功之后 填写你重新获取数据的js')
    //                       console.log(res)
    //                     }
    //                   }
    //                 })
    //               } else if (res.cancel) {
    //                 console.log('用户点击取消')
    //               }
    //             }
    //           })
    //           console.log(res)
    //         }
    //       })
    //     }
    //   }
    // })
    // 获取用户信息
    // wx.getSetting({
    //   success: res => {
    //     console.log('授权')
    //     console.log(res)
    //     if (!res.authSetting['scope.userInfo']) {
    //       // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
    //       wx.getUserInfo({
    //         success: res => {
    //           console.log('拿用户信息')
    //           console.log(res)
    //           // 可以将 res 发送给后台解码出 unionId
    //           this.globalData.userInfo = res.userInfo

    //           // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
    //           // 所以此处加入 callback 以防止这种情况
    //           if (this.userInfoReadyCallback) {
    //             this.userInfoReadyCallback(res)
    //           }
    //         }
    //       })
    //     } else {
    //       console.log('拒绝获取')
    //     }
    //   }
    // })
  },
  globalData: {
    userInfo: null
  },
 
  getuniId(code) {
    // var _this = this
    // var appid ='wx9af75e08f31c2e10' ;//小程序唯一标识
    // var secret ='8b1378b97b4ed10eae7d93db8b560cee' ;//小程序的 app secret
    // var js_code = code;//登录时获取的 code
    // var grant_type ='authorization_code' //填写为 authorization_code
    // wx.request({
    //   url: `https://api.weixin.qq.com/sns/jscode2session?appid=${appid}&secret=${secret}&js_code=${js_code}&grant_type=${grant_type}`,
    //   method: 'GET', 
    //   data: {}, 
    //   success(res) {
    //     console.log(res)
    //     _this.userInfo = res
    //     var pc = new WXBizDataCrypt(appid, res.data.session_key)
    //     wx.authorize({
    //       scope: 'scope.userInfo',
    //       success() {
    //         // 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
        

    
    //     wx.getUserInfo({
    //       success: function (res) {
    //         console.log(11111)
    //         console.log(res)
    //         var data = pc.decryptData(res.encryptedData, res.iv)
    //         console.log('解密后 data: ', data)
    //         //         
    //       },
    //       fail(res) {
    //         console.log(res)
    //       }
    //     })
    //       }
    //     })
    //    // openid	用户唯一标识
    //    // session_key	会话密钥
    //    // unionid	用户在开放平台的唯一标识符。本字段在满足一定条件的情况下才返回。具体参看UnionID机制说明
    //   },
    //   fail(res) {
    //     console.log(res)
    //   }
    // })
  
  },
  //参数设定
  configApi: {
    appId:'wx4099604b04bf38d1',//小程序唯一标示
    cardId: 'pUWdBvxD7BqbMueQZ5sUnTvbv_TY', //暂时没用到，都是后台传递过来的
    baseUrl: 'https://wechat.muji.com.cn/',//https://20160829.team-lab.cn/ 开发机
    getcard:'wechat-java/mini/getcard',  //获取时间戳和签名
    getCardJump:'wechat-java/mini/getcardjump',//判断是否领过卡
    getCode:'wechat-java/mini/decryptCode',  //解码
    getUserInfo: 'wechat-java/mini/getUserInfo',  //获取unionid
    miniInfo:'wechat-java/mini/info', //获取muji个人用户信息
    addPoint:'wechat-java/mini/addPoint'//添加积分
  },
  code: '',
  cardIsFirst:false, //代表第一加载card页面的全部变量
  userInfo:'',
  hasAuthorization:false,//当前用户是否拒绝授权，默认没授权
  unionid:'', //用户unionid 后台获取
  openid:'',
  systemInfo:'',//设备信息
})
