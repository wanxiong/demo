import { $wuxCountUp } from '../components/wux'
var order = ['red', 'yellow', 'blue', 'green', 'red']
Page({
  data: {
    toView: 'red',
    scrollTop: 100,
    show:false,
    tabs: [
      { title: '选项一', content: '内容一' },
      { title: '选项二', content: '内容二' },
      { title: '选项三', content: '内容三' },
      { title: '选项四', content: '内容四' },
      { title: '选项五', content: '内容五' },
      { title: '选项六', content: '内容六' }
    ]
  },
  /**
* 生命周期函数--监听页面初次渲染完成
*/
  onReady: function () {
    //获得dialog组件
    this.c1 = new $wuxCountUp(1, 1024, 0, 50000, {
      printValue(value) {
        this.setData({
          c1: value,
        })
      }
    })

    this.c2 = new $wuxCountUp(0, 88.88, 2, 2, {
      printValue(value) {
        this.setData({
          c2: value,
        })
      }
    })

    this.c3 = new $wuxCountUp(0, 520, 0, 2, {
      printValue(value) {
        this.setData({
          c3: value,
        })
      }
    })

    this.c1.start()
    this.c2.start()

  },
  start() {
    this.c3.start(() => {
      wx.showToast({
        title: '已完成',
      })
    })
  },
  reset() {
    this.c3.reset()
  },
  update() {
    this.c3.update(1314)
  },
  pauseResume() {
    this.c3.pauseResume()
  },
  upper: function (e) {
    console.log(e)
  },
  lower: function (e) {
    console.log(e)
  },
  scroll: function (e) {
    console.log(e)
  },
  tap: function (e) {
    for (var i = 0; i < order.length; ++i) {
      if (order[i] === this.data.toView) {
        this.setData({
          toView: order[i + 1]
        })
        break
      }
    }
  },
  tapMove: function (e) {
    this.setData({
      scrollTop: this.data.scrollTop + 10
    })
  },
  tips() {
    this.setData({
      show: !this.data.show
    })
  },
  showToast() {
    let $toast = this.selectComponent(".J_toast")
    console.log($toast)
    $toast && $toast.show()
    
  },
  onClick: function (e) {
    console.log(`ComponentId:${e.detail.componentId},you selected:${e.detail.key}`);
  }
})