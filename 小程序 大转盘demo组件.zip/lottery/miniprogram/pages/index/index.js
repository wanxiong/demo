var plugin = requirePlugin("myPlugin")
Page({
  onLoad: function() {
    plugin.getData()
  },
  lotteryStart() {
    console.log('转动开始')
  },
  lotteryEnd() {
    console.log('转动结束')
  },
  aaa(event){
    console.log(event)
  }
})