var AnimFrame =  null ;
var rotateCount = 20 ;//转动的圈数
var eleCount = 8 ;//物品的总个数
var status = 0;
var stop = null;
var handelObj = null;
var i = 0;
var that = null
Component({
  data: {
    rotate:'0deg',
    btnImage:{},
    boxImage:{}
  },
  attached: function(){
    // 可以在这里发起网络请求获取插件的数据
    
  },
  properties: {
    myImage: { // 属性名
      type: String, 
      value: '', 
      observer: function (newVal, oldVal) { }
    },
    myBtnImage: { // 属性名
      type: String,
      value: '',
      observer: function (newVal, oldVal) { }
    }
  },
  methods: {
    start(event){
      this.triggerEvent('lotteryStart')
      that = this;
      var value = event.currentTarget.dataset.name
      var name = event.currentTarget.dataset.value
      if( !value && !name ) return false;
      AnimFrame = this.requestAnimFrame()
      handelObj = this.rand(value,name);
      this.toDo()

    },
    //
    toDo() {
      var s = that.bseBase(handelObj.p0, handelObj.p1, handelObj.p2, handelObj.p3,i / 600).y;
      that.setData({ rotate : `${s * 10 }deg`})
      if (i < 600) {
        i++;
      } else {
        status = 0;
        that.triggerEvent('lotteryEnd',)
        return false;
      }
      stop = AnimFrame(that.toDo)
    },
    //
     rand (value,name) {
      //贝塞尔控制点 p2 p3 控制速度
      var ele = value;
      var eleName = name;
      var jiaodu = (rotateCount * 360) + 360 - (ele) * (360 / eleCount)
      var p0 = { x: 0, y: 0, name: 'p0' }
      var p1 = { x: 300, y: 33, name: 'p1' }
      var p2 = { x: 0, y: jiaodu / 10, name: 'p2' }
      var p3 = { x: 600, y: jiaodu / 10, name: 'p3' }
      return { p0, p1, p2, p3, eleName}
    },
    //
    bseBase (p0,p1,p2,p3,t) {
       var x = p0.x * (1 - t) * (1 - t) * (1 - t) + p1.x * 3 * t * (1 - t) * (1 - t) + p2.x * 3 * t * t * (1 - t) + p3.x * t * t * t;
       var y = p0.y * (1 - t) * (1 - t) * (1 - t) + p1.y * 3 * t * (1 - t) * (1 - t) + p2.y * 3 * t * t * (1 - t) + p3.y * t * t * t;
       return { x: x, y: y }
     },
    clear () {
      if (cancelAnimationFrame) {
        cancelAnimationFrame(stop);//可以取消该次动画。
      }
      if (stop) {
        clearTimeout(stop)
      }
      this.setData({ rotate: '0deg' })
      stop = null;
      i = 0;
    },
    requestAnimFrame () {

      return requestAnimationFrame ||
        function (callback) {
          window.setTimeout(callback, 1000 / 60);
        };
    },
    //
    btn_load(event) {
      this.setData({btnImage:event.detail})
    },
    //
    box_load(event) {
      this.setData({ boxImage: event.detail })
    }
  }
})