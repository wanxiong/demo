var path = require('path');
module.exports = {
  apps: [{
    name: 'klcw',
    script: path.normalize(__dirname) + '/server/bin/www',

    // Options reference: https://pm2.io/doc/en/runtime/reference/ecosystem-file/
    autorestart: true,
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production'
    }
  }],

  deploy: {
    prd: {
      user: 'root',
      host: '172.16.9.28',
      ref: 'origin/master',
      repo: 'git@xdlgitlab.com:klcw-h5/klcw-app.git',
      path: '/home/project/klcw-h5',
      'post-deploy': 'git submodule foreach git pull && npm install && cd server && npm install && cd .. && npm run build && pm2 reload ecosystem.config.js --env production'
    }
  }
};
