module.exports = {
  pwa: {
    name: '酷乐潮玩',
    workboxOptions: {
      skipWaiting: true
    }
  },

  productionSourceMap: false,
  configureWebpack: {
    output: {
      filename: 'js/[name].[hash:6].js',
      chunkFilename: 'js/[name].[hash:6].js',
      libraryExport: 'default'
    },
    externals: {
    },
    plugins: []
  },
  chainWebpack: config => {
    config.plugins.delete('prefetch')
    config.plugins.delete('preload')
    if (process.env.NODE_ENV === 'production') {
      // 为生产环境修改配置...
      config
        .plugin('html')
        .tap(args => {
          args[0]['files'] = ['lib/vue.min.js', 'lib/fastclick.min.js', 'lib/vue-router.min.js']
          return args
        })
    } else {
      // 为开发环境修改配置...
      config
        .plugin('html')
        .tap(args => {
          args[0]['files'] = []
          return args
        })
    }
  },

  devServer: {
    proxy: {
      '/gateway': {
        target: 'http://172.16.9.12/gateway',
        changeOrigin: true,
        pathRewrite: {
          '^/gateway': ''
        }
      }
    }
  },

  outputDir: 'server/public',

  css: {
    loaderOptions: {
      css: {
        localIdentName: '[name]-[hash:6]',
        camelCase: 'only'
      },
      // 给全局scss注入该文件
      sass: {
        data: `@import "src/sass/tobe/function";`
      }
    }
  }
}

if (process.env.NODE_ENV == 'production') {
  module.exports.configureWebpack.externals = {
    'vue': 'Vue',
    'fastclick': 'FastClick',
    'vue-router': 'VueRouter'
  }
}
