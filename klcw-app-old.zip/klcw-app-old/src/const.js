import Vue from 'vue'
import utils from '@/utils'

let u = navigator.userAgent;
let isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; // android终端
let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); // ios终端

// variables
const SERVICE_BASE_URL = '/gateway'
const PLATFORM = isiOS ? 'iOS' : isAndroid ? 'Android' : ''
const BLAPP_URL = 'https://mh5.bl.com/static/appDownLoad.html?type=1&bl_ad=7201_-_345496_-_1'
const ISH5 = (u.toLowerCase().match(/iBailian/i) !== 'ibailian')

switch (location.host) {
  case 'localhost:8088': // 测试环境
    break;
  case 'mh5.ut.bl.com': // pre环境
    break;
  default:
}

// methods
const GET = arg => {
  return Vue.resource(SERVICE_BASE_URL).get({
    method: arg.method,
    params: btoa(JSON.stringify(arg.params))
  })
}
const POST = arg => {
  console.log(arg)
  return new Promise((resolve, reject) => {
    let sid = utils.getCookie('sid')
    let salt = utils.getCookie('salt')
    let timestamp = utils.getTimeFormatToday()
    let method = arg.method
    let params = btoa(JSON.stringify(arg.params))
    // 待签名数据
    let signedData = salt + method + params + 'sid' + sid + 'timestamp' + timestamp + salt
    crypto.subtle.digest({
      name: 'SHA-1'
    }, new Uint8Array(signedData)).then(e => {
      // 签名数据
      let sign = Array.prototype.map.call(new Uint8Array(e), function(e) {
        return (e < 16 ? '0' : '') + e.toString(16);
      }).join('')
      Vue.http.post(SERVICE_BASE_URL, {
        method,
        params,
        sid,
        salt,
        sign,
        timestamp
      }).then(res => {
        resolve(res)
      }, error => {
        reject(error)
      })
    })
  })
}

export default {
  SERVICE_BASE_URL, // 接口base地址
  PLATFORM, // 平台
  BLAPP_URL, // app下载页面
  ISH5, // 是APP环境还是H5环境
  GET,
  POST
}
