<template>
  <div id="app">
    <transition>
      <keep-alive :include="/keep/">
        <router-view class="page-content"></router-view>
      </keep-alive>
    </transition>
  </div>
</template>

<script>
export default {
  data() {
    return {
    }
  }
}
</script>
