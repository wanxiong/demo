import Vue from 'vue'
import FastClick from 'fastclick'
import VueLazyload from 'vue-lazyload'
import infiniteScroll from 'vue-infinite-scroll'
import VueResource from 'vue-resource'

import App from './App.vue'
import router from './router'
import directive from './directive'
import utils from '@/utils'
import bluer from './vue-bluer'

import './registerServiceWorker'
import '@/sass/comm.scss'
import '@/base'

// 如果设备系统大于iOS8则给html添加ios-gt-8类名
utils.iOS8DPI()

// FastClick 调用
FastClick.attach(document.body)

Vue.use(bluer)
Vue.use(infiniteScroll)
Vue.use(VueResource)
Vue.use(VueLazyload, {
  preLoad: 1.3,
  loading: require('@/assets/icon_banner_loading.png'),
  error: require('@/assets/icon_banner_loading.png'),
  attempt: 1 // default 1
})

Vue.config.productionTip = false

// Vue.http.options.xhr = { withCredentials: true }
// Vue.http.options.credentials = true;
Vue.http.options.emulateJSON = true
Vue.http.options.headers = {
  'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
}

// 指令 注册
Object.keys(directive).forEach((key) => {
  Vue.directive(`${key}`, directive[key])
})

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
