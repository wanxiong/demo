<template>
  <label class="switch" :class="[ 'switch-' + type ]">
    <input type="checkbox" v-model="currentValue" @change="$emit('change', currentValue)">
    <span></span>
    <span class="bg"></span>
  </label>
</template>

<style lang="scss">
  @import "src/sass/tobe/function";
  // / <label class="switch switch-red">
  // /   <input type="checkbox" checked="checked">
  // /   <span></span>
  // /   <span class="bg"></span>
  // / </label>
  // label.switch>input+span+span.bg


  .switch {
    position: relative;
    height: rem(56);
    width: rem(100);
    line-height: 1.45;
    display: inline-block;
  }
  .switch .bg {
    display: block;
    width: rem(96);
    height: rem(56);
    background-color: #fff;
    border: 1px solid #e6e6e6;
    border-radius: rem(40);
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
  }
  .switch > [type=checkbox] {
    opacity: 0;
    position: absolute;
  }
  .switch input + span {
    display: block;
    z-index: 2;
    position: absolute;
    top: 1px;
    left: 1px;
    width: rem(52);
    height: rem(52);
    border-radius: 50%;
    border: 1px solid #d7d7d7;
    background: white;
    box-shadow: 0 1px 1px rgba(0,0,0,.15);
    -webkit-transition: left 0.2s ease-out;
    -moz-transition: left 0.2s ease-out;
    transition: left 0.2s ease-out;
  }
  .switch input:checked + span {
    top: 1px;
    left: rem(40);
    border-color: white;
  }
  .switch input:checked ~ span.bg {
    background-color: #4cd964;
    background-image: -webkit-linear-gradient(to top, #4cd964, #4bd663);
    background-image: -moz-linear-gradient(to top, #4cd964, #4bd663);
    background-image: linear-gradient(to top, #4cd964, #4bd663);
    border-color: #4cd964;
  }
  @mixin switch-color($bgColor) {
    background-color: $bgColor;
    background-image: -webkit-linear-gradient(to top, $bgColor, darken($bgColor, 1%));
    background-image: -moz-linear-gradient(to top, $bgColor, darken($bgColor, 1%));
    background-image: linear-gradient(to top, $bgColor, darken($bgColor, 1%));
    border-color: $bgColor;
  }

  //如果输出至少两个不同颜色按钮，则调用下面的mixin

  @mixin switch-color-multi($colorLists: $switchColorClass){
    @each $color in $colorLists{
      $class:        nth($color,1);
      $bgColor:      nth($color,2);

      .switch.switch-#{"" + $class} input:checked ~ span.bg{
        @include switch-color($bgColor);
      }
    }
  }
  @include switch-color-multi();

</style>

<script>
export default {

  name: 'Switchs',

  data () {
    return {
      currentValue: this.value
    };
  },
  props: {
    type: {
      type: String,
      default: 'primary'
    },
    value: Boolean
  },

  watch: {
    value(val) {
      this.currentValue = val;
    },

    currentValue(val) {
      this.$emit('input', val);
    }
  }
};
</script>
