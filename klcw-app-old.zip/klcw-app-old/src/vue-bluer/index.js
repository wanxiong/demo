/*!
 * vue-bluer
 * (c) 2017 chen peng
 * Released under the MIT License.
 */
import Toast from './toast'
import ModalJs from './modal'

const keyName = 'k'
const syncComponents = [
  {
    name: 'Bar',
    path: require('./bar')
  },
  {
    name: 'Modal',
    path: require('./modal/modal')
  },
  {
    name: 'Navbar',
    path: require('./navbar')
  },
  {
    name: 'TabItem',
    path: require('./tab-item')
  },
  {
    name: 'Cell',
    path: require('./cell')
  }
]

const install = function(Vue) {
  if (install.installed) return;
  Vue.component(keyName + 'Button', resolve => {
    require(['./button'], resolve)
  })
  Vue.component(keyName + 'Slide', resolve => {
    require(['./slide'], resolve)
  })
  Vue.component(keyName + 'ScrollView', resolve => {
    require(['./scroll-view'], resolve)
  })
  syncComponents.forEach(item => {
    Vue.component(keyName + item.name, item.path.default || item.path);
  })

  window.$toast = Vue.$toast = Vue.prototype.$toast = Toast;
  Vue.$modal = Vue.prototype.$modal = ModalJs;
}

// auto install
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}

export default install
