<template>
  <div class="wrapper" ref="wrapper">
    <div class="content-box">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import BScroll from 'better-scroll'
export default {

  name: 'scrollView',

  props: {
    options: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  data () {
    return {
      scrollObj: null,
      defaultOptions: {
        mouseWheel: true,
        observeDOM: false,
        click: true
      }
    }
  },
  mounted() {
    let options = Object.assign(this.options, this.defaultOptions)
    this.scrollObj = new BScroll(this.$refs.wrapper, options)
  }
}
</script>
