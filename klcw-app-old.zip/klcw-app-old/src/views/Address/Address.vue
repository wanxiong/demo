<template>
  <div class="address">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
    <!-- <mt-field label="用户名" placeholder="请输入用户名"></mt-field>
    <mt-field label="邮箱" placeholder="请输入邮箱" type="email"></mt-field>
    <mt-field label="密码" placeholder="请输入密码" type="password"></mt-field>
    <mt-field label="手机号" placeholder="请输入手机号" type="tel"></mt-field>
    <mt-field label="网站" placeholder="请输入网址" type="url"></mt-field>
    <mt-field label="数字" placeholder="请输入数字" type="number"></mt-field>
    <mt-field label="生日" placeholder="请输入生日" type="date"></mt-field> -->
    <mt-button type="default">default</mt-button>
    <mt-button type="primary">primary</mt-button>
    <mt-button type="danger">danger</mt-button>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
// import { Field } from 'mint-ui';
// Vue.component(Field.name, Field);
export default {
  name: 'home',
  components: {
    HelloWorld
  }
}
</script>
