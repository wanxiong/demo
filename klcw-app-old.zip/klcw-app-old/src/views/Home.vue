<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
    <k-bar>
      <div slot="title">hello</div>
    </k-bar>
    <k-button>hello</k-button>
    <k-scroll-view class="classify" ref="leftScroll" :options="{bounce: false}">
      <ul class="classify-list">
        <li v-for="(item, index) in 10" class="hair" :key="index">{{ item }}</li>
      </ul>
    </k-scroll-view>
    <k-scroll-view class="classify-content" ref="rightScroll">
      <ul class="content-list">
        <li class="li-item" v-for="(item, index) in 10" :key="index">
          {{ item }}
        </li>
      </ul>
    </k-scroll-view>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'home',
  components: {
    HelloWorld
  }
}
</script>
