<template>
  <div>
    <label>用户名</label>
    <input id="user" type="text" value="9001" />
    <label>密码</label>
    <input id="password" type="password" value="123321" />
    <button id="btn-signin" @click="login">登录</button>
  </div>
</template>

<script>
import utils from '@/utils'
export default {

  name: 'Login',

  data () {
    return {
      userName: '9001',
      password: '123321'
    }
  },
  methods: {
    login() {
      utils.getCookie('sid') || this.$GET({
        method: 'ykcloud.user.by.worknums.password.login',
        params: {
          work_nums: this.userName,
          password: this.password,
          channel_num_id: 2
        }
      }).then(result => {
        console.log(result.body)
        if (result.body.code != 0) {
          alert("result");
          return;
        }
        utils.setCookie('sid', result.body.sid)
        utils.setCookie('salt', result.body.salt)
      })
      this.$POST({
        method: 'com.xdl.cn',
        params: {
          name: 'APP'
        }
      }).then(res => {
        console.log(res)
        alert(res.bodyText);
      })
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
