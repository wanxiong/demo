<template>
    <div>
        <div v-if="flag == 2">
            <div class="bg">
                <h1 class="logo" title="酷乐潮玩"><img src="./img/logo.png" alt=""></h1>
            </div>
            <form action="#" class="loginBtn" >  <!-- 用户名密码登录 -->
                <input id="user" type="text" value="" placeholder="请输入用户名"/>
                <input id="password" type="password" placeholder="请输入密码" value="" />
                <label class="forget-password">忘记密码</label>
                <button id="btn-signin" class="btn-signin" @click="login">登录</button>
            </form>
            <form action="#" class="loginBtn">  <!-- 手机验证码登录 -->
                <input class="user" type="text" value="" placeholder="请输入手机号"/>
                <div class="passmb"><input class="password passwordChange" type="password" placeholder="请输入验证码" value="" /><span class="line">|</span><span class="getCode">获取验证码</span></div>
                <button class="btn-signin" @click="login">登录</button>
            </form>
            <span class="loginAgreement">登录及表示同意《服务协议》</span>
        </div>

        <div>
            <form action="#" class="loginBtn">  <!-- 找回密码 -->
                <input id="user" type="text" value="" placeholder="请输入手机号"/>
                <div><input id="password" class="passwordChange" type="password" placeholder="请输入验证码" value="" /><span class="line">|</span><span class="getCode">获取验证码</span></div>
                <input class="passmb" type="text" placeholder="新密码   6-16字符">
                <button class="btn-signin" @click="login">重置密码</button>
            </form>
        </div>
    </div>
</template>
<script>
export default {
    name:"account",
    data (){
        return{
            flag:1
        }
    }
}
</script>
<style lang="scss" scoped>
@import "src/sass/tobe/function";
.bg{
    background: url(./img/bg2.png) no-repeat 0;
    align-items: center; justify-content: space-around; display: flex;
    background-size: cover;
    height: rem(520);
}
.logo {
    display: table;
    margin: 0 auto;
    img{
        width: rem(288);
        height: rem(188);
    }
}
.loginBtn{
  display: table;
  margin: 0 auto;
    input {
      width: rem(500);
      height: rem(70);
      display: block;
      font-size: rem(26);
      color: #333333;
      margin-top: rem(32);
      border-bottom:1px solid #F2F2F2;
    }
    input.passwordChange{width: rem(355);display: inline;}
    .getCode{
      font-size: rem(24);
      color: #FFC832;
    }
    .line{color: #999;margin: 0 rem(24) 0 0;}
    .passmb{margin-bottom: rem(80)}
    
}

.forget-password{
  display: block;
  text-align: right;
  font-size: rem(22);
  color: #999999;
  margin:rem(16) 0 rem(18);
}
.btn-signin{
  width: rem(500);
  height: rem(60);
  background: #FFC832;
  border-radius: 100px;
  font-size: rem(26);
  color: #333333;
  // margin-top: rem(64)
}
.loginAgreement {
    display: block;
    width: 100%;
    position: absolute;
    left: 0;
    bottom: rem(39);
    text-align: center;
    font-size: rem(24);
    color:#666;
}
</style>

</style>

