<template>
  <div class="login">
    <h1 title="酷乐潮玩" class="logo"><img src="./img/logo.png" alt=""></h1>
    <div class="loginBtn">
        <button>微信登录</button>
        <button>QQ登录</button>
        <ul class="accountNumber">
          <li>手机号登录</li>
          <li>账号登录</li>
        </ul>
    </div>
    <span class="loginAgreement">登录及表示同意《服务协议》</span>
    <div>
        <h1>{{ msg }}</h1>
    </div>
    <!-- <h1><router-link to="day1">跳转至HelloVue2332332323</router-link></h1> -->

    <form action="#" class="loginBtn" v-if="flag === 3">  <!-- 用户名密码登录 -->
      <input id="user" type="text" value="" placeholder="请输入用户名"/>
      <input id="password" type="password" placeholder="请输入密码" value="" />
      <label class="forget-password">忘记密码</label>
      <button id="btn-signin" @click="login">登录</button>
    </form>
    <form action="#" class="loginBtn" v-if="!flag==1">  <!-- 手机验证码登录 -->
      <input id="user" type="text" value="" placeholder="请输入手机号"/>
      <input id="password" class="passwordChange" type="passwordß" placeholder="请输入验证码" value="" /><span class="line">|</span><span class="getCode">获取验证码</span>
      <button id="btn-signin" @click="login">登录</button>
    </form>
    <form action="#" class="loginBtn" v-if="!flag==1">  <!-- 找回密码 -->
      <input id="user" type="text" value="" placeholder="请输入手机号"/>
      <input id="password" class="passwordChange" type="passwordß" placeholder="请输入验证码" value="" /><span class="line">|</span><span class="getCode">获取验证码</span>
      <input type="text" placeholder="新密码   6-16字符">
      <button id="btn-signin" @click="login">重置密码</button>
    </form>
    <span class="loginAgreement">登录及表示同意《服务协议》</span>
  </div>
</template>

<script>
import utils from '@/utils'
export default {
  name: 'index',
  data () {
    return {
      msg: '',
      flag: '1',
      userName: '9001',
      password: '123321'
    }
  },
  methods: {
    login() {
      utils.getCookie('sid') || this.$GET({
        method: 'ykcloud.user.by.worknums.password.login',
        params: {
          work_nums: this.userName,
          password: this.password,
          channel_num_id: 2
        }
      }).then(result => {
        console.log(result.body)
        if (result.body.code != 0) {
          alert("result");
          return;
        }
        utils.setCookie('sid', result.body.sid)
        utils.setCookie('salt', result.body.salt)
      })
      this.$POST({
        method: 'com.xdl.cn',
        params: {
          name: 'APP'
        }
      }).then(res => {
        console.log(res)
        alert(res.bodyText);
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@import "src/sass/tobe/function";
.login {
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0px;
  background-color: #FFC832;
}
.loginBtn button {
    display: table;
    margin: 0 auto;
    width: rem(340);
    height: rem(70);
    background: #fff;
    display: block;
    font-size: rem(30);
    color: #000;
    margin-bottom: rem(40);
    border-radius: 100px;
}
.logo {
    display: table;
    margin: 0 auto;  
    padding: rem(307) 0 rem(140);
  img{
    width: rem(288);
    height: rem(180);
  }
}


.accountNumber {
    margin-top: rem(40);
    font-size: rem(26);
    color: #333;
        li {
            display: inline;
            margin-right: rem(110);
        }
        li:last-child {
            margin-right: 0;
        }
}
.loginAgreement {
    display: block;
    width: 100%;
    position: absolute;
    left: 0;
    bottom: rem(39);
    text-align: center;
    font-size: rem(24);
    color:#666;
}

</style>
