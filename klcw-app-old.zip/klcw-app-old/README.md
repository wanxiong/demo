# klcw-h5

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run Express Server
```
npm run start
```

### Lints and fixes files
```
npm run lint
```

### 使用pm2启动Express服务 [pm2快速开始](https://pm2.io/doc/en/runtime/quick-start/)
```
pm2 start
```

### 克隆server子模块
```
git clone git@xdlgitlab.com:klcw-h5/klcw-app.git server
```

### 更新子模块
```
git submodule foreach git pull
```

### deploy发布部署
```
pm2 deploy prd
```

### 免密登录ssh
```
ssh-copy-id -i ~/.ssh/id_rsa.pub root@172.16.9.28
```
