'use strict'
module.exports = {
  NODE_ENV: '"PRODUCTION"',
  ENV_CONFIG:'"production"',
  BASE_URL: '"https://api.DYJ88c.lofter.com/"'
}
