'use strict'
module.exports = {
  NODE_ENV: '"STG"',
  ENV_CONFIG:'"stg"',
  BASE_URL: '"http://api.stg-darwin.lofter.com/"'
}
