'use strict'
module.exports = {
  NODE_ENV: '"LOCAL"',
  ENV_CONFIG:'"local"',
  BASE_URL: '"http://20150915.team-lab.cn/api/"'
}
