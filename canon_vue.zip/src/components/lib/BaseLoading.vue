<template>
  <div>
    <!-- loading 层 留出title-bar -->
    <div v-if="showTabbar == 'noFullBar'" class='loading' style='height: calc(100% - 64px);top: 64px;'>
      <div class='bg' style='
        height: 22vw;
        margin-top: -15vw;
        line-height: 22vw;
        '>
        <i class='icon ion-ios-film beat_heart'></i>
      </div>
    </div>
    <!-- loading 层 不留出title-bar -->
    <div v-if="showTabbar == 'fullBar'" class='loading' style='height: 100%;top:0;'>
      <div class='bg' style='
        height: 22vw;
        margin-top: -15vw;
        line-height: 22vw;
        '>
        <i class='icon ion-ios-film beat_heart'></i>
      </div>
    </div>
  </div>
</template>

<script type="text/javascript">
export default {
  name: 'Loading',
  data() {
    return {

    }
  },
  props: {
    showTabbar: {
      type: String,
      default: 'fullBar'
    }
  }
}
</script>

<style scoped>
  .loading{
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    text-align: center;
    z-index: 50;
    background-color: rgba(0,0,0,0.1);
  }
  .loading div.bg, .upload_img_success div.bg{
    position: relative;
    top: 50%;
    width: 30%;
    color: #FFF;
    border-radius: 8px;
    font-family: sans-serif;
    background-color: rgba(0,0,0,0.75);
    box-shadow: 5px 5px 9px -5px black;
    font-size: 3rem;
    margin: 0 auto;
  }
  .beat_heart{
    animation: spin 0.5s infinite linear;
  }
  @-webkit-keyframes spin /* Safari and Chrome */ {
    from {
      opacity:0;
    }
    to {
      opacity:1;
    }
  }
  @keyframes spin {
    from {
      opacity:0;
    }
    to {
      opacity:1;
    }
  }
  @keyframes loading_ball {
    from {
      font-size: 3rem;
      opacity:1;
    }
    to{
      font-size: 4rem;
      opacity:0;
    }
  }
  @-webkit-keyframes loading_ball {
    from {
      font-size: 3rem;
      opacity:1;
    }
    to{
      font-size: 4rem;
      opacity:0;
    }
  }
</style>
