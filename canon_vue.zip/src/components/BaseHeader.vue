<template>
  <div>
    <!-- 群主页 ==== 寻找群 -->
    <div class="ignore-groupSearch" v-if="showHead == 'groupSearch'" :style="{background: '#7F7F7F url('+ bgUrl +') no-repeat center/cover'}">
      <template name="groupSearch" >
        <van-nav-bar
          class="ignore-pg16 nobg"
          :title="title"
        >
          <van-icon name="arrow-left" class="ignore-2rem ion-ios-arrow-back ignore-init-ps-left" @click="left" slot="left" />
          <div slot="title" v-text="title" class="ignore-titleText"></div>
          <van-icon name="wap-nav" class="ignore-font30 ion-navicon ignore-init-ps-right" @click="right" slot="right" />
        </van-nav-bar>
      </template>
    </div>
    <!--  群主页 ==== 另一类 -->
    <div class="ignore-group" v-if="showHead == 'groupTimeline'">
      <template name="lala" >
        <van-nav-bar
          class="ignore-pg16"
          title="title"
          :fixed=true
        >
          <van-icon name="arrow-left" class="ignore-2rem ion-ios-arrow-back ignore-init-ps-left" @click="left" slot="left" />
          <van-icon name="wap-nav" class="ignore-font30 ion-navicon ignore-init-ps-right" @click="right" slot="right" />
        </van-nav-bar>
      </template>
    </div>
    <!--  通用类头部 只左边返回和右边菜单 -->
    <div class="ignore-group base-color" v-if="showHead == 'baseHead'">
      <template name="lala" >
        <van-nav-bar
          class="ignore-pg16 ignore-base-top nbg "
          :fixed=true
        >
          <van-icon name="arrow-left" class="ignore-2rem ion-ios-arrow-back ignore-init-ps-left" @click="left" slot="left" />
          <div slot="title" v-text="title" class="ignore-fs"></div>
          <van-icon name="wap-nav" class="ignore-font30 ion-navicon ignore-init-ps-right" @click="right" slot="right" />
        </van-nav-bar>
      </template>
    </div>
    <!--  通用类头部 只左边返回 -->
    <div class="ignore-group base-color" v-if="showHead == 'onlyleft'">
      <template name="lala" >
        <van-nav-bar
          class="ignore-pg16 ignore-base-top nbg "
          :fixed=true
        >
          <van-icon name="arrow-left" class="ignore-2rem ion-ios-arrow-back ignore-init-ps-left" @click="left" slot="left" />
          <div slot="title" v-text="title" class="ignore-fs"></div>
        </van-nav-bar>
      </template>
    </div>
  </div>
</template>

<script type="text/javascript">
export default {
  name: 'BaseHeader',
  data() {
    return {
      a: 1
    }
  },
  props: {
    showHead: {
      type: String,
      default: 'baseHead'
    },
    title: {
      type: String,
      default: ''
    },
    // 在groupSearch下，背景图片的URL
    bgUrl: {
      type: String,
      default: ''
    }
  },
  created() {

  },
  mounted() {

  },
  methods: {
    left() {
      this.$emit('left', '');
    },
    right() {
      this.$emit('right', '');
    }
  }
}
</script>

<style scoped>
  .ignore-groupSearch{
    position: fixed;
    width: 100%;
    z-index: 99;
    height: 20vh; /*no*/
    padding-top: 18px;
    line-height: 46px;
    color: #fff;
    font-size: 16px;
    /* background-color: #7F7F7F; */
    background-color: transparent;
    display: block;
    top: 0;
    transition: all .3s;
  }
  .ignore-group{
    position: fixed;
    width: 100%;
    z-index: 99;
    height: 64px; /*no*/
    padding-top: 18px;
    line-height: 46px;
    color: #fff;
    font-size: 16px;
    /* background-color: #7F7F7F; */
    background-color: transparent;
    display: block;
    top: 0;
    transition: all .3s;
  }
  .ignore-2rem{
    font-size: 2rem;
    color: #fff;
  }
  .ignore-font30{
    font-size: 30px;
    color: #fff;
  }
  .igonre-groupSearch > div{
    background-color: transparent;
  }
  .ignore-pg16{
  }
  .nobg{
    background-color: transparent !important;
  }
  .van-hairline--bottom:after{
    border-bottom-width: 0px;
  }
  .ignore-init-ps-left{
    padding: 0 10px;
  }
  .ignore-init-ps-right{
    padding: 0 10px;
  }
  .ignore-titleText{
    line-height: calc(20vh -18px);
  }
  .base-color{
    background-color:#7F7F7F;
  }
  .ignore-base-top{
    margin-top: 18px;
  }
  .ignore-fs{
    font-size: 18px;
  }
  .nbg{
    background-color: transparent;
  }
</style>
<style type="text/css">
  .ignore-groupSearch .van-nav-bar__left, .ignore-group .van-nav-bar__left{
    left: 5px !important;
  }
   .ignore-groupSearch .van-nav-bar__right, .ignore-group .van-nav-bar__right{
    right: 5px !important;
  }
</style>
