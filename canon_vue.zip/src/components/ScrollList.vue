<template>
  <van-list
    v-model="loading"
    :finished="finished"
    :offset="offset"
    :loading-text="loadingText"
    @load="onLoad"
  >
    <slot></slot>
  <van-cell
    v-for="item in list"
    :key="item"
    :title="item"
  />
</van-list>
</template>

<script>
export default {
  name: 'scrollList',
  data() {
    return {
      list: [],
      loading: false,
      finished: false
    }
  },
  props: {
    // 滚动条与底部距离小于 offset 时触发load事件
    offset: {
      type: Number,
      default: 20
    },
    // 加载中提示文案 default 加载中...
    loadingText: {
      type: String,
      default: ''
    }
  },
  methods: {
    onLoad() {
      this.$emit('scrollLoad');
    }
  },
  created() {

  }
}
</script>
<style scoped>
</style>
