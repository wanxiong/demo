let getImageThumbUrlReal = (imageUrl, types, custom) => {
  let arr;
  let h;
  let w;
  let interlace = 0;
  if (types === 'device-img') {
    w = h = Math.round(window.innerWidth * 0.5);
  } else if (types === 'waterFall-img') {
    w = Math.round(window.innerWidth * custom.w);
    h = Math.round(custom.h);
  } else if (types === 'device-img-small') {
    w = h = Math.round(window.innerWidth * 0.2);
  } else if (types === 'device-detail-img-small') {
    w = Math.round(window.innerWidth * 0.2);
    h = Math.round(window.innerWidth * 0.16);
  } else if (types === 'device-detail-img') {
    w = Math.round(window.innerWidth);
    h = Math.round(window.innerWidth * 0.8);
  } else if (types === 'device-detail-logo-img') {
    w = Math.round(window.innerWidth * 0.5);
    h = Math.round(window.innerWidth * 0.075);
  } else if (types === 'take-photos') {
    w = Math.round(window.innerWidth * 1.5);
    h = 0;
    interlace = 1;
  } else if (types === 'face') {
    w = h = Math.round(window.innerWidth * 0.4);
    return imageUrl + '?imageView&thumbnail=' + w + 'y' + h;
  } else {
    return '' + imageUrl;
  }
  if (imageUrl.indexOf('watermark&type') !== -1) {
    arr = imageUrl.split('?');
    return arr[0] + '?imageView&thumbnail=' + w + 'x' + h + '|' + arr[1] + '&interlace=' + interlace;
  } else {
    return imageUrl + '?imageView&thumbnail=' + w + 'x' + h + '&interlace=' + interlace;
  }
}

/* 缩略图
*@params {String imageUrl} 图片URl
*@params {String type} 需要裁剪成的类型
*@params {Object custom} 需要裁剪成的类型
*/
export let getImageThumbUrl = (imageUrl = '', type, custom) => {
  let backUrl;
  if (!imageUrl) { return '' };
  backUrl = getImageThumbUrlReal(imageUrl, type, custom);
  if (['device-img', 'device-detail-img', 'device-detail-img-small', 'device-detail-logo-img'].indexOf(type)) {
    backUrl = backUrl.replace('imageView', 'imageView&stripmeta=0&type=jpg');
  }
  return backUrl;
}
