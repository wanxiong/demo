const GroupCategoryList = res => require(['@/views/group/GroupCategoryList'], res);
let route = [{
  path: '/group/grouplist/:cateId/:categoryName',
  name: 'groupCategoryList',
  component: GroupCategoryList
}]

export default route;
