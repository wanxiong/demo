const Login = res => require(['@/views/login/login'], res);
let route = [{
  path: '/login',
  name: 'login',
  component: Login
}]

export default route;
