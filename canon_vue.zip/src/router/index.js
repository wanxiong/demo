import Vue from 'vue';
import Router from 'vue-router';
import Home from '@/views/Home';
import List from '@/views/List';
import TeacherRouter from './teacherRouter';
import GroupRouter from './groupRouter';
import LoginRouter from './loginRouter';
Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/list',
      name: 'List',
      component: List
    },
    ...TeacherRouter,
    ...GroupRouter,
    ...LoginRouter
  ]
});
