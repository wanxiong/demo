let route = [{
  path: '/teacher/teacherList',
  name: 'teacherList',
  component: function (resolve) {
    require(['@/views/teacher/teacherList'], resolve)
  }
},
{
  path: '/teacher/teacherDetail/:userId/:teacherId',
  name: 'teacherDetail',
  component: function (resolve) {
    require(['@/views/teacher/teacherDetail'], resolve)
  }
}]

export default route;
