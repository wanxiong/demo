var connectWebViewJavascriptBridge, COMPILE_OS;

if (window.hasOwnProperty('nativeApp')) {
  COMPILE_OS = 'android';
  window.DEVICE = '4';
} else {
  COMPILE_OS = 'ios';
  window.DEVICE = '2';
  if (window.screen.height > 736 && window.screen.height <= 812) {
    window.DEVICETYPE = 'X'
  } else {
    window.DEVICETYPE = '2'
  }
}

/*
Function for connection to Webview Javascript Bridge
@callback: Native的回调函数
 */
connectWebViewJavascriptBridge = function (callback) {
  if (window.WebViewJavascriptBridge) {
    callback(window.WebViewJavascriptBridge);
  } else {
    document.addEventListener('WebViewJavascriptBridgeReady', function () {
      callback(window.WebViewJavascriptBridge);
    }, false);
  }
};

/*
Function for connection to Webview Javascript Bridge
@callback: Native的回调函数
 */

connectWebViewJavascriptBridge(function (bridge) {
  console.log('got bridge');
  bridge.init(function (message, responseCallback) {
    var data;
    data = {
      'Javascript Responds': 'Wee!'
    };
    alert('got bridge init');
    responseCallback(data);
  });
  window.bridge = bridge;
});

/*
Call Func 方法
调用Native函数
@command: CallFunc命令
@param: 传入参数
@cb: 回调方法
 */

window.callFunc = function (command, param, cb) {
  var h, params, w;
  if (param.message === 'Code: 0') {
    param.message = 'Error:无网络';
  }
  if (command === 'setUser') {
    if (param.photoUrl) {
      w = h = Math.round(window.innerWidth * 0.5);
      param.photoUrl = param.photoUrl.replace(/.jpg.*/, '.jpg?imageView&thumbnail=' + w + 'x' + h);
    } else {
      param.photoUrl = '';
    }
  }
  if (COMPILE_OS === 'android') {
    if (command === 'setUser' || command === 'setKey') {
      return window.androidNative.send(command, JSON.stringify(param));
    } else if (command === 'snsShare') {
      return window.AndroidNativeExports.callNative(command, JSON.stringify(param), cb);
    } else {
      return window.nativeApp.send(command, JSON.stringify(param), cb);
    }
  } else {
    if (command === 'showPage') {
      window.location.href = param.url;
    } else {
      if (command === 'setLoading') {
        return console.log(command + ': ' + (JSON.stringify(param)));
      } else {
        if (window.bridge) {
          if (command === 'makeToast') {
            params = {
              msg: command,
              params: JSON.stringify({
                position: param.position,
                duration: param.duration,
                toast: param.message
              })
            };
          } else {
            params = {
              msg: command,
              params: JSON.stringify(param)
            };
          }
          window.bridge.send(params, function (r) {
            try {
              cb(JSON.parse(r));
            } catch (error) {
              cb(r);
            }
          });
        } else {
          switch (command) {
            case 'makeToast':
              console.log('Toast: ' + (JSON.stringify(param)));
              return console.log('' + param.Code);
            case 'isSnsInstall':
              let res = {'wechat': true, 'weibo': true, 'qq': true, 'lofter': true};
              return cb(res);
            case 'getPhonebook':
              return cb();
            case 'getKey':
              return cb();
            default:
              console.log(command);
          }
        }
      }
    }
  }
};
