import md5 from 'js-md5';
import {AUTHCDSEED, API_IDS} from './apiCfg';

/* API 调用authCd规则生成
* @params {String apiId} api编号
* @params {String userId} 用户id
*/
export let authCd = (apiId = '', userId = '') => {
  if (userId) {
    return md5(`DARWIN_API_${apiId}:${userId}:${AUTHCDSEED}`);
  } else {
    return md5(`DARWIN_API_${apiId}::${AUTHCDSEED}`);
  }
};

/* API 路径
* @params {String appCode} api编号
*/
export let url = appCode => {
  return `${API_IDS['DARWIN_API_' + appCode]}.do`;
}
