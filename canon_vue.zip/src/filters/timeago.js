import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/zh-cn';

dayjs.locale('zh-cn');
dayjs.extend(relativeTime);
export default value => {
  if (value === null || value === undefined || value === '') {
    return '';
  }
  return dayjs().from(dayjs(value));
};
