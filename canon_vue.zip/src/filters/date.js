import dayjs from 'dayjs';

export default (value, formatString = 'YYYY-MM-DD HH:mm:ss') => {
  if (value === null || value === undefined || value === '') {
    return '';
  }
  return dayjs(value).format(formatString);
};
