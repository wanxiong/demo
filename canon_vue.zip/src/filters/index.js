import Vue from 'vue'
import date from './date';
import timeago from './timeago';

let filters = {
  ...date,
  ...timeago
};

Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key]);
});
