<template>
  <div id="app" class="ignore_app">
    <keep-alive include="groupCategoryList">
      <router-view />
    </keep-alive>
  </div>
</template>

<script>
export default {
  name: 'App'
};
</script>

<style>
.box {
  color: #fff;
  text-align: center;
  width: 100%;
  background-color: #666;
}
#app{
  position: absolute;
  height: 100%;
  width: 100%;
  background-size: cover;
}
.ignore_app{
  left: 0;
  top: 0;
}
</style>
