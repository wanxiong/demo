import topic from './topic';

export default {
  topic
};
