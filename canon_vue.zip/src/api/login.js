import api from './resource';
/*
*  获取登录接口
*/
export let getLogin = params => {
  return api.post('1067', params);
};
