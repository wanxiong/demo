import axios from 'axios';
import qs from 'qs';
import {authCd, url} from '../apiconfig/utils'
// import router from '../router';
import store from '../store';
console.log(process.env);
// 创建实例
const Instance = axios.create({
  baseURL: process.env.BASE_URL,
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded'
  }
});

Instance.interceptors.request.use(
  config => {
    let data = {};
    try {
      data = (store.state.vuex && JSON.parse(store.state.vuex));
    } catch (err) {
    }
    // 根据请求方法构建请求参数和数据
    config.data.authCd = authCd(config.url, data.userId || localStorage.getItem('userId') || '');
    // config.data.device = window.DEVICE;
    config.data.uuid = '0';
    config.data.token = data.token || localStorage.getItem('token') || null;
    config.data.userId = data.userId || localStorage.getItem('userId') || null;
    config.data.ticket = data.ticket || localStorage.getItem('ticket') || null;
    config.data.sessionId = data.sessionId || localStorage.getItem('sessionId') || '0';
    config.url = url(config.url);
    config.data = qs.stringify(config.data);
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// http response 拦截器
Instance.interceptors.response.use(
  response => {
    if (response.status === 200) {
      let data = response.data;
      switch (data.status) {
        case '200':
          if (data.results.resultCd === '1') {
            window.callFunc('makeToast', {
              position: 'center',
              duration: '2.0',
              message: data.errorMsg
            });
            return Promise.reject(data);
          } else {
            return Promise.resolve(data);
          }
        case '401':
          console.log('401啦！返回到登录！');
          window.callFunc('makeToast', {
            position: 'center',
            duration: '2.0',
            message: data.errorMsg
          });
          localStorage.setItem('newMsgPush', '0');
          window.callFunc('clear', '');
          window.callFunc('showLogin', '');
          break;
        case '300':
          console.log('300啦！服务器维护中！');
          window.callFunc('showMaintenancePage', '');
          break;
        default :
          window.callFunc('makeToast', {
            position: 'center',
            duration: '2.0',
            message: data.errorMsg
          });
          break;
      }
      return Promise.reject(data);
    } else {
      window.callFunc('makeToast', {
        position: 'center',
        duration: '2.0',
        message: response.data.errorMsg
      });
      return Promise.reject(response.data);
    }
  },
  async error => {
    const data = error.response && error.response.data;
    return Promise.reject(data);
  }
);

export default Instance;
