import api from './resource';

// 名师一览list
export let getTeacherList = params => {
  return api.post('0030', params);
};
// 名师详情 文字
export let getTeacherDetail = params => {
  return api.post('0031', params);
};
// 名师详情 photo
export let getTeacherPhoto = params => {
  return api.post('0033', params);
};
