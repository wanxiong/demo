import Instance from './resource';

export default {
  // 获取话题列表
  getTopicList(params) {
    return Instance.get('/topics', { params });
  },
  getTopicDetail(topicId) {
    return Instance.get(`/topic/${topicId}`);
  }
};
