import api from './resource';
/*
*  获取群组分类一览
*/
export let getGroupCategoryList = params => {
  return api.post('1021', params);
};
