// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import './brige/brige';
import Vue from 'vue';
import App from './App';
import Vant from 'vant';
import router from './router';
import store from './store';
import api from './api';
import components from './components';
import loading from './components/lib/InstallLoading';
import './filters';
import 'vant/lib/vant-css/index.css';
import './assets/css/main.less';
import './assets/css/ionicons.min.css';

Vue.use(Vant);
Vue.use(loading);

Vue.prototype.$axios = api;
Vue.config.productionTip = false;

Object.keys(components).forEach(key => {
  Vue.component(key, components[key]);
});

// 同步local到store
store.dispatch('copyLocalAction');
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
});
