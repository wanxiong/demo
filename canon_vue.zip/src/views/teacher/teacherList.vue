<template>
    <div class="teacherList">
        <!-- <base-header :title="title"  :showHead="'baseHead'"  ></base-header> -->
        <div class="lists" v-for="(item,index) in teacherList" :key="index">
          <img :src="item.photoUrl" alt="" @click="goDetails(item.teacherId)">
        </div>
    </div>
</template>
<script>
// groupTimeline groupSearch baseHead onlyleft
import BaseHeader from '@/components/BaseHeader'
import {getTeacherList} from '@/api/teacher';
export default {
  name: 'teacherList',
  data() {
    return {
      // title: '影家名师',
      teacherList: []
    };
  },
  methods: {
    getlist() {
      // 实验userUId
      getTeacherList({userId: 741629}).then(res => {
        console.log(res)
        this.teacherList = res.results.teacher
      }).catch(err => {
        console.log(err);
      })
    },
    goDetails(teacherId) {
      this.$router.push({
        name: 'teacherDetail',
        params: {userId: 741629, teacherId: teacherId}
      })
    }
  },
  created() {
    this.getlist()
  },
  components: {
    BaseHeader
  }
};
</script>
<style lang="less" scoped>
  .teacherList{
     padding: 64px 0 20px 0;
    .lists{
      width: 100%;
      padding: 12px 0 0 0;
      overflow: hidden;
      img{
        width: 100%;
        border: none;
        float: left;
      }
    }
  }
</style>
