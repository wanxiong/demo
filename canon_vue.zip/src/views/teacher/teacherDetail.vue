<template>
  <div class="details">
    <div class="details_top">
        <div class="header" :style="{background: 'url('+ teacherList.photoUrl +') no-repeat center/cover'}">
            <div class="review" style="font-size: 23px;">请老师<br>点评</div>
        </div>
        <div class="teacher-introduce">
            <div class="ignore-name">{{teacherList.name}}</div>
            <div style="color:#505050;font-size: 3.96825vw;">{{teacherList.comment}}</div>
        </div>
    </div>
    <div class="ignore-details_bottom">
       <div class="waterfall">
          <div class="grid__item" v-for="(item,index) in teacherList.laoshiPhoto" :key="index">
            <img :src="item.url" alt="" >
          </div>
       </div>
    </div>
  </div>
</template>
<script>
import {getTeacherDetail} from '@/api/teacher';
export default {
  name: 'teacherList',
  data() {
    return {
      key: '',
      teacherList: {}
    };
  },
  methods: {
    getDetails() {
      let params = {
        userId: this.$route.params.userId,
        teacherId: this.$route.params.teacherId,
        start: 1,
        count: 15
      }
      getTeacherDetail(params).then(res => {
        this.teacherList = res.results
        console.log(this.teacherList)
      }).catch(err => {
        console.log(err);
      })
    }
  },
  created() {
    this.getDetails()
  }
};
</script>
<style lang="less" scoped>
.details{
  padding: 64px 0 0 0;
  letter-spacing: 0.1em;
  line-height: 1.5;
  .details_top{
    .header{
      width: 100vw;
      height: 52.8vw;
      background-color: red;
      .review{
        position: relative;
        float: right;
        width: 33vw;
        height: 28vw;
        bottom: -38.8vw;
        background-color: #ec681f;
        color: white;
        padding-top: 4vw;
        text-align: center;
      }
    }
    .teacher-introduce{
      padding: 0 25px;
      width: 100vw;
      .ignore-name{
         font-size: 35px;
         margin: 15px 0;
         color: #505050;
      }
    }
  }
  .ignore-details_bottom{
    margin: 30px 0 12px 0;
    width: 100%;
    .waterfall{
      -moz-column-count:2; /* Firefox */
      -webkit-column-count:2; /* Safari 和 Chrome */
      column-count:2;
      column-gap: 4px;
      .grid__item{
        margin: 0px 0px 4px;
        -moz-page-break-inside: avoid;
        -webkit-column-break-inside: avoid;
        width: 100%;
        break-inside: avoid;
        img{
            width: 100%;
            vertical-align: middle;
        }
      }
    }
  }
}
</style>
