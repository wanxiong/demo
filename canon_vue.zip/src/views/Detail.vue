<template>
  <div class="detail">
    <div v-html="detail.content"></div>
  </div>
</template>

<script>
export default {
  name: 'Detail',
  data() {
    return {
      detail: {}
    };
  },
  methods: {
    async fetchDetail() {
      try {
        const res = await this.$api.topic.getTopicDetail(this.$route.params.id);
        this.$set(this, 'detail', res);
      } catch (err) {
        console.log(err);
      }
    }
  },
  mounted() {
    console.log(111);
    this.fetchDetail();
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.detail {
  font-size: 14px;
}
</style>
