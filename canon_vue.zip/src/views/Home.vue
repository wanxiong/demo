<template>
  <div>
    <div class="icon-wechat">
      <base-icon name="wechat"></base-icon>
    </div>
    <div @click="goGroupList" style="font-size: 20px;">群的一栏测试demo</div>
    <van-button type="primary" @click="$router.push({name: 'List'})">话题列表</van-button><br>
    <van-button type="primary" @click="$router.push({name: 'login'})">登录页</van-button>
    <div>
      <van-button round type="danger" @click="$router.push({name: 'teacherList'})">名师一览</van-button>
    </div>
  </div>
</template>

<script>
import {mapState, mapActions} from 'vuex'
export default {
  name: 'Home',
  mounted() {
  },
  computed: {
    ...mapState([
      'test'
    ])
  },
  // computed: {
  //   ...mapState({
  //     'test':state => {
  //       console.log(state.auth.test);
  //       return state.auth.test;
  //     }
  //   })
  // },
  created() {
  },
  methods: {
    goGroupList() {
      // this.testAction('我是测试数据');
      this.$router.push({name: 'groupCategoryList', params: {cateId: '1', categoryName: '季节'}});
    },
    ...mapActions([
      'testAction'
    ])
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
.icon-wechat{
  width: 120px;
  height: 120px;
  margin: 0 auto;
}
</style>
