<template>
  <div>
    <div>
      <input type="input" name="" placeholder="请输入账号" v-model="mobilephone">
    </div>
    <input type="password" name="" placeholder="请输入密码" v-model="password">
    <button class="ignore-login" @click="login">{{txt}}</button>
  </div>
</template>

<script type="text/javascript">
import {getLogin} from '@/api/login';
export default {
  data() {
    return {
      mobilephone: '',
      password: '',
      txt: '点击登录'
    }
  },
  methods: {
    login() {
      this.$loading.show();
      this.txt = '别点了，我在发请求';
      console.log('开始登录');
      getLogin({
        mobilephone: this.mobilephone,
        password: this.password,
        stateType: 2,
        countryCd: 86,
        channelCd: null
      })
        .then(res => {
          alert('登录成功,你可以手动更改路由了');
          console.log(res)
          localStorage.setItem('expireTime', `${res.results.expireTime}`);
          localStorage.setItem('flagUserId', `${res.results.userInfo.userId}`);
          localStorage.setItem('nickName', `${res.results.userInfo.nickName}`);
          localStorage.setItem('nonce', `${res.results.nonce}`);
          localStorage.setItem('photoUrl', `${res.results.expireTime}`);
          localStorage.setItem('sericePushSignature', `${res.results.signature}`);
          localStorage.setItem('stageId', `${res.results.userInfo.stageId}`);
          localStorage.setItem('ticket', `${res.results.ticket}`);
          localStorage.setItem('token', `${res.results.userInfo.accessToken}`);
          localStorage.setItem('userId', `${res.results.userInfo.userId}`);
          localStorage.setItem('photoUrl', `${res.results.userInfo.photoUrl}`);
          localStorage.setItem('copy_right', `${res.results.userInfo.copyrightStatus}`);
          localStorage.setItem('officialFlag', `${res.results.userInfo.officialFlag}`);
          localStorage.setItem('avatar_url', `${res.results.userInfo.photoUrl}`);
          if (!res.results.userInfo.pushMsgFlg) {
            localStorage.setItem('notificationPush', `off`);
          }
          this.$loading.hide();
          window.history.back();
        })
        .catch(res => {
          this.$loading.hide()
          alert('登录失败')
        })
    }
  }
}
</script>

<style type="text/css" scoped>
  .ignore-login{
    margin: 50px;
    color: red;
  }
</style>
