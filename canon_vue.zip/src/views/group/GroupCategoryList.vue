<template>
  <keep-alive include="GroupCategoryList">
    <div class="ignore-group-category-list">
      <!-- header start -->
      <base-header :title="param.categoryName" :bgUrl="groupImgUrl" :showHead="'groupSearch'" @left="back" @right="menu" ref="groupHeader"></base-header>
      <!-- header end -->
      <!-- scroll view start -->
      <scroll-list @scrollLoad="scrollLoad" ref="Scroll" :offset="30" class="ignore-list-item">
        <div class="group-list" v-for="item in list" :key="item.groupId" @click="gowechat(item.groupId)">
          <div :style="{background: 'url('+ thumbnail(item.groupImgUrl) +') no-repeat center/cover'}"></div>
          <p class="tip ignore-font14" v-text="item.categoryName"></p>
          <p v-text="item.title" class="title"></p>
          <div class="joinAbout ignore-font14">
            <p>
              <img src="../../assets/img/index_num.png">
              <span v-text="item.memberCnt"></span>
            </p>
            <p>
              <img src="../../assets/img/index_info.png">
              <span v-text="item.messageCnt"></span>
            </p>
          </div>
        </div>
      </scroll-list>
      <!-- scroll view end -->
      <div>aaa {{groupImgUrl}}</div>
    </div>
  </keep-alive>
</template>

<script>
import {getGroupCategoryList} from '@/api/group';
import {getImageThumbUrl} from '@/utils/index';
import BaseHeader from '@/components/BaseHeader'
import ScrollList from '@/components/ScrollList'
import {mapState} from 'vuex'
export default {
  name: 'GroupCategoryList',
  data() {
    return {
      category: {},
      list: [],
      param: {},
      bgUrl: '',
      start: 1, // 每页请求的起始位置
      count: 7 // 每页请求的数量
    };
  },
  created() {
    this.param = {
      ...this.$route.params
    };
    // this.bgUrl = localStorage.getItem('groupImgUrl');
    window.callFunc('listenToBack', {
      'back': true}, () => {
      window.history.back()
    });
  },
  computed: {
    ...mapState([
      'groupImgUrl'
    ])
  },
  methods: {
    infoList() {
      let param = {
        categoryId: this.param.cateId,
        page: this.start,
        count: this.count
      };
      getGroupCategoryList(param).then(res => {
        let arr = res.results.list;
        this.list = this.list.concat(arr);
        if (arr.length < this.count) {
          this.$refs['Scroll'].finished = true;
          this.$refs['Scroll'].loading = false;
        } else {
          this.start += this.count;
          this.$nextTick(() => {
            this.$refs['Scroll'].loading = false;
          });
        }
      }).catch(err => {
        console.log(err);
      })
    },
    thumbnail(url) {
      let Url = getImageThumbUrl(url, 'take-photos');
      return Url;
    },
    back(param) {
      window.history.back();
    },
    menu(param) {
      // console.log('showSideBar');
      window.callFunc('showSideBar', '');
    },
    gowechat(groupid) {
      window.callFunc('showGroupChat', {groupId: groupid,
        isBack: 0
      })
    },
    scrollLoad() {
      this.infoList();
    },
    watchScroll() {
      var scrollTop = this.$refs['Scroll'].$el.scrollTop;
      if (scrollTop > 44) {
        // this.$refs.groupHeader
        this.$refs.groupHeader.$el.children[0].style.height = '64px';
        this.$refs.groupHeader.$el.children[0].childNodes[0].childNodes[1].childNodes[0].style.lineHeight = '46px';
      } else {
        this.$refs.groupHeader.$el.children[0].style.height = '20vh';
        this.$refs.groupHeader.$el.children[0].childNodes[0].childNodes[1].childNodes[0].style.lineHeight = 'calc(20vh - 18px)';
      }
    }
  },
  mounted() {
    // this.infoList();
    this.$refs['Scroll'].$el.addEventListener('scroll', this.watchScroll, false);
  },
  beforeDestroy() {
    console.log('destroy');
    this.$refs['Scroll'].$el.removeEventListener('scroll', this.watchScroll, false);
  },
  components: {
    BaseHeader,
    ScrollList
  }
}
</script>

<style scoped>
  .group-list{
    position: relative;
    margin: 0 20px;
    background-color: #fff;
  }
  .group-list > div:nth-of-type(1){
    height: 25vh;
    border-radius: 10px;
  }
  .group-list{
    margin-top: 15px;
  }
  .ignore-group-category-list{
    /* padding-top: 20vh; */
    background-color: #f5f5f5;
    position: absolute;
    width: 100%;
    height: calc(100%);
    overflow: scroll;

  }
  .group-list .tip{
    position: absolute;
    left: 20px;
    top: 2vh;
    padding-right: 20px;
    color: #fff;
    background-color: #adbacc;
    border-top-right-radius: 21px;
    border-bottom-right-radius: 21px;
    line-height: 42px;
    padding-left: 10px;
  }
  .ignore-font14{
     font-size: 14px;
  }
  .group-list .title{
    margin-top: 10px;
    text-align: left;
    width: 100% ;
    padding: 0 15px;
    font-size: 36px;
  }
  .joinAbout{
    color: #8d8c8c;
    padding: 8px 15px 10px;
  }
  .joinAbout > p {
    display: inline-block;
  }
  .joinAbout > p:nth-of-type(1) {
    margin-right: 10%;
  }
  .joinAbout img{
    width: 29px;
    height: 25px;
  }
  .ignore-list-item{
    height: 100%;
    overflow: scroll;
    padding-top: 20vh;
  }
</style>
