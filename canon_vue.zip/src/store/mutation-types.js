// 登录成功
export const LOGIN_SUCCESS = 'auth/LOGIN_SUCCESS';

// 退出登录
export const LOGOUT_SUCCESS = 'auth/LOGOUT_SUCCESS';

// 测试数据
export const TEST = 'TEST';

//
export const COPYLOCAL = 'COPYLOCAL';
