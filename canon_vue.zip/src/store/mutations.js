import * as types from './mutation-types';
const mutations = {
  [types.LOGIN_SUCCESS](state, user) {
    // 存储user
    state.user = user;
  },
  [types.LOGOUT_SUCCESS](state) {
    // 清除本地数据
    state.user = {};
  },
  [types.TEST](state, test) {
    // 添加本地测试数据
    state.test = test;
  },
  [types.COPYLOCAL](state, data) {
    for (let key in data) {
      if (key !== 'vuex') {
        state[key] = data[key];
      }
    }
  }
};

export default mutations;
