const state = {
  user: {},
  test: null
};

export default state;
