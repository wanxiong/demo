import Vue from 'vue';
import Vuex from 'vuex';
import createVuexLogger from 'vuex/dist/logger';
import createPersistedState from 'vuex-persistedstate';
// import auth from './modules/auth';
import state from './state';
import * as actions from './actions';
import mutations from './mutations';
import getters from './getters';
// const debug = process.env.NODE_ENV !== 'production';
const debug = process.env.NODE_ENV !== 'PRODUCTION';

Vue.use(Vuex);
const store = new Vuex.Store({
  // modules: {
  //   auth: {
  //     state,
  //     actions,
  //     getters,
  //     mutations
  //   }
  // },
  state,
  actions,
  getters,
  mutations,
  strict: debug,
  plugins: debug
    ? [
      createVuexLogger(),
      createPersistedState({
        storage: window.localStorage
      })
    ]
    : [
      createPersistedState({
        storage: window.localStorage
      })
    ]
});

export default store;
