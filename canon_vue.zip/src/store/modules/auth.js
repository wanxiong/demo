import * as types from '../mutation-types';

const state = {
  user: {}
};

const getters = {
  user: state => state.user
};

const actions = {
  loginAction({ commit }, userData) {
    commit(types.LOGIN_SUCCESS, userData);
  },
  logoutAction({ commit }) {
    commit(types.LOGOUT_SUCCESS);
  }
};

const mutations = {
  [types.LOGIN_SUCCESS](state, user) {
    // 存储user
    state.user = user;
  },
  [types.LOGOUT_SUCCESS](state) {
    // 清除本地数据
    state.user = {};
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};
