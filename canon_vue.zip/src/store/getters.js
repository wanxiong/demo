const getters = {
  user: state => state.user,
  test: state => state.test
};

export default getters;
