import * as types from './mutation-types'
// 登录
export const loginAction = ({ commit }, userData) => {
  commit(types.LOGIN_SUCCESS, userData);
}
// 登出
export const logoutAction = ({ commit }) => {
  commit(types.LOGOUT_SUCCESS);
}
// 测试数据
export const testAction = ({ commit }, test) => {
  commit(types.TEST, test);
}
// 同步本地数据
export const copyLocalAction = ({ commit }) => {
  console.log('同步数据');
  let local = localStorage;
  commit(types.COPYLOCAL, local);
}
