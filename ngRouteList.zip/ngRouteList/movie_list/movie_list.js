


(function(){

	var movieList = angular.module('movieList',['serviceModel']);
		var start = 0,
			count = 9,
			isTrue = true;
		 movieList.controller('movieListController',function($scope,serviceModel){
		
			serviceModel.getInTheaters(start,count,function(data){
				$scope.data = data.subjects
				start ++
			})
			//
			$(document).scroll(function(){
				var scrollTop = $(document).scrollTop()
				var bodyH = $('body').height()
				var height = $(window).height()
				if( bodyH > height + scrollTop - 30){
					
					if(isTrue){
						start ++
						start = (start - 1) * 9
						isTrue = false
						serviceModel.getInTheaters(start,count,function(data){
						
					 		$scope.title = data.title
					 		$scope.data = data.subjects
					 		isTrue = true
					 	})
				 	}
				}
			})
			//
		 })




})()