


(function(){

	var movieArtical = angular.module('movieArtical',['serviceModel']);

		 movieArtical.controller('movieArticalController',function($scope,serviceModel){
		 	var start = 0,
				count = 9,
				isTrue = true;
		 		
		 	serviceModel.getComingSoon(start,count,function(data){
		 		$scope.title = data.title
		 		$scope.data = data.subjects
		 		start ++
		 	})
			//
			$(document).scroll(function(){
				var scrollTop = $(document).scrollTop()
				var bodyH = $('body').height()
				var height = $(window).height()
				if( bodyH > height + scrollTop - 30){
					
					if(isTrue){
						start ++
						start = (start - 1) * 9
						isTrue = false
						serviceModel.getComingSoon(start,count,function(data){
						
					 		$scope.title = data.title
					 		$scope.data = data.subjects
					 		isTrue = true
					 	})
				 	}
				}
			})
			//
			
		 })




})()