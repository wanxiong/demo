


(function(){

	var movieTop = angular.module('movieTop',['serviceModel']);

		 movieTop.controller('movieTopController',function($scope,serviceModel){
		 	var start = 0,
				count = 9,
				isTrue = true;
			serviceModel.getTop250(start,count,function(data){
				$scope.title = data
				$scope.data = data.subjects;
				start++
			})
			//
			$(document).scroll(function(){
				var scrollTop = $(document).scrollTop()
				var bodyH = $('body').height()
				var height = $(window).height()
				if( bodyH > height + scrollTop - 30){
					
					if(isTrue){
						start ++
						start = (start - 1) * 9
						isTrue = false
						serviceModel.getTop250(start,count,function(data){
						
					 		$scope.title = data.title
					 		$scope.data = data.subjects
					 		isTrue = true
					 	})
				 	}
				}
			})
			//
		 })




})()