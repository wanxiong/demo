
(function(){

	var main = angular.module('main', ['ngRoute','movieList','movieArtical','movieTop']);
		main.config(function($routeProvider){
			$routeProvider
				.when('/movieList',{
					templateUrl:"movie_list/movie_list.html",
					controller :"movieListController",
				})
				.when('/movieListArtical',{
					templateUrl:"movieartical/movieArtical.html",
					controller :"movieArticalController",
				})
				.when('/movieTop',{
					templateUrl:"movietop/movieTop.html",
					controller :"movieTopController",
				})
				.otherwise({
					redirectTo:'/movieList',
				})
		})
		
    	
})()