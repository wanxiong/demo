//日期控件初始化
    	$(function(){
    		var isNewDate = new Date();
    		var isYear = isNewDate.getFullYear();
    		var isMonth = isNewDate.getMonth() + 1;
    		var isDay = isNewDate.getDate();
    		var minTime = '1902/01/01',maxTime = '2900/01/01' ;
    		isMonth = isMonth < 10 ? '0' + isMonth : isMonth
			isDay = isDay < 10 ? '0' + isDay : isDay
			var nowTime = isYear + '/' + isMonth + '/' + isDay
	    	$("#endTimeBox").DateTimePicker({
	            "maxDate":maxTime,
	            "minDate":minTime,
	            "defaultDate":nowTime,
	            "value":null,
	            "dateSeparator":'/',
	            "custom":{
	                "ele":$('#endTimeBoxVal')}})
	         $("#startTimeBox").DateTimePicker({
	            "maxDate":maxTime,
	            "minDate":minTime,
	            "defaultDate":nowTime,
	            "value":null,
	            "dateSeparator":'/',
	            "custom":{
	                "ele":$('#startTimeBoxVal')}})
    	})