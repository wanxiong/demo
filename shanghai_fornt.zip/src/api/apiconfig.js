export var imgUrl = 'http://www.lhsgy.com/'
export var uploadUrl = 'http://shan.bangyiwl.com:8088/'
export var shareUrl = 'http://www.lhsgy.com/index?share='

