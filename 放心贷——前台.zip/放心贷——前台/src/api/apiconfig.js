export var imgUrl = 'http://jiu.dxcqp.com/'
export var uploadUrl = 'http://jiu.dxcqp.com/'
export var shareUrl = 'http://jiu.dxcqp.com/index?share='

