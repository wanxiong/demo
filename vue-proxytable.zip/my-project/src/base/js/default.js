/* 给当前的元素增加属性或者获得其制定的属性
 * @params { Object }  el     元素对象
 * @params { String }  name   获取元素属性对应的属性值  //  data-index  只取index默认格式
 * @params { String }  value  给当前的元素对应的属性添加值
*/
export function getDataAtt(el , name , value ) { 
	const prefix = 'data-'
	if( value ){
		return el.setAttribute(prefix + name , value )
	} else{
		return el.getAttribute(prefix + name)
	}
}

let elementStyle = document.createElement('div').style

let vendor = (() => {
  let transformNames = {
    webkit: 'webkitTransform',
    Moz: 'MozTransform',
    O: 'OTransform',
    ms: 'msTransform',
    standard: 'transform'
  }

  for (let key in transformNames) {
    if (elementStyle[transformNames[key]] !== undefined) {
      return key
    }
  }

  return false
})()


/* 给当前的元素增加属性或者获得其制定的属性
 *
 *
*/

export function prefix(style) {
	if( !vendor ) return '';

	if (vendor === 'standard') {
    	return style
  	}

  	return vendor + style.charAt(0).toUpperCase() + style.substr(1)
}	


/* 数组乱序
 *
*/
export function shuffle (arr) {
  let _arr = arr.slice()
  for( var i = 0 ; i < _arr.length ; i++ ){
    let j = getRandomInt(0 , i)
    let t = _arr[i]
        _arr[i] = _arr[j]
        _arr[j] = t
  }
  return _arr
} 

function getRandomInt(min , max) {
  return Math.floor( Math.random() * (max - min + 1) + min )

}

export function findIndex (list ,song) {
  list.findIndex((item)=>{
      return item.id === song.id
  })
}

export function filterSinger (singer) {
  let ret = []
  if(!singer){
    return ''
  }
  singer.forEach((value)=>{
    ret.push(value.name)
  })

  return ret.join('/')
}