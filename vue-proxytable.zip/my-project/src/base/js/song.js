import {getLyric } from '@/api/common'
import {ERR_OK } from '@/api/config'
import {Base64} from 'js-base64'
export default class Song{
	constructor({id, mid , singer , name , ablum ,duration ,image , url}) {
		this.id = id
		this.mid = mid
		this.singer = singer
		this.name = name
		this.ablum = ablum
		this.duration = duration
		this.image = image
		this.url = url
	}
}

export function createSong (musicData) {
	return new Song({
		 id: musicData.songid,
	    mid: musicData.songmid,
	    singer: filterSinger(musicData.singer),
	    name: musicData.songname,
	    album: musicData.albumname,
	    duration: musicData.interval,
	    image: `https://y.gtimg.cn/music/photo_new/T002R300x300M000${musicData.albummid}.jpg?max_age=2592000`,
	    url: `http://ws.stream.qqmusic.qq.com/${musicData.songid}.m4a?fromtag=46`
	})
}

export function filterSinger (singer) {
	let ret = []
	if(!singer){
		return ''
	}
	singer.forEach((value)=>{
		ret.push(value.name)
	})

	return ret.join('/')
}
//获取歌词详情
export function initLyric(mid) {
	return new Promise( (resolve , reject ) => {
		getLyric(mid).then( (res) => {
			if( res.retcode === ERR_OK) { 
				return resolve(Base64.decode(res.lyric))
			} else {
				console.log('歌词请求错误或者没有歌词')
				return reject('')
			}
		})
	})
}