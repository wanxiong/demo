import Vue from 'vue'
import Router from 'vue-router'
import Hello from 'components/Hello'
import Recommend from 'components/recommend/recommend'
import Singer from 'components/singer/singer'
import SingerDetail from 'components/singer/singer-detail'
import Rank from 'components/rank/rank'
import Search from 'components/search/search'
import Disc from 'components/recommend/disc'
import RankDetail from 'components/rank/rank-detail'
/********************************************************** 
 *   后期路由太多的话，可以分成多个路由的小模块。         *
 *   然后统一导出，在这里面导入，                         *
 *   var route = [...router1,...router2,router3,router4]  *
 *   export default new Router({routes : route })         *
 ***********************************************************/
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Hello',
      redirect:'recommend'
    },
    {
	    path: '/recommend',
      name: '推荐',
      component: Recommend,
      children: [
        {
          path: ':id',
          component: Disc
        }
      ]
    },
    {
	  path: '/singer',
      name: '歌手',
      component: Singer,
      children:[{
        path:':id',
        component:SingerDetail
      }
      ]

    },
    {
	  path: '/rank',
      name: '排行',
      component: Rank,
      children:[{
        path:':id',
        component:RankDetail
      }]
    },
    {
	  path: '/search',
      name: '搜索',
      component: Search
    }
  ]
})
