import * as types from '@/store/mutation-type'
import {playMode } from '@/base/js/config'
import {shuffle , findIndex } from '@/base/js/default'
// 获取推荐图片轮播更新
export const saveRecommendImageList = ({commit} , res ) => {
	commit(types.SET_RECOMMEND_IMAGE_LIST , res.data.slider)
}
// 获取推荐列表更新
export const saveRecommendList = ({commit} , list ) => {
	commit(types.SET_RECOMMENDLIST , list)
}
// 获取推荐列表更新
export const saveRecommendDisc = ({commit} , list ) => {
	commit(types.SET_RECOMMEND_DISC , list)
}
// 获取歌手列表
export const saveSingerList = ({commit} , res) => {
	commit(types.SET_SINGER_LIST , res.data)
}
// 获取歌手详情
export const saveSingerDetailList = ({commit} , res) => {
	commit(types.SET_SINGER_DETAIL_LIST , res.data)
} 
//是否显示组件player { Boolean }
export const saveTransPlayer = ({commit} , isTrue ) =>{
	commit(types.SET_IS_SHOW_PLAYER , isTrue)
}
//切换播放还是暂停状态  { Boolean }
export const saveTransPause = ({commit} , isTrue) => {
	commit(types.SET_IS_PAUSE , isTrue)
}
export const selectPlay = ({commit , state } , {list,index})=>{
	//修改一些状态
	commit(types.SET_SEQUENCE_LIST,list)
	if( state.mode === playMode.random ) {
		let randomList = shuffle(list)
		let listIndex = findIndex(list , list[index])
		commit(types.SET_PLAY_LIST,randomList)
		commit(types.SET_CURRENT_INDEX,listIndex)
	} else{
		commit(types.SET_PLAY_LIST,list)
		
	}
	commit(types.SET_FULL_SCREEN,true)
	commit(types.SET_CURRENT_INDEX,index)
}
export const savePlayList = ({commit } , list ) => {
	commit(types.SET_PLAY_LIST,list)
}
export const saveMode = ({commit} , type) => {
	commit(types.SET_MODE,type)
}
export const saveCurrentIndex = ({commit } , index ) => {
	commit(types.SET_CURRENT_INDEX,index)
}
//播放列表重置
export const saveSequence = ({commit } , lsit) =>{
	commit(types.SET_SEQUENCE_LIST,list)
}
//关闭全屏播放 default true
export const closeScreen = ( {commit} , flg )=>{
	if( flg ) {
		commit(types.SET_FULL_SCREEN, false)
	} else {
		commit(types.SET_FULL_SCREEN, true)
	}
}

export const randomPlay = ({commit} , {list}) => {
	commit(types.SET_MODE,playMode.random)
	commit(types.SET_SEQUENCE_LIST,list)
	let randomList = shuffle(list)
	commit(types.SET_PLAY_LIST,randomList)
	commit(types.SET_FULL_SCREEN,true)
	commit(types.SET_CURRENT_INDEX,0)
	commit(types.SET_IS_PAUSE,true)
}


export const saveRankDetail = ({commit},list)=>{
	commit(types.SET_RANK_DETAIL,list)
}