import {playMode }  from '@/base/js/config'

let state = {
	//是否显示播放器组件 默认false
	isShowPlayer : false,
	//是否播放状态   default false
	isPause : false,
	//全屏
	fullScreen:false,
	//播放列表
	playList:[],
	//顺序列表
	sequenceList:[],
	//播放模式  默认顺序播放
	mode:playMode.sequence,
	//当前index
	currentIndex : -1,
	//推荐轮播图的照片数字
	recommendImageList : [],
	//歌手列表
	singerList : {},
	//歌手详情
	singerDetailList : [],
	//推荐list
	recommendList : [],
	//推荐详情disc
	recommendDisc:[],
	//热门
	rankDetail:{},
}

export default state


