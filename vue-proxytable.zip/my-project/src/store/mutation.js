import * as types from './mutation-type'

const mutations = {
  [types.SET_RECOMMEND_IMAGE_LIST](state, recommendImageList) {
    state.recommendImageList = recommendImageList
  },
  [types.SET_IS_SHOW_PLAYER](state, isShowPlayer) {
    state.isShowPlayer = isShowPlayer
  },
  [types.SET_RECOMMENDLIST](state, recommendList) {
    state.recommendList = recommendList
  },
  [types.SET_SINGER_LIST](state, singerList) {
    state.singerList = singerList
  },
  [types.SET_SINGER_DETAIL_LIST](state, singerDetailList) {
    state.singerDetailList = singerDetailList
  },
  [types.SET_IS_PAUSE](state, flg) {
    console.log('xiongxiong')
    state.isPause = flg
  },
  [types.SET_FULL_SCREEN](state, flg) {
    state.fullScreen = flg
  },
  [types.SET_SEQUENCE_LIST](state, list) {
    state.sequenceList = list
  },
  [types.SET_CURRENT_INDEX](state, index) {
    state.currentIndex = index
  },
  [types.SET_PLAY_LIST](state, list) {
    state.playList = list
  },
  [types.SET_MODE](state, number) {
    state.mode = number
  },
  [types.SET_RECOMMEND_DISC](state, list) {
    state.recommendDisc = list
  },
  [types.SET_RANK_DETAIL](state, list) {
    state.rankDetail = list
  },

  
}

export default mutations