<template>
	<div>
	《你好  明天》
	<router-view></router-view>	
	</div>
</template>
<script >	
	import {ERR_OK} from '@/api/config'
	import {getRecommend , getDiscList} from '@/base/js/recommend'
	import {mapState , mapActions} from 'vuex'
	import Scroll from 'common/scroll/scroll'
	import {playListMixin } from '@/base/js/mixin'
	export default {
		data() {
			return {
				dataList :this.recommendList 
			}
		},
		created() {
			this.dataList = []
			this.initDiscList()
		},
		computed : {
			...mapState([
				'recommendImageList',
				'recommendList'
			])
			
		},
		mounted() {

		},
		methods : {

			initDiscList() {
				/*var _this = this
				getDiscList().then((res)=>{
					if( res.code == ERR_OK) {
						console.log(res)
						this.dataList = res.data.list
						console.log(res.data.list)
						_this.saveRecommendList(res.data.list)
					}else{
						console.log('失败哦')
					}
				})*/
			},

			selected(item){
				this.$router.push({
					path:`/recommend/${item.id}`
				})
				this.saveRecommendDisc(item)
			},
			//
			handlePlayList(playList) {
				let bottom = playList.length > 0 ? '60px' : ''
				if(playList.length > 0 ) {
					//objArr[objArr.length-1].style.paddingBottom = bottom
					 this.$refs.recommendScroll.$el.style.bottom = bottom
					 this.$refs.recommendScroll.refresh()
				}
			},
			...mapActions([
				'saveRecommendImageList',
				'saveRecommendList',
				'saveRecommendDisc',
            ])

		},
		components:{
			Scroll
		}
	}
</script>
<style type="text/css" lang="scss">
	.recommend_list{
		z-index: 88;
		background-color:#1c1d1d;
       	height: unset !important;
	    top: 65px;
	    bottom: 0;
       	overflow: inherit;	
	}
	.recommend{
		text-align:center;
		padding-top:10px;
		font-size:14px;
		color:#fff;
		width:100%;
		.swiper-slide{
			img{
				width:100%;
				min-height:150px;
			}
			.swipeSlide{
				height:150px;

			}
		}
		.list-mox{
			padding: 10px 0 10px 5%;
			position: relative;
		}
		.hot-recommend{
			color:#deaf03;
			font-size:14px;
			padding:5px 0;
		}
		.hot-list-img{
				width: 60px;
				height: 60px;
				img {
					display: block;
					width: 100%;
					height: auto;
				}
		}
		.hot-list-text{
				margin-left:10px;
				width: calc(100% - 100px);
				position:absolute;
				top: 50%;
				transform: translateY(-50%);
				left: 85px;
				p:nth-child(1){
					color: #fff;
					padding:2px 0;
					text-align: left;
				}
				p:nth-child(2){
					color: #666;
					padding:2px 0;
					text-align: left;
					overflow:hidden; 
					text-overflow:ellipsis;
					display:-webkit-box; 
					-webkit-box-orient:vertical;
					-webkit-line-clamp:2;
				}
		}
		.load-recommend{
			text-align: center;
			padding-top: 20px;
			color: #666;
			font-size: 16px;
		}

	}
	
</style>