<template>
	<transition name="slide">
		<div class="disc">
			<music-list :songList="recommendList" :name="title" :avatar="img"></music-list>
			}
		</div>
	</transition>
</template>
<script type="text/javascript"> 
	import MusicList from 'components/singer/music-list'
	import {mapState } from 'vuex'
	import {getSongList } from '@/base/js/recommend'
	import {ERR_OK } from '@/api/config'
	export default {
		data() {
			return {
				recommendList:['']
			}
		},
		created() {
			this._getSongList()
		},
		computed:{
			title() {
				console.log(this.recommendDisc)
				return this.recommendDisc.dissname
			},
			img() {
				return this.recommendDisc.imgurl
			},
			...mapState([
				'recommendDisc',
				
			])
		},
		methods:{
			_getSongList() {
				getSongList(this.recommendDisc.dissid).then((res) => {
					console.log('~~~~~~~~')
					console.log(res)
					if( res.code === ERR_OK ) {
						console.log(res)
					} else {

					}
				})
			}
		},
		components:{
			MusicList,
		},
	}
</script>
<style type="text/css" lang="scss">
	.slide-enter-active, .slide-leave-active{
	    transition: all 0.3s
	}

	.slide-enter, .slide-leave-to{
	    transform: translate3d(100%, 0, 0)
	}
	.disc{
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 999;
		display: inline-block;
	}
</style>