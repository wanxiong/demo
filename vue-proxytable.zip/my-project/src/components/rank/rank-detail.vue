<template>
	<transition name="slide">
		<div class="rank-detail">
			<music-list :songList="songs" :avatar="img" :name="title"></music-list>
			<!-- load ... -->
			<div v-show="!songs.length">
				<p class="load-recommend">loading....</p>
			</div>
		</div>
	</transition>
</template>
<script type="text/javascript">
	import MusicList from 'components/singer/music-list'
	import {mapState } from 'vuex'
	import {getMusicList } from '@/base/js/rank'
	import {ERR_OK} from '@/api/config'
	import {filterSinger } from '@/base/js/default'
	export default {
		data() {
			return {
				songs:[]
			}
		},
		computed:{
			...mapState([
				'rankDetail'
			]),
			title() {
				return this.rankDetail.topTitle
			},
			img(){
				return this.rankDetail.picUrl
			}
		},
		created() {
			this._getMusicList()
		},
		methods:{
			_getMusicList(){
				
				getMusicList(this.rankDetail.id).then((res)=>{
					if( res.code === ERR_OK ) {
						this.songs = this._normalizeSongs(res.songlist)
						console.log(this.songs)
					} else {
						console.log('error')
					}
				})
			},
			_normalizeSongs(list) {
				let ret = []
				list.forEach((item) => {
					const musicData = item.data
					if( musicData.songid && musicData.albummid) {
						ret.push({
							id: musicData.songid,
						    mid: musicData.songmid,
						    singer: filterSinger(musicData.singer),
						    name: musicData.songname,
						    album: musicData.albumname,
						    duration: musicData.interval,
						    image: `https://y.gtimg.cn/music/photo_new/T002R300x300M000${musicData.albummid}.jpg?max_age=2592000`,
						    url: `http://ws.stream.qqmusic.qq.com/${musicData.songid}.m4a?fromtag=46`
						})
					}
				})
				console.log(ret)
				return ret
			},
		},
		watch:{

		},
		components:{
			MusicList,
		}


	}
</script>
<style type="text/css" lang="scss">
	.slide-enter-active , .slide-leave-active{
		transition: all .3s;
	}
	.slide-enter , .slide-leave-to{
		transform:translate(100%,0,0);
	}
	.rank-detail{
		position: fixed;
		z-index: 20;
		top: 0;
		display: block;
		width: 100%;
		bottom: 0;
		background-color: #1c1d1d;
		z-index: 999;
	}
</style>