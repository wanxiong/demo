<template>
	<div class="rank">
		<!-- <div class="topList"> -->
			<scroll :data="topList" class="topList" ref="topList">
				<ul class="topFlex">
					<li v-for="item in topList" @click="selected(item)">
						<div>
							 <img width="100" height="100" v-lazy="item.picUrl"/>
						</div>
						<div>
							<p class="omg" v-for="(song , index ) in item.songList">
									<span>{{++index}} &nbsp</span>
									<span>{{song.singername}}{{song.songname}}</span>
							</p>
						</div>
					</li>
				</ul>
				
			</scroll>
			<!-- load ... -->
			<div v-show="!topList.length">
				<p class="load-recommend">loading....</p>
			</div>
		<!-- </div> -->
		<!-- 子路由 -->
		<router-view></router-view>	
	</div>
</template>
<script type="text/javascript" >
	import {getTopList , getMusicList} from '@/base/js/rank'
	import {ERR_OK} from '@/api/config'
	import Scroll from 'common/scroll/scroll'
	import {playListMixin } from '@/base/js/mixin'
	import {mapState , mapActions } from 'vuex'
	export default {
		mixin:[playListMixin],
		data() { 
			return {
				topList:[]
			}
		},
		created() {
			this._getTopList()
		},
		methods:{
			_getTopList() {
				getTopList().then((res) => {
					if( res.code === ERR_OK ) {
						console.log(res.data)
						this.topList = res.data.topList
					} else {
						console.log('请求失败')
					}
				})
			},
			selected(item) {
				console.log(item)
				this.$router.push({
					path:`/rank/${item.id}`
				})
				this.saveRankDetail(item)
			},
			handlePlayList(playList) {
				let bottom = playList.length > 0 ? '60px' : ''
				if(playList.length > 0 ) {
					//objArr[objArr.length-1].style.paddingBottom = bottom
					 console.log(this.$refs.topList.$el)
					 this.$refs.topList.$el.style.bottom = bottom
					 this.$refs.topList.refresh()
				}
			},
			...mapActions([
				'saveRankDetail',
			]),
		},
		watch: {

		},
		components:{
			Scroll,
		}
	}
</script>
<style type="text/css" lang="scss">
	.rank{
		text-align:center;
		font-size:14px;
		color:#fff;
	}
	.topList{
		position: fixed;
		top: 65px;
		bottom: 0;
		display: block;
		width: 100%;
		z-index: 300;
		height: unset !important;
		.topFlex{	
			padding-bottom: 10px;
			 li {
				display: flex;
				position: relative;
				margin: 10px 0 ;
				&:last-child(){
					padding-bottom:10px; 
				}
				 div:nth-of-type(1){
					width: 100px;
					height: 100px;
					padding: 0 20px;
				}
				 div:nth-of-type(2){
				 	background-color:#333;
					text-align: left;
					color: rgba(255,255,255,0.3);
					font-size: 12px;
					line-height: 22px;
					position: absolute;
					left: 120px;
					top: 0;
					width: calc(100% - 120px);
					height: 100%;
					p{
						margin:5px 0 ;
						padding: 0 10px;
					}
				}
			
			}
		}
	}
	.load-recommend{
		text-align: center;
		padding-top: 20px;
		color: #666;
		font-size: 16px;
	}
	
</style>