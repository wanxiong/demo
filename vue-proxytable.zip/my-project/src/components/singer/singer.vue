<template>
	<div class="singer">
		<list-view :data="dataList" @selectId="selectSinger"></list-view>
		<!-- 子页面承载 -->
		<router-view></router-view>
	</div>
</template>
<script>

	import {getSingerList , getSingerDetail , getSingerAvatar } from '@/base/js/singer'
	import {mapState , mapActions ,mapMutations } from 'vuex'
	import {ERR_OK} from '@/api/config'
	import listView from './list-view'
	export default {
		data() {
			return {
				title:"热门",
				dataList:[],
				singer :true
			}
		},
		created() {
			//一览
			this.initSingerList()
		},
		mounted() {
			this.saveTransPlayer(true)
		},
		computed:{
			...mapState([
				'singerList'
			])
		},
		methods :{
			initSingerList() {
				getSingerList().then( (res) => {
					if(res.code == ERR_OK) {
						this.saveSingerList(res)
						this.reviewList(res)
					} else {
						console.log('失败')
					}
				})
			},
			/* 去详情 */
			selectSinger(singerId) {
				this.$router.push({
					path: '/singer' + '/' + singerId,
					//query: {singerId}
				})
			},
			/* 把list的每个列表push一个缩略图
			 * @params {Array} 数组
			*/
			reviewList(listArray) {
				this.dataList = this.normalLizeSinger(listArray.data.list)
			},
			/*
			 * 序列化数据
			*/
			normalLizeSinger( list ) {
				let map = {
						hot : {
							title:"热门",
							items:[]
						}
				};
				// 新构件一个数据结构
				list.forEach( (item , index) => {
					if( index < 10) {
						map.hot.items.push( getSingerAvatar({id:item.Fsinger_mid,name:item.Fsinger_name}) )
					}
					//
					const key = item.Findex
					if( !map[key]){
						map[key] = {
							title:key,
							items :[]
						}
					}
					map[key].items.push( getSingerAvatar({id:item.Fsinger_mid,name:item.Fsinger_name}) )
				})
				// 处理MAP 
				let hot = []
				let ret = []
				let reg = /[a-zA-Z]/i
				for ( let att in map ){
					let Key = map[att]
					if( reg.test(Key.title)){
						ret.push(Key)
					} else if( Key.title == '热门' ) {
						hot.push(Key)
					}
				}
				//按照从小到大的顺序排列   a-z
				ret.sort( (a , b) => {
					return a.title.charCodeAt(0) - b.title.charCodeAt(0)
				})
				return hot.concat(ret)

			},
			/*
			 *去详情页面
			*/
			selectItem(singer) {
				this.$router.push({
		          path: `/singer/${singer.Fsinger_mid}`
		        })
		        this.singer = false;
			},
			...mapActions([
				'saveSingerList',
				'saveTransPlayer'
			])
		},
		components:{
			listView
		}
	}
</script>
<style type="text/css" lang="scss">
	.singer{
		text-align:center;
		font-size:14px;
		color:#fff;
		position:fixed;
		width: 100%;
		bottom: 0;
		top:65px;
		z-index: 300;
		.singer-con{
			height: 100%;
			position:relative;
		}
		.scroll-content{
			height:calc(100% - 29px);
		}
		.singer-item{
			> li{
				vertical-align: middle;
				padding:10px 0 0 20px;
				position: relative;
				text-align: left;
				span{
					color: #666;
					position:absolute;
					top: 50%;
					transform: translateY(-50%);
				}
				img{
					width: 50px;
					height: 50px;
					border-radius: 50%;
					overflow: hidden;
					display: inline-block;
					margin-right:15px	;
				}
			}
		}
		.singer-letter{
				position: absolute;
				right: 10%;
				top: 50%;
				transform: translateY(-50%);
				z-index:100; 
				color: #666;

		}	
		.singer-title{
			text-align: left;
			color: #999;
			background-color:#333;
			padding:5px 0 5px 25px;
		}
	}
</style>