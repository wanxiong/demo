<template>
	<transition name="slide">
		<div class="singer-detail-child" >
			<music-list  :songList="songs" :avatar="avatar" :name="name"></music-list>
		</div>
	</transition>
</template>
<script>
	import MusicList from './music-list'
	import {getSingerDetail , getSingerAvatar } from '@/base/js/singer'
	import {mapState , mapActions} from 'vuex'
	import {ERR_OK} from '@/api/config'
	import {createSong} from '@/base/js/song'
	export default {
		data() {
			return {
				songs :[],
				name:'',
				avatar:''
			}
		},
		created() {
			// console.log(this.singerList)
			this.initSingerDetail()
		},
		computed:{
			...mapState([
				'singerDetailList'
			])
		},
		methods : {
			initSingerDetail() {
				let id = this.$route.params.id
				getSingerDetail(id).then( (res) => {
					console.log(res)
					if(res.code == ERR_OK ){
						let data = res.data
						let detail = getSingerAvatar({id:data.singer_mid,name:data.singer_name})
						res.data.detail = detail 
						this.avatar = detail.avatar
						this.name = detail.name
						this.saveSingerDetailList(res)
						this.songs = this.normalizeSong(res.data.list)
					} else {
						console.log('失败~~~~')
					}
				})
			},
			normalizeSong(list) {
				let ret = []
				list.forEach((item)=>{
					let musicDate = item.musicData
					if( musicDate.songid && musicDate.albummid ){
						ret.push( createSong(musicDate) )
					}
				})
				console.log(ret)
				return ret
			},
			...mapActions([
				'saveSingerDetailList'
			]),
		},
		components: {
			MusicList
		},
	}
</script>
<style type="text/css" lang="scss">
	.slide-enter-active, .slide-leave-active{
	    transition: all 0.3s
	}

	.slide-enter, .slide-leave-to{
	    transform: translate3d(100%, 0, 0)
	}
	.singer-detail-child{
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		z-index:9900;
		background-color: #1c1d1d;
	}
</style>