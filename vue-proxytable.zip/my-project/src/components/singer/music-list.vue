<template>
	<div>
		<div class="singer-detail">
			<!-- 顶部信息 -->
			<div v-show="songList.length">
				<!-- <img v-lazy="data.imgUrl"> -->
				<div class="bg-company" ref="bgImage">
					<p class="singer-modal"></p>
					<div class="singer-name omg">{{name}}</div>
					<div v-lazy:background-image="avatar" class="bg-company-div" ref="bg">
						<div class="singer-random" @click.stop="addList" ref="singerRandom">
							<i class="icon icon-kuaijin1 iconfont" @click=""></i>
							<span>随机播放全部</span>
						</div>
					</div>
					<p class="icon_back">
						<i class="icon icon-fanhui iconfont singer_back" @click="go_back"></i>
					</p>
				</div>
			</div>
			<!-- 列表区域 -->
		<scroll class="song-detail" :data="songList" :probeType="3" :click="true"
			:listenScroll = "true"
			@scroll = "listenScroll"
			ref="song_list"
		>
			<song-list :data="songList" 
				@playsong="playSong" 
				@closescreen="closeScreen"
				@openScreen="openScreen"
			></song-list>
			<!-- load ... -->
			<div v-show="songList.length">
				<p class="load-recommend">loading....</p>
			</div>
		</scroll>
		</div>
		<!-- 黑色层级 -->
		<div class="bg-posirion" ref="layer"></div>
		
	</div>
</template>
<script>
	import Scroll from 'common/scroll/scroll'
	import SongList from 'common/song/song-list'
	import {prefix } from '@/base/js/default'
	import {mapActions, mapState} from 'vuex'
	import {playListMixin } from '@/base/js/mixin'
	const TRANSLATEY = 40
	const INIT_HEIGHT = 250
	const Transform = prefix('transform')
	const Filter = prefix('filter')
	export default {
		mixins:[playListMixin],
		data() {
			return {
				scrollY : 0
			}
		},
		created() {
		},
		computed:{
			...mapState([
				'fullScreen',
			])
		},
		methods: {
			/* 返回歌手列表一览 */
			go_back() {
				this.$router.back()
			},
			/* 添加到列表播放页面 */
			addList() {
				//
				this.randomPlay({
					list:this.songList
				})
			},
			listenScroll(pos) {
				this.scrollY = pos.y
			},
			//去播放界面
			playSong(list,index) {
				this.selectPlay({
					list:this.songList,
					index
				})
			},
			//打开全屏
			openScreen() {
				this.closeScreen(false)
			},
			//
			handlePlayList(playList) {
				//操作list 
				//let objArr = this.$refs.song_list.$el.children[0].children

				let bottom = playList.length > 0 ? '40px' : ''
				if(playList.length > 0 ) {
					console.log('~~~~~~~~~~~~~~~~~')
					//objArr[objArr.length-1].style.paddingBottom = bottom
					 this.$refs.song_list.$el.style.bottom = bottom
					 this.$refs.song_list.refresh()
				}
			},
			...mapActions([
				'selectPlay',
				'closeScreen',
		        'randomPlay',
			])
		},
		mounted() {
			/* this.$nextTick(() => {
           		this.imgHeight = this.$refs.bgImage.clientHeight 
           		console.log(this.$refs.bgImage.style)
				this.minHeight = -this.imgHeight +  TRANSLATEY
       		 })*/
		},
		components:{
			Scroll,
			SongList,
		},
		props :{
			songList:{
				type : Array,
				default:[]
			},
			avatar:{
				type :String,
				default :''
			},
			name:{
				type :String,
				default : ''
			}
		},
		watch:{
			scrollY(newY) {
				let translateY = Math.max( -(INIT_HEIGHT -TRANSLATEY)  , newY)
				let scale = 1
				let blur = 0
				let precent = Math.abs(newY / INIT_HEIGHT)
				this.$refs.layer.style[Transform] = `translate3d(0,${translateY}px,0)`
				
				if( newY < -(INIT_HEIGHT -TRANSLATEY)) {//到达顶部最上面 距离还差TRANSLATEY
					this.$refs.bgImage.style.height = TRANSLATEY + 'px'
					this.$refs.bgImage.style.zIndex = '300'
					this.$refs.singerRandom.style.display = 'none'
				} else{
					this.$refs.bgImage.style.height = INIT_HEIGHT + 'px'
					this.$refs.bgImage.style.zIndex = '100'
					this.$refs.singerRandom.style.display = 'block'
				}
				if( newY > 0) { //往下拉
					scale =  1 + precent
					this.$refs.bgImage.style.zIndex = '300'
				} else{

					blur = Math.min(20 * precent , 20)
				}
				//filter
				
				this.$refs.bg.style[Filter] = `blur(${blur}px)`
				//scale
				this.$refs.bg.style[Transform] = `scale(${scale})`
			//	this.$refs.bg.style.webkitTransform = `scale(${scale})`
				this.$refs.bg.style.zIndex = '500'
			}
		}
	}
</script>
<style type="text/css" lang="scss">
	.icon_back{
		position:absolute;
	    left:5%;
	    z-index:900;
	    top: 0;
	}
	.load-recommend{
		text-align: center;
		padding-top: 20px;
		color: #666;
		font-size: 16px;
	}
	.singer_back{
		font-size: 26px;
		color: #ffcd32;
		padding:10px;
		display: block;
	}
	.singer-detail{
		position: absolute;
		height: 100%;
		display: block;
		width: 100%;
	}
	.bg-company{  
	    width: 100%;  
	    height: 250px;  
	    position: relative;
        background-color: #fff;
	    .bg-company-div{
	    	position:absolute;
	    	width: 100%;
	    	height: 100%;
	    	display: block;
		    background-repeat: no-repeat;  
	    	background-position:center top;
	    	background-size: cover;

	    }
	    .singer-name{
	    	position:absolute;
	    	top: 10px;
	    	left: 50%;
	    	transform: translateX(-50%);
	    	color: #fff;
	    	z-index:900;
	    	font-size: 18px;
	    	font-weight: 500;
	    }
	    .singer-random{
	    	position: absolute;
	    	left: 50%;
    	    top: 200px;
	    	transform: translateX(-50%);
	    	padding:5px 15px;
	    	border:1px solid #ffcd32;
	    	color:#ffcd32;
	    	border-radius:10px; 
	    	z-index: 100;
	    	i{
	    		font-size: 14px;
	    	}
	    	span{
	    		font-size: 12px;
	    		font-weight:500;
	    	}

	    }  
	}  
	.song-detail{
		z-index: 200;
		background-color:#1c1d1d;
       	height: unset;
	    top: 250px;
	    bottom: 0;
       	overflow: inherit;	
	}
	.singer-modal{
		position:absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		display: block;
		background-color:rgba(0,0,0,.3);
		z-index:100;
	}
	.bg-posirion{
		position:absolute;
		height: 100%;
		width: 100%;
		display: block;
		background-color:#1c1d1d;
		top: 250px;
		z-index: 100;
	}
	.filter{
		width: 100%;
		height: 100%;
	}
</style>