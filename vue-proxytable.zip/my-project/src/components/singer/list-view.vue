<template>
	<scroll class="list-view" :data="data" :click="true" probe-type="2"
		:listen-scroll = "true"
		@scroll = "scroll"
		ref = "listview"
	>
		<ul>
			<li v-for="group in data" class="list-group" ref="groupview">
				<h2 class="list-group-title">{{group.title}}</h2>
				<ul>
					<li v-for="item in group.items" class="list-group-item" @click="goDetail(item.id)">
						<!-- <img :src="item.avatar" > -->
						<!-- <div class="bg-company" v-lazy:background-image="imgIcon"></div> -->  
						<img v-lazy="item.avatar" >
						<span>{{item.name}}</span>
					</li>
				</ul>
			</li>
		</ul>
		<!-- 字典 -->
		<div class="letterList"  
			 @touchstart.stop.prevent="onstart" 
			 @touchmove.stop.prevent="onmove"
			 @touchend.stop>
			<p class="item" 
				:data-index="index" 
				v-for="(items,index) in shortcutList" 
				:class="{'current': index === currentIndex}">
				{{items}}
			</p>
		</div>
		<!--  字典提示 -->
		<div class="letterList-tip" v-show="tipDefault" ref="fixed">
			{{tipDefault}}
		</div>
		<!-- load ... -->
		<div v-show="!data.length">
			<p class="load-recommend">loading....</p>
		</div>
	</scroll>
</template>
<script >
	import Scroll from 'common/scroll/scroll'
	import BScroll from 'better-scroll'
	import {getDataAtt} from '@/base/js/default'
	import {playListMixin } from '@/base/js/mixin'
	const HEGHT = 18
	const INIT_HEIGHT = 30
	export default {
		mixins:[playListMixin],
		data() {
			return {
				 currentIndex: 0,
				 tip: 		   '',
				 scrollY:     -1,
				 diff   :  -1
			}
		},
		props :{
			data :{
				type :Array,
				default:[]
			}
		},
		created() {
			//创建空对象
			this.touch = {}
			//this.tip = this.data && this.data[0].title
			this.listHeight = []
		},
		computed: {
			/*展示英文数据的计算*/
			shortcutList() {
				return this.data.map( (group) =>{
						return group.title.substr(0, 1)
					
				})
			},
			/* 展示tip提示 动态计算 */
			tipDefault() {
				if( this.scrollY > 0 ){
					return ''
				}
				 return this.data[this.currentIndex] ? this.data[this.currentIndex].title : ''
			}
		},
		methods:{
			onstart(ev) {
			 let anchorIndex = getDataAtt(ev.target , 'index')
			    //记录点击时候的初始值
			 	this.touch.y1 = ev.touches[0].pageY
			 	this.touch.currentIndex = anchorIndex;
			 	//this.$refs.listview.scrollToElement(this.$refs.groupview[anchorIndex] , 0)
			 	this._scrollToView(parseInt(anchorIndex)) 
			},
			onmove(ev) {
				this.touch.y2 = ev.touches[0].pageY
				let disY = (this.touch.y2 - this.touch.y1) / HEGHT | 0
				let index = parseInt(this.touch.currentIndex) + disY
				//this.$refs.listview.scrollToElement(this.$refs.groupview[index] , 0)
				this._scrollToView(index) 
			},
			/* 去歌手详情 */
			goDetail(id) {
				this.$emit('selectId',id)
			},
			/* 滚动事件的监听 */
			scroll(pos) {
				this.scrollY = pos.y
				// console.log(this.scrollY)
				//console.log(ev )
			},
			/* 滚动到对应的位置 */
			_scrollToView(index) {
				//提示文字替换
				//边界处理
				if( index < 0) {
					index = 0;
				} else if( index > this.listHeight.length - 2) {
					index = this.listHeight.length - 2;
				}
				this.tip = this.data[index].title
				this.currentIndex = index
				this.$refs.listview.scrollToElement(this.$refs.groupview[index] , 100)
			},
			/* 重新计算 */
			calcHeight() {
				this.listHeight = []
				const listView = this.$refs.groupview
				let height  = 0
				this.listHeight.push(height)
				//把对应的高度转化成距离数组关联起来
				for( let i = 0 ; i < listView.length ; i++ ){
					 let item = listView[i];
					 let itemH = item.clientHeight
					 height += itemH
					 this.listHeight.push(height)

				}

			},
			//
			handlePlayList(playList) {
				let bottom = playList.length > 0 ? '60px' : ''
				if(playList.length > 0 ) {
					//objArr[objArr.length-1].style.paddingBottom = bottom
					 this.$refs['listview'].$el.style.bottom = bottom
					 this.$refs['listview'].refresh()
				}
			},
		},
		watch: {
			/* 如果数据变化 */
			data() {
				setTimeout(() => {
					this.calcHeight()
				},20)
			},
			/* 监听scrollY的变化 */
			scrollY(newY) {
				const listHeight = this.listHeight;
				//当滚动到顶部  newY大于0          			    -------- 上 
				if(newY > 0) {
					this.currentIndex = 0
					return 
				}
				//在中间滚动部分 因为负数    				    -------- 中  
				for( let i = 0 ; i < listHeight.length - 1 ; i++ ) {
					let height1 = listHeight[i]
					let height2 = listHeight[i +1]
					if( (-newY >= height1) && (-newY < height2) ) {
						//在中间区域滚动
						this.currentIndex = i
						this.diff = height2 + newY
						return ;
					}
				}
				// 当滚动到底部，且-newY大于最后一个元素的上限   -------- 下
        		this.currentIndex = listHeight.length - 2
			},
			/*  计算tip的位置 */
			diff(newVal) {
				console.log(newVal + '~~~~~~~~~~~~~~~')
				let fixedTop = (newVal > 0 && newVal < INIT_HEIGHT) ? newVal - INIT_HEIGHT : 0
				if (this.fixedTop === fixedTop) {
		          return
		        }
		        this.fixedTop = fixedTop
		        this.$refs.fixed.style.transfrom = `translate3d(0,${fixedTop}px,0)`
			}
		},
		components:{
			Scroll
		}
	}
</script>

<style type="text/css"  lang="scss">
	.list-group-item{
		vertical-align:middle;
		padding-left: 10%;
		text-align: left;
		margin: 3% 0;
		img{
			display: inline-block;
			width: 50px;
			height: 50px;
			border-radius: 50%;
			vertical-align:middle;
			margin-right:5%;
		}
	}
	.list-group-title{
		text-align: left;
		font-size: 14px;
		color: #ccc;
		padding-left: 20px;
		background-color:#333;
		padding:3px 0 3px 20px;
	    font-weight: 100;
	}
	.list-view{
		height: unset !important;
		bottom: 0;
	}
	.letterList {
		position: absolute;
		top: 50%;
		right: 0%;
		transform: translateY(-50%);
		z-index: 50;
		background-color:rgba(0,0,0,0.6);
		padding:12px 0px;
		border-radius:12px;
		.item {
			color:#333;
			//padding: 2px;
			height: 18px;
			line-height: 18px;
			padding:0 4px;
			&.current{
				color: #f40;
			}
		}

	}
	.load-recommend{
		text-align: center;
		padding-top: 20px;
		color: #666;
		font-size: 16px;
	}
	.letterList-tip{
		text-align: left;
		font-size: 14px;
		color: #ccc;
		padding-left: 20px;
		background-color:#333;
		padding:3px 0 3px 20px;
		position: absolute;
		width: 100%;
		top: 0;
		display: block;
		z-index: 101;
	}
</style>