<template>
	<div class="search">
		<search-box :placeholder="placeholder" @queryChange="change" ></search-box>
		<!-- 热门搜索 -->
		<div class="ret-wrapper">
			<p>热门搜索</p>
			<ul class="ret-tag clearfix">
				<li v-for="item in hotKey">aaa</li>
			</ul>
		</div>
	</div>
</template>
<script type="text/javascript">
	import SearchBox from './search-box'
	import {getHotKey , search } from '@/base/js/search'
	import {ERR_OK } from '@/api/config'
	//import $ from 'jquery'
	export default {
		data() {
			return {
				placeholder:'搜索歌曲',
				hotKey :[],
			}
		},
		created() {
			this._getHotKey()
			//console.log($)
		},
		methods:{
			change(val) {
				console.log(val)
			},
			_getHotKey() {
				getHotKey().then((res) => {
					if( res.code === ERR_OK) {
						console.log(res.data)
						this.hotKey = res.data.hotkey.slice(0,10)
					} else {
						console.log('err')
					}
				})
			}
		},
		components: {
			SearchBox,
		},
	}
</script>
<style type="text/css" lang="scss">
	.search{
		text-align:center;
		font-size:14px;
		color:#fff;
		.ret-wrapper{
			> p{
				padding-left: 22px;
				text-align: left;
				color: rgba(255,255,255,.5);
				position: relative;
			}
			
			.ret-tag{
				padding: 10px 20px;
				color: rgba(255,255,255,.5);
				li{
					flex:1;
					width: 33.3%;
					display: inline-block;
					float: left
				}
			}
		}
	}

</style>