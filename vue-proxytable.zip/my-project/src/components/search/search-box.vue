<template>
	<div>
		<!-- 查询 -->
		<div class="input-wrapper">
			<input type="text" name="" v-model="inputTxt"  :placeholder="placeholder"  ref="inputSearchBtn"/>
			<span v-show="inputTxt" class="close" @click="clearTxt">+</span>
		</div>
	</div>
</template>
<script type="text/javascript">
	export default {
		data() {
			return {
				inputTxt:'',
			}
		},
		created(){
			//监听query的变化 input
			this.$watch('inputTxt',(input) => {
				this.$emit('queryChange',input )

			})
		},
		methods:{
			clearTxt() {
				// todo

				let val = this.$refs.inputSearchBtn.value
					if( this.trim(val) !== '') {
						//this.$refs.inputSearchBtn.value = ''
						this.inputTxt = ''
					}
			},
			trim(val) {
				if ( !!val ) {
					return val.replace(/(^\s*)|(\s*$)/g,"")
				}
				return ''
			},
			
		},
		props:{
			placeholder:{
				type:String,
				default :'搜索歌曲'
			}
		},
	}
</script>
<style type="text/css" lang="scss">
	.input-wrapper{
		margin: 10px 20px;
		position: relative;
		input{
			width: 90%;
			padding: 10px 0 10px 20px;
			border-radius: 10px;
			background: #333;
		}
		.close{
			position: absolute;
			right: 12px;
			top: 50%;
			transform:translateY(-50%) rotate(45deg);
			font-size: 36px;
			color: rgba(255,255,255,.6);
			font-weight: 100;
		}	
	}
</style>