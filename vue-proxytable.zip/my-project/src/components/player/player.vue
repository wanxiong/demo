<template>
	<div class="player" v-show="playList.length">
		<transition name="palyer"
		>
		<!-- 完整播放器 -->
		<div class="song-play" v-show="fullScreen">
			<div class="song-play-pos">
			<!-- 背景 -->
				<div class="song-pos-bg">
					<!-- :style="{background:'url('+currentSong.image  +') no-repeat center','background-size': 'cover'}" -->
					<img :src="currentSong.image" >		
				</div>
				<!-- 内容部分 -->
				<div class="song-pos-con">
					<h2 class="song-con-title" >
						<p v-html="currentSong.name"></p>
						<p v-html="currentSong.singer"></p>
						<i class="icon icon-xialajiantou iconfont" @click="go_back" ref=""></i>
					</h2>
					<div class="song-con-bg">
						<div>
							<div class="song-wrapper">
							<div class="swiper-container swiper-play-box">
							  <div class="swiper-wrapper swiper-play" ref="swiperCon">
							    <div class="swiper-slide swiper-play-slide">
							    	<!-- <img :src="currentSong.image" 
								 	:class="{'miniImg':isPause,'miniImg miniPause':!isPause}"
									> -->
									<div :style="{'background':'url('+ currentSong.image +') no-repeat center',
													'width':'90%','padding-top':'90%',
													'border-radius':'50%','overflow':'hidden',
													'background-size': 'cover','border':'8px solid #666',
													'margin':'0 auto'}" 
										:class="{'miniImg':isPause,'miniImg miniPause':!isPause}"

									></div>
									<p v-if="playingLyric.length" class="playNow_text" ref="playNowTxt">
										{{playingLyric}}
									</p>
								</div>
							    <div class="swiper-slide swiper-play-slide">
							    	<!-- 滚动组件  -->
							    	<scroll class="lyric-play" v-if="currentLyric && currentLyric.lines "
							    		 :data="currentLyric.lines"
							    		 ref="lyricList"
							    	>
								    	<!-- 歌词 -->
										<div class="lyric-wrapper">
							              <div>
							                <p ref="lyricLine"
							                   class="text"
							                   :class="{'hasLineHeight': index=== currentLineNum}"
							                   v-for="(line,index) in currentLyric.lines">{{line.txt}}</p>
							              </div>
							            </div>
							            <!-- 歌词 end-->
						            </scroll>
							    </div>
							  </div>
							  <div class="swiper-pagination swiper-play-pagination swiper-play-point">
							  	
							  </div>
							</div>
							</div>
						</div>
					</div>
				</div>
				<!-- 底部确定 -->
				<div class="song-pos-bot">
					<div class="sing-bot-pre">
						
						<div class="line" ref="progressBox" @click="changeProgress">
							<p class="start">{{format(currentTime)}}</p>
							<div class="pos-line" ref="progress"></div>
							<div class="pos-border" ref="proBor" 
								@touchstart.prevent="progressStart"
								@touchmove.prevent="progressMove"
								@touchend="progressEnd"
								>
									
							</div>
							<p class="end">{{format(currentSong.duration)}}</p>
						</div>
					</div>
					<div class="sing-bot-icon">
						<i class="icon icon-yinle iconfont" @click="" ref="" :class="iconMode" @click="changeMode"></i>
						<i class="icon icon-kuaijin1 iconfont" @click="preBtn" ref="prebtn"></i>
						<i 
							class="icon iconfont" 
							:class="{'icon-chuyidong':isPause,'icon-yinlezanting':!isPause}"
							@click="autoPlay" ref="autoPlatBtn"></i>
						<i class="icon icon-kuaijin iconfont" @click="nextBtn" ref="nextbtn"></i>
						<i class="icon icon-shoucang iconfont" @click="" ref=""></i>
					</div>
				</div>
			</div>
		</div>
		</transition>
		<!-- mini播放器 -->
		<transition name="mini">
		<div class="mini-player" v-show="!fullScreen" @click="openScreen">
			<div> 
				<img v-lazy="currentSong.image" ref="miniImg"
					:class="{'miniImg':isPause,'miniImg miniPause':!isPause}"
				>
			</div>
			<div>
				<p class="omg">hello word vincentwan</p>
				<p class="omg" >你好</p>
			</div>
			<div >
				<i 
					class="icon iconfont" 
					:class="{'icon-chuyidong':isPause,'icon-yinlezanting':!isPause}"
					@click.stop.prevent="switchPause" ref="playBtn"></i>
				<i class="icon icon-yinle iconfont" @click.stop.prevent="showPlayList"></i>
			</div>
		</div>
		</transition>
		<!-- 音频播放 -->
		<audio ref="audio" :src="currentSong.url" @canplay="ready" @error="error" @timeupdate="updateTime"
		@ended="end"
		>
			
		</audio>
	</div>
</template>
<script>
	import {mapGetters , mapState , mapActions} from 'vuex'
	import {prefix , shuffle} from '@/base/js/default'
	import { playMode } from '@/base/js/config'
	import animations from 'create-keyframe-animation'
	import {initLyric } from '@/base/js/song'
	import Lyric from 'lyric-parser'
	import Scroll from 'common/scroll/scroll'
	const Transform = prefix('transform')
	const progressBorder = 20
	export default {
		data() {
			return {
				aaa:'red',
				songReady:false,
				currentTime:0,
				currentLyric:null,
				lyricSwiper:null,
				currentLineNum:0,
				playingLyric:''
			}
		},
		created() {
			this.touch = {}
		},
		computed: {
			iconMode() {
				return this.mode === playMode.sequence? 'icon-sequence' : this.mode === playMode.loop? 'icon-loop' :'icon-random'
			},
			...mapState([
				'isShowPlayer',
				'isPause',
				'fullScreen',
				'playList',
				'currentIndex',
				'mode',
				'sequenceList',
		  	]),
		  	...mapGetters([
		  		'currentSong'
		  	])

		},
		mounted() {
			/*this.$nextTick(() => {
				
			})*/
		},
		methods : {
			//是否播放欧哲暂停
			switchPause() {
				let btn = this.$refs.playBtn
				let btnTwo = this.$refs.miniImg
				//icon切换
				if( !this.isPause) { //暂停
					let nameStr = btn.className.replace(/(icon-chuyidong|icon-yinlezanting)/g,'')
					btn.className = nameStr + ' icon-yinlezanting'
					btnTwo.className = 'miniImg '
					this.saveTransPause(true)
					this.$refs.audio.play()
				} else { //播放
					this.$refs.audio.pause()
					let nameStr = btn.className.replace(/(icon-chuyidong|icon-yinlezanting)/g,'')
					btn.className = nameStr + ' icon-chuyidong'
					this.saveTransPause(false)
					btnTwo.className = 'miniImg miniPause'
				}
				this.currentLyric && this.currentLyric.togglePlay()	
			},
			//显示最近播放列表
			showPlayList() {
				//TODO
			},
			//播放音乐
			autoPlay() {
				let btn = this.$refs.autoPlatBtn
				if( !this.isPause ) {
					let nameStr = btn.className.replace(/(icon-chuyidong|icon-yinlezanting)/g,'')
					btn.className = nameStr + ' icon-yinlezanting'
					this.saveTransPause(true)
					this.$refs.audio.play()
									
				} else { //暂停
					this.$refs.audio.pause()
					let nameStr = btn.className.replace(/(icon-chuyidong|icon-yinlezanting)/g,'')
					btn.className = nameStr + ' icon-chuyidong'
					this.saveTransPause(false)
				}
				this.currentLyric && this.currentLyric.togglePlay()	
			},
			//隐藏全屏
			go_back() {
				this.closeScreen(true)
			},
			//打开全屏
			openScreen() {
				this.closeScreen(false)
			},
			//播放上一个
			preBtn() {
				if( !this.songReady ){
					return
				}
				if( this.playList.length === 1) {
					this.loop()
				} else{
					let index = this.currentIndex - 1;
					if( index === -1 ) {
						index = this.playList.length - 1
					}
					this.saveCurrentIndex(index)
					//是否处于播放状态  切换按钮状态
					this.switchState()
				}
				this.songReady = false
			},
			//播放下一个
			nextBtn() {
				if( !this.songReady ) {
					return
				}
				if( this.playList.length === 1 ) {
					this.loop()
				} else {
					let index = this.currentIndex + 1;
					if( index === this.playList.length ) {
						index = 0
					}
					this.saveCurrentIndex(index)
					//是否处于播放状态  切换按钮状态
					this.switchState()
				}
				this.songReady = false
			},
			//防止粗错 按钮出错
			error() {
				this.songReady = true
			},
			//audio  事件
			updateTime(e) {
				this.currentTime = e.target.currentTime
			},
			//时间转换
			format(interval) {
				interval = interval | 0
				const minute = interval/60 | 0
				const second = this._pad(interval % 60)
				return `${minute}:${second}`
			},
			//切换歌曲的状态判定
			switchState() {
				//是否处于播放状态  切换按钮状态
				if( this.isPause  ) { 
					this.$nextTick(() => {
						this.$refs.audio.play()	
					})
				} else {
					this.$refs.audio.pause()
				}
			},
			//补0
			_pad(num,n = 2) {
				let len = num.toString().length
				while(len < n) {
					num = '0' + num
					len ++				
				}
				return num
			},
			//音乐加载完毕能播放的时候的事件
			ready() {
				this.songReady = true
			},
			//进度条
			progressFun() {
				let width = this.$refs.progressBox.clientWidth - progressBorder
				let pre = this.currentTime/this.currentSong.duration
				this._offset( width * pre )
			},
			//偏移量
			_offset(width,precent) {
				this.$refs.proBor.style.left = `${width}px`
				this.$refs.progress.style.width = `${width}px`
			},
			//开始点击
			progressStart(e) {
				this.touch.init = true
				this.touch.startX = e.touches[0].pageX
				this.touch.left = this.$refs.progress.clientWidth
			},
			//移动
			progressMove(e) {
				//还没start 就return
				if( !this.touch.init ) {
					return;
				}
				const moveX = e.touches[0].pageX - this.touch.startX
				const offsetWidth =Math.min( this.$refs.progressBox.clientWidth - progressBorder , Math.max(0,this.touch.left + moveX) )
				//console.log(offsetWidth + '~~~~~~~~~~~~~~~~')	
				this._offset(offsetWidth)
			},
			//离开
			progressEnd(e) {
				this.touch.init = false
				//音乐同步进度
				this._triggerPrecent()
			},
			//音乐同步进度
			_triggerPrecent() {
				const precent = this.$refs.progress.clientWidth/(this.$refs.progressBox.clientWidth-progressBorder)
				//快进
				let currentTime = this.currentSong.duration * precent
				this.$refs.audio.currentTime = currentTime
				//歌词同步  具体时间
				this.currentLyric && this.currentLyric.seek( currentTime * 1000 )
			},
			//点击进度
			changeProgress(e) {
				this._offset(e.offsetX)
				//音乐同步进度
				this._triggerPrecent()
			},	
			//切换播放模式
			changeMode() {
				const mode = ( this.mode + 1 ) % 3
				this.saveMode(mode)
				let list = null 
				if( mode === playMode.random ) {
					//随机播放
					list = shuffle(this.sequenceList)
					//this.saveSequence(arr)
				} else {
					list = this.sequenceList
				}
				this.resetCurrentIndex(list)
				this.savePlayList(list)
			},
			//重置currentIndex
			resetCurrentIndex(list) {
				let index = list.findIndex((item)=>{
					return item.id === this.currentSong.id
				})
				this.saveCurrentIndex(index)
			},
			//播放完毕
			end() {
				//
				if( this.mode === playMode.loop ) {
					this.loop()
				} else {
					this.nextBtn()					
				}
			},
			//重播
			loop() {
				this.$refs.audio.currentTime = 0
				this.$refs.audio.play()
				//重置
				this.currentLyric && this.currentLyric.seek()	
			},
			//get lyric
			getLyric() {
				initLyric(this.currentSong.mid).then((res) => {
					if( res !== '') {
						this.currentLyric = new Lyric(res , this.handleLyric)
						if( this.isPause ) {
							this.currentLyric.play()
						}
					}
				}).catch(()=>{
					this.playingLyric = ''
					this.currentLyric = null
					this.currentLineNum = 0
				})
				
			},
			//handleLyric 每次读完一条歌词  对应给的回调 主要区域
			handleLyric({lineNum , txt }) {
				this.currentLineNum = lineNum
				this.playingLyric = txt
				//操作better - scroll
				if( lineNum > 5 ) {
					let linef = this.$refs.lyricLine[lineNum-5]
					this.$refs.lyricList.scrollToElement(linef,1000)
				} else {
					//5行之内
					this.$refs.lyricList.scrollTo(0)
				}
			},
			//实例化swiper
			initSwiper() {
				this.$nextTick(()=>{
					this.lyricSwiper = new Swiper('.swiper-container', {
						wrapperClass : 'swiper-play',
						slideClass : 'swiper-play-slide',
						pagination : '.swiper-play-pagination',
						effect : 'coverflow',
					})
				})
			},
			...mapActions([
		        'saveTransPause',
		        'closeScreen',
		        'saveCurrentIndex',
		        'saveMode',
		        'saveSequence',
		        'savePlayList',
		    ]),
		},
		watch:{
			currentSong(newY) {
				//等加音频加载完毕再来播放
				//为了解决微信浏览器后台的原因，代码暂停，但是事件还是会执行，改成定时器卡住
				//this.$nextTick(() => {
				setTimeout( ()=>{
					this.$refs.audio.play()	
					this.saveTransPause(true)
				})
				//})
				
				if( this.currentLyric ) {
					this.currentLyric.stop()
				}
				this.getLyric()
				this.initSwiper()
				//initLyric(newY.mid)
			},
			//监听播放
			currentTime(newY) {
				if(newY !== 0 && !this.touch.init){ //并且拖动情况下不能同步展示
					this.progressFun()
				}
			},
		},
		components:{
			Scroll
		},
	}
</script>
<style type="text/css" lang="scss">
	
	.player{
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		z-index: 1000;
		.mini-player {
			position: fixed;
			bottom: 0;
			width: 100%;
			height: 60px;
			background-color:#333;
			z-index: 300;
			display: flex;
			&.mini-enter-active , .mini-leave-active{
				transition:all 1s;
			}
			&.mini-enter , .mini-leave-to{
				opacity: 0;
			}
			& > div:nth-child(1){
				width: 20%;
				position: relative;
				img{
					display: inline-block;
					margin-top: 10px;
					width: 40px;
					height: 40px;
					border-radius: 50%;
					overflow: hidden;

				}
				.miniImg{
					animation:rotation 5s linear infinite;
					-webkit-animation:rotation 5s linear infinite;
					-moz-animation:rotation 5s linear infinite;
					-ms-animation:rotation 5s linear infinite;
				}
				.miniPause{
					-webkit-animation-play-state: paused !important;
					 animation-play-state: paused !important;
				}
			}
			& > div:nth-child(2){
				width: 50%;
				padding-top: 5px;
				text-align: left;
				line-height: 22px;
				& > p:nth-of-type(1){
					color: #fff;
					font-size: 14px;
				}
				& > p:nth-of-type(2){
					color: rgba(255,255,255,.3);
					font-size: 12px;
				}
			}
			& > div:nth-child(3){
				width: 30%;
				color: #ffcd32;
				text-align: left;
				i{
					font-size:18px;
					line-height: 60px;
					border-radius: 50%;
					text-align: center;
					border:1px solid #ffcd32;
					padding: 4px;
				}
				& > i:nth-of-type(1){
					margin-right: 10px;
				}
				& > i:nth-of-type(2){

				}
			}
		}
		@-webkit-keyframes rotation{
			from {
				-webkit-transform: rotate(0deg);
				transform: rotate(0deg);
			}
			to {
				-webkit-transform: rotate(360deg);
				transform: rotate(360deg);
			}
		}
		@keyframes rotation{
			from {
				-webkit-transform: rotate(0deg);
				transform: rotate(0deg);
			}
			to {
				-webkit-transform: rotate(360deg);
				transform: rotate(360deg);
			}
		}

		//
		.song-play{
			position: fixed;
			width: 100%;
			height: 100%;
			display: block;
			background-color: #222;
			bottom: 0;
			left: 0;
			.song-play-pos{
				position: relative;
				width: 100%;
				height: 100%;
				.song-pos-bg{
					position: absolute;
					width: 100%;
					height: 100%;
					left: 0;
					top: 0;
					filter:blur(20px);
					-webkit-filter:blur(20px);
					-moz-filter:blur(20px);
					-ms-filter:blur(20px);
					opacity: .3;
					img{
						display: block;
						width: 100%;
						height: 100%;
					}
				}
				.song-pos-con{

					&> h2{
						position: relative;
						font-size: 20px;
						text-align: center;
						color: #fff;
						padding: 10px 0;						
						> p{
							padding:5px 0; 
							font-size: 14px;
							font-weight: 100;
							&:nth-of-type(1){
								font-size: 16px;
								padding-bottom: 0;
							}
						}
						&> i {
							position: absolute;
							left: 5%;
							top: 10px;
							padding: 3px;
							display: inline-block;
							font-size: 24px;
							color: #ffcd32;
						}
					}
					.song-con-bg{
						width: 100%;
						top: 80px;
						bottom: 130px;
						position: fixed;
						> div{
							position: relative;
							display: block;
							width: 100%;
							//padding-top: 100%;
							height: 100%;
						}
						.song-wrapper{
							position: absolute;
							width: 100%;
							left: 0%;
							top: 0;
							//overflow: hidden;
							height: 100%;
							img{
								margin: 0 auto;
								display: block;
								width: 90%;
								height: 90%;
								border-radius: 50%;
								overflow: hidden;
								border:8px solid #666;
								box-sizing:border-box;
							}
							.miniImg{
								animation:rotation 5s linear infinite;
								-webkit-animation:rotation 5s linear infinite;
								-moz-animation:rotation 5s linear infinite;
								-ms-animation:rotation 5s linear infinite;
							}
							.miniPause{
								-webkit-animation-play-state: paused !important;
								 animation-play-state: paused !important;
							}
						}
						.lyric-wrapper{
							color: rgba(255,255,255,.6);
							font-size: 14px;
							line-height: 26px;
						}
						.tips{
							width: 100%;
							padding: 5px;
							font-size: 14px;
						}
					}
				}
			}
		}

		//
		.song-pos-bot{
			position: absolute;
			width: 100%;
			display: inline-block;
			left: 0;
			bottom: 0;
			.sing-bot-icon{
				display: flex;
				padding: 30px 0;
				i{
					flex:1;
					font-size: 30px;
					color: #ffcd32;
				}
				.icon-random{
					color: red;
				}
				.icon-sequence{

				}
				.icon-loop{
					color: #bb32ff;
				}
			}
			.sing-bot-pre{
				color: #fff;
				width: 70%;
				margin: 0 auto;
				position: relative;
				.line{
					margin: 0 20px;
					border-radius: 5px;
					height: 5px;
					background-color: #111;
					position: relative;
				}
				.pos-line{
					position: absolute;
					left: 0;
					width: 0;
					height: 100%;
					background-color: #ffcd32;
					border-radius: 5px;
				}
				.pos-border{
					width: 20px;
					height: 20px;
					border-radius:50%;
					background-color: #fff;
					position: absolute;
					left: 0;
					top: 50%;
					transform:translateY(-50%);
				}
				.start{
					position: absolute;
					left: -35px;
					top: 50%;
					transform:translateY(-50%);
					font-size: 14px;
				}
				.end{
					position: absolute;
					right: -40px;
					top: 50%;
					transform:translateY(-50%);
					font-size: 14px;
				}
			}
		}
	}
	.palyer-enter-active,.palyer-leave-active{
        transition: all 0.4s;
        .song-pos-con, .song-pos-bot{
	          transition: all 0.4s cubic-bezier(0.86, 0.18, 0.82, 1.32)
        }
     }
    .palyer-enter, .palyer-leave-to{
        opacity: 0;
   		.song-pos-con{
          transform: translate3d(0, -100px, 0)
        }
        .song-pos-bot{
          transform: translate3d(0, 100px, 0)
        }
    }
    .swiper-play-box{
    	height: 100%;
    }
    .swiper-play-point{
    	bottom: 0px !important;
    }
    .lyric-play{
    	top: 20px;
    	height: calc(100% - 40px);
    }
    .hasLineHeight{
    	color: rgba(255,0,0,.8) !important;
    }
    .playNow_text{
    	color: rgba(255,255,255,.9);
    	font-size: 14px;
    	padding: 10px;
    	letter-spacing: 2px;
    }
</style>