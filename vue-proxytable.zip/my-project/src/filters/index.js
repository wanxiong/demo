import filters from './filter'


// 注册全局过滤器
// filters(Vue)

export default (Vue) => {
    Object.keys(filters).forEach(key => {
        Vue.filter(key, filters[key])
    })
}