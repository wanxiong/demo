import {commonParams } from './config'
import axios from 'axios'

export function getLyric(id) {
	const url = '/api/lyric'
	const data = Object.assign({}, commonParams, {
		songmid : id,
		pcachetime: +new Date(),
		platform: 'yqq',
		hostUin: '0',
		needNewCode: '0',
		g_tk:'67232076',
		format:'json',
	})

	return axios.get(url,{
		params:data
	}).then((res) => {
		return Promise.resolve(res.data)
	})
}

export function test(){ 
	return axios.post('/api/lyric/fcgi-bin/fcg_query_lyric_new.fcg',{
		
	}).then((res) => {
		return Promise.resolve(res.data)
	}).catch((res)=>{
		console.log(res)
	})
}

export function test_two(){ 
	return axios.post('/api/splcloud/fcgi-bin/fcg_get_diss_by_tag.fcg',{
		
	}).then((res) => {
		return Promise.resolve(res.data)
	}).catch((res)=>{
		console.log(res)
	})
}