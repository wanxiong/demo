import originJsonp from 'jsonp'
/*  jsonp
 *	@params  url  	 	api请求绝对路径
 *	@params  data  		api请求参数 
 *	@params  option  	callback 对应的名字
*/
let jsonp = (url , data ,option) => {
	url += ( url.indexOf('?') < 0 ? '?' : '&' ) + param(data)

	return new Promise( (resolve , reject) => {
		originJsonp( url , option , (err , data) => {
			if( !err ) { 
				resolve(data)
			} else{
				reject(err)
			}
		})
	})
}

let param = (data) => {
	let url = ''
	for( let key in data ) {
		let item = data[key] + ''
		let value = !item ? '' : item
		url += `${key}=${encodeURIComponent(value)}&` 
	}
	url = !url ? '' : url.substring(1,url.lastIndexOf('&') )
	return url

}
export default jsonp