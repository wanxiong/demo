import Vue from 'vue'
import store from './store'
import App from './App'
import router from './router'
import filters from './filters' 
//加载图片懒加载
import VueLazyload from 'vue-lazyload'
import $ from 'jquery'
//导入过滤器
filters(Vue)
//导入swiper
import 'swiper'
import '@/base/css/swiper.min.css'
import "@/base/css/reset.css";

//配置图片懒加载
Vue.use(VueLazyload, {
	//error: 'dist/error.png',//这个是请求失败后显示的图片
	loading: require('@/base/image/default.png'),//这个是加载的loading过渡效果
	try: 2, // 这个是加载图片数量,
    // filter: {
    //   webp ({ src }) {
    //   	  console.log('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
    //   	  console.log(src)
    //       return src
    //   }
    // }
})
// router.beforeEach((to, from, next) => {
//   if( 1) {
//     next()
//   } else {

//   }
// })
Vue.config.productionTip = false

/* eslint-disable no-new */
//注入  store  router
new Vue({
  el: '#app',
  store,
  router,
  render: h => h(App)
})
