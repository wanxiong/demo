<template>
	<ul v-show="data.length" class="song-list">
		<li v-for="(item , index) in data" @click="songDetail(item,index)">
			<h2>{{item.name}}</h2>
			<p>{{item.singer}} -{{item.name}} </p>
		</li>
	</ul>
</template>

<script type="text/javascript">
	export default {
		data() {
 			return {

 			}
		},
		methods :{

			songDetail(list,index) {
				//todo
				this.$emit('playsong',list,index)
			}
		},
		props:{
			data :{
				type : Array,
				default:[]
			}
		}
	}
</script>

<style type="text/css" lang="scss">
	.song-list{
		/* position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100;
		display: block;
		z-index: 300;
		 */
		 padding:20px;
		li{
			font-size: 12px;
			text-align: left;
			padding: 0 0 0 10px;
			color:rgba(255,255,255,0.3);
			height: 64px;
			line-height: 24px;
			h2{
				font-weight:100;
				font-size: 12px;
				color: #fff;
			}
		}
	}
</style>