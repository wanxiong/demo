<template>
	<div class="tabs">
		 <router-link tag="div" class="tab-item" to="/recommend">
		 	推荐
		 </router-link>
		 <router-link tag="div" class="tab-item" to="/singer">
		 	歌手
		 </router-link>
		 <router-link tag="div" class="tab-item" to="/rank">
		 	排行
		 </router-link>
		 <router-link tag="div" class="tab-item" to="/search">
		 	搜索
		 </router-link>
	</div>

</template>
<script >
	export default {

	}
</script>
<style type="text/css" lang="scss">
	.tabs{
		display: flex ;
		padding:10px 0;
		position: relative;
		z-index:200;
		background-color: #1c1d1d;
		div{
			flex: 1;
			font-size:14px;
			color:#666;
			&.router-link-active{
				color:#f40;
			}
		}
	}
</style>