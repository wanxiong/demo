<template>
	<div class="my-header">
		{{text}}
	</div>
</template>
<script>
	import {test , test_two} from 'api/common'
	export default {
		data() {
			return {
				text: 'hellow vincentwan'
			}
		},
		created(){
			test()
			test_two()
		}
	}	
</script>
	
</style>
<style lang="scss" scoped="" type="text/css">
	.my-header{
		text-align:center;
		font-size:14px;
		color: #42b983;
		padding:5px;
		position: relative;
		z-index: 100;
		background-color: #1c1d1d;
		width: 100%;
	}

</style>