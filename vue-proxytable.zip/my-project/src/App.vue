<template>
  <div id="app">
    <m-header></m-header>
    <tabs></tabs>
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
    <player></player>  
  </div>
</template>

<script>
  import MHeader from 'common/header/header'
  import Tabs from 'common/tabs/tabs'
  import Player from 'components/player/player'
  export default {
    name: 'app',
    components:{
        MHeader,
        Tabs,
        Player
    }
  }
</script>

<style scoped>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  background-color: #1c1d1d;
  height: 100%;
  overflow-y:scroll;
}
</style>
