﻿/**
 *  常用命令
 * 
 *  本地开发：fis3 release -wL   (发布到本地服务器目录，加-wl 同时监听文件变动和自动刷新浏览器)
 *           fis3 server start  (打开fis3自带的服务器)
 *           fis3 server open   (打开服务器目录)
 *           fis3 server clean  (清空服务器目录)
 * 
 * 构建到build目录：
 *           fis3 release build 
 */

//编译sass 
//需安装 npm install fis-parser-node-sass -g
fis.match(/^(?!_).+scss/, {
  rExt: '.css',
  parser: fis.plugin('node-sass', {
     success: function(css){
        //sass 编译
    }
  })
});

// 加 md5   目的为了是缓存不用每次刷新 你懂得
/*fis.match('*.{css,scss,sass}', {
  useHash: true
});*/


//雪碧图
// fis.match('::package',{//是否开启雪碧图 默认css里面
//   spriter : fis.plugin('csssprites'),
// });

// 清除其他配置，只保留如下配置
fis.match('*.js', {
  // fis-optimizer-uglify-js 插件进行压缩，已内置
  optimizer: fis.plugin('uglify-js')   //是否压缩
});

fis.match('*.{css,scss,sass}', {
  // fis-optimizer-clean-css 插件进行压缩，已内置
  optimizer: fis.plugin('clean-css'),//是否压缩
   useHash: true,
   //useSprite : true   //开启雪碧图
});

fis.match('*.png', {//用来压缩 png 文件，减少文件体积，详情请见 pngcrush 和 pngquant 说明。
  // fis-optimizer-png-compressor 插件进行压缩，已内置
  optimizer: fis.plugin('png-compressor',{
    // pngcrush or pngquant
    // default is pngcrush
    //type : 'pngquant'   //开启png压缩
  })  //是否压缩
  
});



// fis3 release start -wl   发布本地www并且监听
fis.media('start').match('*.{js,css,png}', {//本地浏览的时候不需要压缩
  useHash: false,
  useSprite: false,
  optimizer: null
});
//构建到build发布目录 fis3 release build   这才是打包
fis.media('build').match('*', {
  deploy: fis.plugin('local-deliver', {
    to: '../build'
  })
});
