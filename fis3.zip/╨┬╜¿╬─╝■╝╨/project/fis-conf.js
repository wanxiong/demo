﻿/**
 *  常用命令
 * 
 *  本地开发：fis3 release -wL   (发布到本地服务器目录，加-wl 同时监听文件变动和自动刷新浏览器)
 *           fis3 server start  (打开fis3自带的服务器)
 *           fis3 server open   (打开服务器目录)
 *           fis3 server clean  (清空服务器目录)
 * 
 * 构建到build目录：
 *           fis3 release build 
 */

//编译sass 
//需安装 npm install fis-parser-node-sass -g
fis.match(/^(?!_).+scss/, {
  rExt: '.css',
  parser: fis.plugin('node-sass', {
     success: function(css){
        //sass 编译
    }
  })
});

// 加 md5 
fis.match('*.{css}', {
  useHash: true
});




// 清除其他配置，只保留如下配置
fis.match('*.js', {
  // fis-optimizer-uglify-js 插件进行压缩，已内置
  optimizer: fis.plugin('uglify-js')   //是否压缩
});

fis.match('*.css', {
  // fis-optimizer-clean-css 插件进行压缩，已内置
  optimizer: fis.plugin('clean-css')  //是否压缩
});

fis.match('*.png', {
  // fis-optimizer-png-compressor 插件进行压缩，已内置
  optimizer: fis.plugin('png-compressor')    //是否压缩
});
fis.media('debug').match('*.{js,css,png}', {
  useHash: false,
  useSprite: false,
  optimizer: null
});
//构建到build发布目录
fis.media('build').match('*', {
  deploy: fis.plugin('local-deliver', {
    to: '../build'
  })
});
