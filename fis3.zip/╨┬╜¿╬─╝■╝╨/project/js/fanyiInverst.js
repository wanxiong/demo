define(function(require, exports, module) {
    var template = require('lib/art-template')
   
    var Ajax = require('common/ajax'),
        Utils = require('common/utils'),
        tpl = require('./productTpl.js');
       
    var app = {

        init: function() {
            var _this = this;
            _this.getProduct()
            _this.totalAmount = []
        },
        // 展示标的列表信息
        getProduct: function() {
            var _this = this;
             Ajax.send({
                config: {
                    url: 'product/bid/getList.json',
                    data: {
                        bid_type: 6
                    }
                },
                success: function(data) {
                    _this.getProductList(data)
                }
            });
        },
        /*存放数据*/
        getProductList : function(data){
            var _this = this;
            var html = '',
                url = 'productDetail.html?productid=';
            console.log(data)

            $.each(data,function(index ,  list) {
                if (list.cycleUnit == 1) {
                list.cycleUnitName = list.cycle + '天';
                } else if (list.cycleUnit == 2) {
                    list.cycleUnitName = list.cycle + '个月';
                } else if (list.cycleUnit == 3) {
                    list.cycleUnitName = list.cycle + '年';
                }
                if( list.completeRate ==null ){
                     _this.totalAmount.push(0)
                }else{
                    _this.totalAmount.push( list.completeRate/100)
                }
                list.url = url + list.bidId

                var  reader = template.compile(tpl.fanli)
                    html += reader(list)
         });

            $('.FL_inverst').append( html )
            setTimeout(function(){//一步
             _this.svgAnimate()
            }, 0)
        },
     
        /*环形*/
        svgAnimate : function(){
            var _this = this;
            $.each( $('.cir') , function(index, val) {
                 svg(val , _this.totalAmount[index])
                 $('.svg_sty').eq(index).html( ((_this.totalAmount[index] *100)  + '%') )
            });

             function svg(obj , value , L ) {
             var L = L || 1
             var percent = value / L, perimeter = Math.PI  * 2 * 32;
             obj.setAttribute('stroke-dasharray', perimeter * percent + " " + perimeter * (1- percent));
             }
          
        },

    };

    app.init();
});