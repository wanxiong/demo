define(function(require, exports, module) {
    require.async('rsa/rsajs');
    require('rsa/prng4');
    require.async('rsa/rng');
    require.async('rsa/jsbn');
    require.async('rsa/base64');
    require('rsa/md5');
    // require('lib/webStorage');
    var Ajax = require('common/ajax'),
        Utils = require('common/utils'),
        Validates = require('lib/validateUtil');
    Atpl = require('lib/art-template');

    var app = {

        init: function() {
            var _this = this;
            _this.bidId = Utils.getParameter("productId");

            _this.PRODUCT = {}; //当前产品
            _this.$myMoney = $('#investAmount');

            _this.selcJXQID = ''; //选中的加息券
            _this.selcJXQRATE = 0;
            _this.JXQlist = ''; //加息券列表

            _this.getProduct();
            _this.getCompanyInfo();
            _this.getjiaxiquan(); //前提用户登录，在列表层点击拦截

            _this.initPay();
            _this.isloginUserInfo();
            _this.lastSmsPay();
            _this.lastSubmitBuy();

            _this.modalSHow();
        },
        // 展示标的列表信息
        getProduct: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'product/bid/detail.json',
                    data: {
                        bidId: _this.bidId
                    }
                },
                success: function(data) {
                    window.localStorage.setItem('biaototalTimes',data.totalTimes);
                    window.localStorage.setItem('biaosaledAmount',data.saledAmount);
                    _this.setProduct(data);
                    _this.getExpectedRevenue();
                },
                failure: function(msg) {
                    Validates.showErrorMsg(msg);
                }
            });
        },
        setProduct: function(product) {
            var _this = this;
            
            _this.PRODUCT = product;
            _this.productId = _this.PRODUCT.productId;
            //计算周期
            if (product.cycleUnit == 1) {
                product.cycleUnitName = product.cycle + '天';
            } else if (product.cycleUnit == 2) {
                product.cycleUnitName = product.cycle + '个月';
            } else if (product.cycleUnit == 3) {
                product.cycleUnitName = product.cycle + '年';
            }
            //起息方式
            if (product.lenderFlag == "1") {
                product.investWay = "募集满当日+1个工作日计息";
            } else {
                product.investWay = "T+1个工作日计息";
            }
            $('#productCycle span').text(product.cycleUnitName);
            $('#collectAmount').text(product.totalAmount);
            $('#lenderFlag').text(product.investWay);
            $('.profitNum').text(product.annualRate);
            $('#minInvestment span').text(product.minInvestment);
            $('#restAmountRate').text(product.completeRate + '%');
            $('.percentBar').css({
                width: product.completeRate + '%'
            });
            $('#restAmount').text(product.restAmount);
        },
        // TODO
        //获取订单总收益  
        getExpectedRevenue: function() {
            var _this = this;
            _this.unitInvestAmount = 10000;
            var annualRate = (_this.PRODUCT.annualRate / 100).toFixed(2);
            var totalDays = 0;
            if (_this.PRODUCT.cycleUnit == 1) {
                totalDays = _this.PRODUCT.cycle;
            } else if (_this.PRODUCT.cycleUnit == 2) {
                totalDays = _this.PRODUCT.cycle * 30;
            } else if (_this.PRODUCT.cycleUnit == 3) {
                totalDays = _this.PRODUCT.cycle * 360;
            }
            _this.productRevenue = _this.unitInvestAmount*annualRate*totalDays/360;

            var investAmount = parseInt(Utils.removeComma(_this.$myMoney.val()));
            
            //页面加载第一次请求订单收益，以后计算
            if (_this.productRevenue !== '' && _this.productRevenue !== undefined) {
                var baseRevenue = investAmount * _this.productRevenue / _this.unitInvestAmount;
                var revenue = baseRevenue + _this.selcJXQRATE * baseRevenue / annualRate;
                $('#revenue').text(revenue.toFixed(2));
            }

        },
        // 获取标的的保障信息
        getCompanyInfo: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'product/bid/corp/info.json',
                    data: {
                        bidId: _this.bidId
                    }
                },
                success: function(data) {
                    $("#projectDescription .invest-doc-box").html(data.projectDescription);
                    $("#collateralInformation .invest-doc-box").html(data.collateralInformation);
                    $("#loanEnterpriseInfo .invest-doc-box").html(data.loanEnterpriseInfo);
                    $("#repaymentSource .invest-doc-box").html(data.repaymentSource);
                    $("#safeguardMeasures .invest-doc-box").html(data.safeguardMeasures);
                },
                failure: function(msg) {
                    Validates.showErrorMsg(msg);
                }
            });
        },

        // 获取加息券
        getjiaxiquan: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'coupon/user/getList.json',
                    data: {
                        productId: _this.productId,
                        type: '03', //加息券
                        status:0,
                        page: 1,
                        size: 10
                    }
                },
                success: function(json) {
                    if (json != undefined) {
                        var userActivityList = json.userActivityList;
                        if (userActivityList != null && userActivityList != '' && userActivityList.length > 0) {
                            _.forEach(userActivityList, function(userActivity, index) {
                                $('#jiaxiquan').append('<div class="checkInterest checked">12%</div>')
                                $("#jiaxiquan").prepend("<div class='checkInterest' data_activity='" + userActivity.userActivityId + "' data-value='" + userActivity.raiseRate + "'>" + "+" + userActivity.raiseRate + "%");
                            });
                            jiaxiclcik();
                        } else {
                            $("#jiaxiquan").html("您暂时无可用加息券");
                        }
                    } else {
                        $("#jiaxiquan").html("您暂时无可用加息券");
                    }

                },
                failure: function(msg) {
                    Validates.showErrorMsg(msg);
                },
                complete: function() {
                    _this.producCalc();
                }
            });

            function jiaxiclcik() {
                var _this = this;
                $(".checkInterest").each(function() {
                    $(this).on("click", function() {
                        if ($(this).hasClass("checked")) {
                            $(this).removeClass("checked");
                            _this.selcJXQRATE = 0;
                            _this.selcJXQID='';
                            _this.getExpectedRevenue(product);
                        } else {
                            $(this).siblings().removeClass("checked");
                            $(this).addClass("checked");
                            _this.selcJXQID=$(this).attr('data_activity');
                            _this.selcJXQRATE = $(this).attr('data-value');
                            _this.getExpectedRevenue(product);
                        }
                    });
                })
            }
        },


        initPay: function() {
            // 点击判断是否登录
            var _this = this;
            $('#initPay').click(function() {
                _this.goSubmit();
            });

        },
        goSubmit: function() {
            var _this = this;
            if ($('.payment-active').attr('data-type') == 1 && _this.userUnlockedValue < $('#investAmount').val()) {
                Validates.showErrorMsg("余额不足，请更换购买方式");
                return;
            }
            $('#initPay').prop('disabled', true);
            
            Ajax.send({
                config: {
                    url: 'order/save.json',
                    data: {
                        productId: _this.productId,
                        amount: _this.$myMoney.val(),
                        experId: "", //体验金
                        raiseRateId: '', //加息券
                        clientType: '04' //h5
                    }
                },
                success: function(orderId) {
                    _this.orderId = orderId;
                    require.async('lib/modal', function() {
                        $('#securityCode').modal('show');
                    })
                },
                failure: function(msg) {
                    Validates.showErrorMsg(msg);
                },
                complete: function() {
                    $('#initPay').prop('disabled', false);
                }

            });
        },

        // 短信验证码pay
        lastSmsPay: function() {
            var _this = this;
            var button = $('.sendCellReg'),
                timer = $('.sendCellReg');
            $(button).on("click", function() {

                if (!$(button).attr("disabled") || $(button).attr("disabled") == false) {
                    $(timer).html("获取90秒");
                    $(button).attr("disabled", true);
                    var time = 90;
                    var t = setInterval(function() {
                        if (time == 0) {
                            $(button).removeAttr("disabled");
                            clearInterval(t);
                            time = 90;
                            $(timer).html("获取验证码");
                        } else if (time > 0) {
                            time = time - 1;
                            $(timer).html("获取" + time + "秒");
                        }
                    }, 1000);
                    Ajax.send({
                        config: {
                            url: 'order/pay/msg/send.json',
                            data: {
                                'orderId': _this.orderId,
                                "payType": $('.payment-active').attr('data-type'),
                                'couponId': ''
                            }
                        },
                        success: function(data) {
                            //发送验证码成功
                             $('#lastSubmit').attr('disabled',false);
                        },
                        failure: function(data) {
                            Validates.showErrorMsg(data);
                            clearInterval(t);
                            $(button).removeAttr("disabled");
                            $(timer).html("获取验证码");
                        }

                    }); //end 发送验证码

                }
            });
        },
        lastSubmitBuy: function() {
            var _this = this;
            $('#lastSubmit').click(function() {
                _this.getPublicKey();
            });
        },
        lastSubmitReal: function() {
            var _this = this;
            if (!Validates.isNotEmpty($('.cellReg').val(), "短信验证码", true)) {
                return;
            }
            var mypaytype = $('.payment-active').attr('data-type');
            if (mypaytype != 2) { //银行卡支付
                var smscode = _this.rsaPass(md5($('.cellReg').val()));
            } else {
                var smscode = _this.rsaPass($('.cellReg').val());
            }

            $('#lastSubmit').prop('disabled', true).text('支付中...');
            Ajax.send({
                config: {
                    url: 'order/pay/confirm/do.json',
                    data: {
                        'orderId': _this.orderId,
                        "payType": mypaytype,
                        'validateCode': smscode,
                        'couponId': ''
                    }
                },
                success: function(data) {
                    window.location.href = '/pages/product/inverstStatus.html?paystatus=1';
                },
                failure: function(data) {
                    Validates.showErrorMsg(data);
                    $('#lastSubmit').prop("disabled", false).text('确定');
                },
                error: function(msg) {
                    Validates.showErrorMsg(msg);
                    $('#lastSubmit').prop("disabled", false).text('确定');
                }
            });
        },



        // 支付方式获取用户信息
        isloginUserInfo: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'user/info/detail.json',
                    data: {
                        no_length: 4
                    }
                },
                success: function(setInfo) {
                    _this.setPayInfo(setInfo);
                },
                failure: function(msg) {
                    Validates.showErrorMsg(msg);
                },
                unLogin: function() {
                    $('#initPay').prop('disabled', true);
                      $('.payment-terms a').text('');
                    $('.payment-method').html('<a href="/pages/login/appLogin.html#carlogin?returnurl=' + window.location.pathname + '">去登录</a>')
                        .removeAttr('data-target');

                },
            });
        },
        setPayInfo: function(setInfo) {
            var _this = this;
            $('.accountCell').text(setInfo.userMobile);
            if (setInfo.accountNo == undefined || setInfo.accountNo == "") { //未绑卡
                $('#initPay').prop('disabled', true);
                $('.payment-method').html('<a  href="/pages/myAccount/bindBankCard.html?bindtype=1&returnurl=' + window.location.pathname + '">去绑卡</a>')
                    .removeAttr('data-target');
            } else { //已绑卡
                // 弹出框
                $('.payment-method').click(function() {
                    require.async('lib/modal', function() {
                        $('#paymentTerms').modal('show');
                    });
                })
                if (setInfo.unlockedValue == undefined) {
                    setInfo.unlockedValue = 0;
                }
                _this.userUnlockedValue = setInfo.unlockedValue; //账户余额
                $('#unlockedValue').html('可用余额<em>' + setInfo.unlockedValue + '</em>元');
                $('#bankInfo').html(setInfo.accountName + '(尾号<em>' + (setInfo.accountNo).replace(/\*/g, '') + '</em>）');
                $('#showPayAmount').text(setInfo.unlockedValue);
            }
        },


        producCalc: function() {
            //最低100，最高10000,加减100
            var _this = this;
            var minInvest = 1000,
                maxInvest = 10000,
                minusadd = 100,
                defaultInvest = 100;

            maxInvest = Math.floor(_this.PRODUCT.totalAmount - _this.PRODUCT.saledAmount);

            if (_this.PRODUCT.productType == '4') {
                maxInvest = 10000;
            }
            _this.getExpectedRevenue(minInvest);
            // function _this.getExpectedRevenue(amount) {
            //     var html = '充值金额:' + amount + '元 实付<span>' + (amount * _this.productRate) + '元 节省<b>' + (amount - amount * _this.productRate) + '</b>元</span>';
            //     $('.recharge_exp').html(html);
            // }

            $("#add").on("click", function() {
                var addMoney = parseInt(_this.$myMoney.val());
                addMoney = addMoney + minusadd >= maxInvest ? maxInvest : addMoney + minusadd;
                _this.$myMoney.val(addMoney);

                _this.getExpectedRevenue(addMoney);
            });
            $("#minus").on("click", function() {
                var minusMoney = parseInt(_this.$myMoney.val());
                if (minusMoney >= (minInvest + minusadd)) {
                    minusMoney = minusMoney - minusadd;
                } else {
                    minusMoney = minInvest;
                }

                _this.$myMoney.val(minusMoney);
                _this.getExpectedRevenue(minusMoney);
            });
            $("#investAmount").on("blur", function() {
                var investAmount = parseInt(_this.$myMoney.val());
                if (!/^\d+$/.test(investAmount)) {
                    _this.$myMoney.val(defaultInvest);

                    _this.getExpectedRevenue(defaultInvest);
                } else if (investAmount < minInvest) {

                    _this.$myMoney.val(minInvest);
                    _this.getExpectedRevenue(minInvest);

                } else if (investAmount > maxInvest) {
                    _this.$myMoney.val(maxInvest);

                    _this.getExpectedRevenue(maxInvest);

                } else if (investAmount % minInvest != 0) {
                    investAmount = investAmount + minusadd >= maxInvest ? maxInvest : investAmount + minInvest - investAmount % minInvest;
                    _this.$myMoney.val(investAmount);

                    _this.getExpectedRevenue(investAmount);

                } else {
                    _this.$myMoney.val(investAmount);
                    _this.getExpectedRevenue(investAmount);

                }


            });

        },

        // 支付验证码加密
        getPublicKey: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'common/public_key.json',
                },
                success: function(response) {
                    _this.publicKey = response;
                    _this.lastSubmitReal();
                    return true;
                },
                failure: function(msg) {
                    Validates.showErrorMsg(msg);
                    return false;
                }
            });
        },
        rsaPass: function(pass) {
            var _this = this;

            var rsaKey = new RSAKey();
            rsaKey.setPublic(b64tohex(_this.publicKey.modulus), b64tohex(_this.publicKey.exponent));
            var enPassword = hex2b64(rsaKey.encrypt(pass));
            return enPassword;
        },


        modalSHow:function(){
            var _this=this;
            var modals=[
                {
                    triggleEle:'#linkToProjectBriefPage',referEle:'#projectDescription'
                },
                   {
                    triggleEle:'#linkToCollateralPage',referEle:'#collateralInformation'
                },
                   {
                    triggleEle:'#linkToCompanyInfoPage',referEle:'#loanEnterpriseInfo'
                },
                   {
                    triggleEle:'#linkToBenefitDetail',referEle:'#repaymentSource'
                },
                 {
                    triggleEle:'#linkToEnsureInfoPage',referEle:'#safeguardMeasures'
                },
                
            ];
            $.each(modals,function(index,item){
                $(item.triggleEle).click(function(){
                require.async('lib/modal', function() {
                        $(item.referEle).modal('show');
                    })
           	    })
            })
            

        }









    };

    app.init();
});