

define(function(require, exporst ,module  ){

	var tpl = {
		/*返利标*/
		fanli : '<li>\
		           <a href="{{url}}">\
		            <section class="FL_Up">\
		               <h3 class="FL_Up_name">{{bidName}}</h3>\
		               <p>首投金额≥10000，可获300元现金红包</p>\
		               <p>5000≤首投金额≤10000，可获150元现金红包</p>\
		            </section>\
		            <section class="FL_Down">\
		                <section class="FL_Down_left">\
		                    <span>年化收益率</span>\
		                    <p><span class="FL_left_scale">{{annualRate}}</span>%</p>\
		                </section>\
		                <section class="FL_Down_right">\
		                    <span>理财期限</span>\
		                    <p class="FL_right_day">{{cycleUnitName}}</p>\
		                </section>\
		                <section class="FL_svg">\
		                    <span class="svg_sty">30%</span>\
		                    <svg>\
		                       <circle cx="34" cy="34" r="32" stroke-width="2" stroke="#e9e9e9" fill="none"></circle>\
                        	   <circle class="cir" cx="34" cy="34" r="32" stroke-width="2" stroke="#ff5249" fill="none" stroke-dasharray="0 1069" angle="90"></circle>\
		                    </svg>\
		                </section>\
		            </section>\
		            </a>\
		        </li>',
		     /* */
	}


	module.exports = tpl
})