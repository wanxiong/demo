define(function(require, exports, module) {
    var
        Utils = require('common/utils'),
        Validates = require('lib/validateUtil');
    Ajax = require('common/ajax');

    var app = {
        init: function() {
            var _this = this;
_this.productId = Utils.getParameter("productId");
            _this.orderList();
            var totalTimes=window.localStorage.getItem('biaototalTimes');
            var saledAmount=window.localStorage.getItem('biaosaledAmount');

            $('.sumPeople').text(totalTimes);
            $('#sumMoney').text(saledAmount);

        },

        // 展示标的列表信息
        orderList: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'product/invest/records.json',
                    data:{
                        'productId':_this.productId,
                        "pageNo":"1","pageSize":"10000"
                    }
                },
                success: function(data) {
                    if (data.length == 0) {
                        $(".sumSingleHistory").html('暂无购买记录');
                    } else {
                        _this.setList(data);
                    }

                },
                failure: function(msg) {
                    Validates.showErrorMsg(msg);
                },
                
            })

        },

    
        setList: function(productList) {
            var _this = this;
            var html = '';
            $.each(productList, function(index, item) {
               
                html += _this.listHtml(item);
            })

            $(".sumSingleHistory").html(html);
        },
        listHtml: function(item) {
            _this = this;
            var html = ' <div class="singleHistory clear">'+
                '<div>'+
                    '<p class="investName">'+item.userMobilePhone+'</p>'+
                    '<p class="investDate">'+Utils.date2Format(item.createTime)+'</p>'+
                '</div>'+
                '<div>'+
                    '<p class="investMoney"><span>'+item.amount+'</span>元</p>'+
                '</div>'+
            '</div>';
            return html;
        }

    };

    app.init();
});