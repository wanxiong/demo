define(function(require, exports, module) {

    require('lib/webStorage');
    var Ajax = require('common/ajax'),
        Utils = require('common/utils'),
        Atpl = require('lib/art-template');

    var app = {
        protype: {
            xinshou: 4,
            huodong: 5,
            putong: 6
        },
        init: function() {
            var _this = this;
            _this.islogin();
        },
        islogin: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'user/login/getInfo.json'
                },
                success: function() {
                    _this.unLogin = false;
                },
                unLogin: function() {
                    _this.unLogin = true;
                },
                complete: function() {
                    _this.getXinshouList();

                }
            })
        },
        // 展示标的列表信息
        productList: function(bidtype, callback) {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'product/bid/getList.json',
                    data: {
                        bid_type: bidtype
                    }
                },
                success: function(data) {
                    callback && callback(data);
                }
            });
        },
        getXinshouList: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'product/bid/getList.json',
                    data: {
                        bid_type: _this.protype.xinshou
                    }
                },
                success: function(data) {
                    var html1 = '';
                    $.each(data, function(index, item) {
                        html1 += _this.producthtml(item);
                    });
                    $('#newPD ul').append(html1);

                    _this.getPutongList();

                }
            });


        },
        getPutongList: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'product/bid/getList.json',
                    data: {
                        bid_type: _this.protype.putong
                    }
                },
                success: function(data) {
                    var html = '';
                    $.each(data, function(index, item) {
                        html += _this.producthtml(item);
                    });
                    $('#normalPD ul').append(html);
                    _this.getHuodongList();
                }
            });


        },
        getHuodongList: function() {
            var _this = this;
            Ajax.send({
                config: {
                    url: 'product/bid/getList.json',
                    data: {
                        bid_type: _this.protype.huodong
                    }
                },
                success: function(data) {
                    var html = '';
                    $.each(data, function(index, item) {
                        html += _this.producthtml(item);
                    });
                    $('#actPd ul').append(html);
                }
            });

        },

        producthtml: function(product) {
            var _this = this;
            var url = "";
            if (!_this.unLogin) {
                url = 'productDetail.html?productid=' + product.bidId;
            } else {
                url = '/pages/login/appLogin.html#carlogin?returnurl=/pages/product/productDetail.html?productid=' + product.bidId;
            }
            var _this = this;
            if (product.cycleUnit == 1) {
                product.cycleUnitName = product.cycle + '天';
            } else if (product.cycleUnit == 2) {
                product.cycleUnitName = product.cycle + '个月';
            } else if (product.cycleUnit == 3) {
                product.cycleUnitName = product.cycle + '年';
            }

            var html = '<a href="' + url + '">' +
                '<li>' +
                '<div class="productSeries_info clear">' +
                '<div class="productSeries_info_name">' +
                '<div class="info_title_margin">' + product.bidName + '</div>' +
                '<div class="productSeries_info_benefit1">' +
                '<span style="style="padding-right: 5px;">' + product.annualRate + '</span>' +
                '<span class="productSeries_info_benefit_per">%</span>' +
                '</div>' +
                '</div>' +
                '<div class="productSeries_info_benefit">' +
                '<div class="info_title_margin">' + product.cycleUnitName + '</div>' +
                '<div> 期 限 </div>' +
                '</div>' +
                '<div class="productSeries_time">' +
                '<div class="info_title_margin">全额担保</div>' +
                '<div class="productSeries_purchase">' +
                '<span>购买</span>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</li>' +
                '</a>'
            return html;
        }

    };

    app.init();
});