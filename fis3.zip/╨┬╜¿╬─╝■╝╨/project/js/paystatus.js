define(function(require, exports, module) {


    var Ajax = require('common/ajax'),
        Utils = require('common/utils');
    var APP = require('lib/appSendEvent');

    var app = {
        paystatus: {
            success: 1, //支付成功
            fail: 2, //支付失败
            middle: 3 //支付中
        },
        paysource:{
            xingmei:2,
            fuelcard:1,
            chaincarbiao:0
        },
        init: function() {
            var _this = this;
            _this.status();
           
            // APP.bridgeInit();

            _this.share();
        },


        status: function() {
            var _this = this;
            var resourcePayStatus = Utils.getParameter('paystatus');
            var resourcePay = Utils.getParameter('paysource');
            $('.payment-Status status' + resourcePayStatus).removeClass('hide').siblings().removeClass('hide');
            if(resourcePay==_this.paysource.xingmei){
                $('.payment-Details').html(
                    '<p>客服电话：400-808-7988</p><a href="/pages/myAccount/movieOrderList.html">查看购买记录</a>'
                );
            }    
    },

        share: function() {
            var _this = this;
            $('#shareBuy').click(function() {
                APP.sendEvent({
                    name: 'openShareWithData',
                    param: {
                        image: 'http://chaincar.com/p/images/logo.png',
                        url: 'http://weixin.chaincar.com',
                        title: '链车金服LOGO',
                        describe: '这个图片是链车金服的logo图片'
                    },
                    success: function(msg) {
                        //
                    },
                });
            });
        }

    };

    app.init();
});