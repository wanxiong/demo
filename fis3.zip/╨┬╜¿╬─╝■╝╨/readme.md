##使用fis

### 1.安装过程
 * 安装nodejs 版本尽量最新
 * 安装fis3 `npm install -g fis3 ` (当前版本v3.3.21)
 * 安装node-sass **现在的css尽量使用sass写法，fis3自动将后缀.scss改为.css**
  1）` npm install -g node-sass`
  2）` npm install -g fis3-parser-node-sass` 
  (如果运行的时候提示libsass失败什么的，尝试安装 `npm install -g fis-parser-node-sass` 或者卸载node重新装fis3)
### 2.开发过程
* cmd进入开发目录`..src/`
* 执行命令-启动本地服务 `fis3 server start` (只需要执行一次)
* 执行命令-发布项目 `fis3 release debug -wL` (自动将开发目录`src`下面的文件全部发布到自带的服务器中，)

### 3.发布到build目录 
* 执行命令-发布项目 `fis3 release build `

> 本地开发只需要提交**src目录到svn**,无需执行**步骤3**命令，上线的时候操作。

test
