
var  tpl = {
	 	source : '<% for (var i = 0; i < dataIn.length; i ++) { %>\
					<li>\
						<p> <%= dataIn[i].name1 %> </p>\
						<p> <%= dataIn[i].name2 %> </p>\
						<p> <%= dataIn[i].name3 %> </p>\
						<p> <%= dataIn[i].name4 %> </p>\
					</li>\
				<% } %>'
 }



