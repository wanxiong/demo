'use strict';

window.nativeStorageSet = function () {
  window.nativeCall('storageSet', {
    key: 'ts',
    value: (+new Date()) / 1e3
  }, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeStorageGet = function () {
  window.nativeCall('storageGet', {
    key: 'ts'
  }, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeScanCode = function () {
  window.nativeCall('scanCode', {}, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeSnsShare = function () {
  window.nativeCall('snsShare', {
    title: 'The title goes here',
    description: 'The content goes here.',
    image: 'http://www.muji.com.cn/cn/store/feature/img/flagship/huaihai755/bg_openmuji.jpg',
    url: 'http://www.muji.com.cn/'
  }, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeGetContactNumber = function () {
  window.nativeCall('getContactNumber', {}, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeDialPhone = function () {
  window.nativeCall('dialPhone', {
    number: '+8613800138000'
  }, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeSendMessage = function () {
  window.nativeCall('sendMessage', {
    number: '+8613800138000',
    content: 'Hello world!'
  }, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeGetCacheSize = function () {
  window.nativeCall('getCacheSize', {}, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeClearCache = function () {
  window.nativeCall('clearCache', {}, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeGetGeoLocation = function () {
  window.nativeCall('getGeoLocation', {}, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeGeoNavigation = function () {
  window.nativeCall('geoNavigation', {
    title: '游仁堂',
    description: '游仁信息科技（上海）有限公司',
    address: '上海市普陀区曹杨路619号近铁云中心8层C座',
    latitude: '31.2217605258',
    longitude: '121.4194092372',
  }, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};

window.nativeShowOnlineService = function () {
  window.nativeCall('showOnlineService', {}, function (res) {
    window.alertify.alert(JSON.stringify(res));
  });
};
