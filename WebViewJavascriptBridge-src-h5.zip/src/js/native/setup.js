'use strict';

window.setupNativeBridge = function () {

  if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
    setupIosBridge(function (bridge) {
      // 封装
      bridge.send = function (handler, params, callback) {
        bridge.callHandler('default', JSON.stringify({ handler: handler, params: params }), callback)
      };
      // 监听事件
      var handlers = ['goTo', 'pushMessage', 'resume', 'pause'];
      handlers.forEach(function (handler) {
        bridge.registerHandler(handler, function (res) {
          if (typeof res === 'string') {
            res = JSON.parse(res);
          }
          window.alertify.alert('[iOS Native Bridge] ' + handler + ': ' + JSON.stringify(res));
        });
      });
      // 暴露
      window.iosBridge = bridge
    });
    // 延时 200 毫秒
    setTimeout(function () {
      if (window.iosBridge) {
        window.alertify.success('Initialized iOS Native Bridge');
      } else {
        window.alertify.error('Failed to initialize iOS Native Bridge');
      }
    }, 200);
  }

  if (/(Android)/i.test(navigator.userAgent)) {
    setupAndroidBridge();
    if (window.nativeApp) {
      // 监听事件
      var handlers = ['goTo', 'pushMessage', 'resume', 'pause', 'backbutton', 'menubutton', 'searchbutton'];
      handlers.forEach(function (handler) {
        window.nativeApp[handler] = function (res) {
          if (typeof res === 'string') {
            res = JSON.parse(res);
          }
          window.alertify.alert('[Android Native Bridge] ' + handler + ': ' + JSON.stringify(res));
        };
      });
      window.alertify.success('Initialized Android Native Bridge');
    } else {
      window.alertify.error('Failed to initialize Android Native Bridge');
    }
  }

};

window.nativeCall = function (handler, params, callback) {
  console.log('[Native Bridge] request:', { handler: handler, params: params });
  var bridge = window.iosBridge || window.nativeApp;
  if (bridge) {
    bridge.send(handler, JSON.stringify(params), function (res) {
      if (typeof res === 'string') {
        res = JSON.parse(res);
      }
      console.log('[Native Bridge] response:', res);
      callback.apply(null, [res]);
    });
  } else {
    window.alertify.alert('Native Bridge does not exist.');
  }
};

window.document.addEventListener('DOMContentLoaded', function () {
  window.setupNativeBridge();
}, false);
