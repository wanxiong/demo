
define(function(require, exports, module) {
    var $ = require('lib/jquery');

    var util = {
		
		/**
		 * 获取URL中的数据
		 */
		getParameter : function(name) {
			var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
			var r = window.location.search.substr(1).match(reg);
			if (r != null)
				return unescape(r[2]);
			return null;
		},
		/**
		 * 银行卡号显示信息
		 */
		bankAccount:function(acc){
			var name="";
			if(acc !=null&&acc.length>4){
				name=acc.substr(0,4)+" *** "+acc.substr(acc.length-4);
			}
			return name;
		},
		/**
		 * 银行卡号显示4位尾号
		 */
		bankEnd4No:function(acc){
			var name="";
			if(acc !=null&&acc.length>4){
				name=acc.substr(acc.length-4);
			}
			return name;
		},
		//将投资金额以100,000.00的格式显示
		showMoney : function(data){
			var data = data +'';
			var str = data.split('.')[0];
			var temp = '';
			if(str.length > 3){
				while(str.length  > 3){
					if(temp == ''){
						temp = str.substr(str.length-3 ,str.length);
					}else{
						temp = str.substr(str.length-3 ,str.length) + ',' + temp ;
					}
					str = str.substr(0 ,str.length-3);
				}
				if (str != null || str != ''){
					temp = str + ',' + temp;
				}
			}else{
				temp = str ;
			}
			if( data.split(".")[1] && data.split(".")[1] != null ){
				temp = temp +'.'+data.split(".")[1];
			}else{
				temp = temp +'.00';
			}
			
			return temp ;
		},
		//显示手机号
		passMobile:function(tel){
			if(tel !=null){
				 return  tel.substr(0,3)+'****' +tel.substr(7,11);
			}
			return null;
		},
		/**
		 * 毫秒转为yyyy.MM.dd HH:mm:ss格式
		 */
		dateFormat : function(millisecond){
			if(millisecond ==  null || !millisecond || millisecond ==''){
				return '--';
			}
			var _this = this;
		    var date = new Date(millisecond);
		    var seperator1 = ".";
		    var seperator2 = ":";
		    var month = date.getMonth() + 1;
		    var strDate = date.getDate();
		    if (month >= 1 && month <= 9) {
		        month = "0" + month;
		    }
		    if (strDate >= 0 && strDate <= 9) {
		        strDate = "0" + strDate;
		    }
		    var temp_hours = date.getHours();
		    var temp_minutes = date.getMinutes();
		    var temp_seconds = date.getSeconds();
		    if (temp_hours >= 1 && temp_hours <= 9) {
		    	temp_hours = "0" + temp_hours;
		    }
		    if (temp_minutes >= 1 && temp_minutes <= 9) {
		    	temp_minutes = "0" + temp_minutes;
		    }
		    if (temp_seconds >= 1 && temp_seconds <= 9) {
		    	temp_seconds = "0" + temp_seconds;
		    }
		    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
		            + " " + temp_hours + seperator2 + temp_minutes
		            + seperator2 + temp_seconds;
		    return currentdate;

		},
		/**
		 * 毫秒转为yyyy-MM-dd 格式
		 */
		date2Format : function(millisecond){
			if(millisecond ==  null || !millisecond || millisecond ==''){
				return "--";
			}
			var _this = this;
		    var date = new Date(millisecond);
		    var seperator1 = "-";
		    var seperator2 = ":";
		    var month = date.getMonth() + 1;
		    var strDate = date.getDate();
		    if (month >= 1 && month <= 9) {
		        month = "0" + month;
		    }
		    if (strDate >= 0 && strDate <= 9) {
		        strDate = "0" + strDate;
		    }
		    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
		    return currentdate;
		},
		
		/**
		 * 加上逗号
		 */
        addComma : function(id)
        {
        	id = id + "";
            var v, j, sj, rv = "";
            v = id.replace(/,/g,"").split(".");
            j = v[0].length % 3;
            sj = v[0].substr(j).toString();
            for (var i = 0; i < sj.length; i++)
            {
                rv = (i % 3 == 0) ? rv + "," + sj.substr(i, 1): rv + sj.substr(i, 1);
            }
            var rvalue = (v[1] == undefined) ? v[0].substr(0, j) + rv: v[0].substr(0, j) + rv + "." + v[1];
            if (rvalue.charCodeAt(0) == 44)
            {
                rvalue = rvalue.substr(1);
            }
            return rvalue;
        },
		/**
		 * 去掉逗号
		 */ 
         removeComma : function(id)
        {
        	id = id + "";
            var v;
            v = id.replace(/,/g,"");
            return Number(v);
        },
        /**
         * 倒计时
         */
        timer:function(button,timer,msg){
			var time = 90;
			var t = setInterval(function() {
				if (time == 0) {
					$(button).removeAttr("disabled");
					clearInterval(t);
					time = 90;
					$(timer).html("获取验证码");
					if(msg){
						$(timer).html(msg);
					}
				} else if (time > 0) {
					time = time - 1;
					$(timer).html("获取" + time + "秒");
				}
			}, 998);
		},
		
		totalPage:function(total,pageSize){
			var totalPage=1;
			if(total!=null&&total!=0){
				if(total%pageSize == 0){
					totalPage= total/pageSize;
				}else{
					totalPage = parseInt(total/pageSize) + 1 ;
				}
			}
			return totalPage;
		},
		
		comparetDate : function(t){
			var nowDate = new Date();
			var str = t.replace(/\./g,'\/');
			var tt = new Date(str);
			if(nowDate.getTime() >= tt.getTime()){
				return true ;
			}
			return false ;
		},
		
		decimalFormat:function(value,n){
			var f=parseFloat(value);
			return f.toFixed(n);
		},
		/**
		 * 毫秒转为MM月dd日 格式
		 */		
		date4Format : function(millisecond){
			if(millisecond ==  null || !millisecond || millisecond ==''){
				return "--";
			}
			var _this = this;
		    var date = new Date(millisecond);
		    var seperator1 = "月";
		    var seperator2 = "日";
		    var month = date.getMonth() + 1;
		    var strDate = date.getDate();
		    var currentdate = month + seperator1 + strDate + seperator2;
		    return currentdate;
		}
	}

    module.exports = util;
});