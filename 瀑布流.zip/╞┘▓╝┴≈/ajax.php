<?php

	header('Content-Type:text/html;charset=utf-8');

	$result = file_get_contents('json.json');


	echo $result;

?>