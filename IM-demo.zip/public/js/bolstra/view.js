/** 页面元素控制 */
var view_control = function () {
	//绑定切换内容
	$('#conversation_list_ul').delegate('li','click',this.chatContent.bind(this));
	 //聊天编辑区域元素
	this.cSetailC = $('.c-detail-c ul');
	this.cSetailCBox = $('.c-detail-c');
	this.viewControl = this;
	//聊天编辑区域title文言元素
	this.currentTitle = $('#current_conversation_title');
	this.initEmpty = false
	this.dataArray = []
	//解决SDK重复调用updateSession
	this.sessionBoolean = false
	//绑定加载历史记录
	this.cSetailCBox.on('scroll',window.addHistoryContent)
}

view_control.fn = view_control.prototype;

/**聊天内容面板UI重置*/
view_control.fn.chatContent = function(){
	//解决初始化数据被清空
	if (!this.initEmpty) {
		this.initEmpty = true
		return 
	}
	this.emptyContent(this.cSetailC);
	this.emptyContent(this.currentTitle);
	for (var i = 0; i < this.teamList.length; i++) {
		if(this.tabIndex == i){
			this.ContentTileView(this.teamList[i])
			this.ContentConView(this.teamList[i])
			break ;
		}
	}

	console.log(this)
	console.log('来自绑定动态的LI')
}
/**清空内容*/
view_control.fn.emptyContent = function(obj){
	obj.empty();
}
/**聊天内容头部UI*/
view_control.fn.ContentTileView = function(team){
	this.currentTitle.text(team.name);
}
/**聊天内容具体聊天记录UI*/
view_control.fn.ContentConView = function(team){
	//再次请求
	
	messageDetail()
}
/** 显示会话一览 */
view_control.fn.show_conversation_list = function (list) {
	
	
	custom.arrayId = [];
	if (list != null && list.length > 0) {
		custom.id = list[0].id || '';
		for (var i = 0; i < list.length; i++) {
			var $li = $("<li></li>");
			if (list[i].topicType == BOLSTRA_CODE.conversation_topic_type_trade){
				$li.addClass("service");
			} else {
				$li.addClass("serviceName");
			}
			
			if( list[i].id == custom.conversationId ){
				custom.conversationIndex = i
			}
			var $span = $("<span></span>").text(list[i].title);
			if( list[i].unreadCount ){
				$span.addClass('c-t-point')
			}
			
			$li.append($span);
			$li.bind("click", {id:list[i].id,viewControl:this.viewControl,isFirst:true}, conversation_switch);
			$("#conversation_list_ul").append($li);
			
			custom.arrayId.push(list[i].id)
		}
	}
}

/** 显示会话详情 */
view_control.fn.show_conversation_detail = function (detail) {
	// 显示标题
	$("#current_conversation_title").text(detail.title);
	// 显示成员
	$("#conversation_user_company,#conversation_user_agency").empty();
	for (var i = 0; i < detail.userList.length; i++) {
		// 区分会话成员角色
		if (BOLSTRA_CODE.conversation_user_trade_role_company == detail.userList[i].tradeRole) {
			$("#conversation_user_company").append($("<li></li>").text(detail.userList[i].imName));
		} else {
			$("#conversation_user_agency").append($("<li></li>").text(detail.userList[i].imName));
		}
	}
}

/**会话内容详情*/
view_control.fn.buildSessions = function(id){
	console.log(this.data)

};

/**
 *会话消息默认显示第一条 
 *@param
 *	@data  数据
 *	@debug default boolean  fasle confirm (append  || prevend) create html
 *、	
 */
view_control.fn.defaultFirst = function(data,debug){
	var Debug = debug || false
	var data = data.list,
		HTML = '';
	var list= data
		HTML = '';
	newArr = chooseNowPerson(list,true);
	if ( newArr ) list = newArr;
	for(var i=list.length-1;i>=0;i--){ 
		if(list[i].sendUserId == custom.userId ){
			if( list[i].contentType == 1 ){//文本信息
				HTML += '<li class="detail-right clear">'+
						'<div class="right-service-name">'+list[i].sendImName+'</div>'+
						'<div class="right-content">'+
						'<p>'+list[i].content+'</p>'+
						'<span class="right-icon"></span>'+
					'</div>'+
				'</li>'
			} else {// 2 3  图片 文件类型 
				HTML += '<li class="detail-right clear">'+
					'<div class="right-service-name">'+list[i].sendImName+'</div>'+
					'<div class="right-content">'+
					'<a target="_blank" href="'+list[i].filePath+'" title="" class="file-icon">'+list[i].content+'</a>'+
					'<span class="right-icon"></span>'+
				'</div>'+
			'</li>'
			} 
			
		} else {
		//不是本人发送消息
			if( list[i].contentType == 1 ){//文本消息
				HTML += '<li class="detail-left clear">'+
				'<div class="left-service-name">'+list[i].sendImName+'</div>'+
				'<div class="left-content" style="margin-top: 10px;">'+
				'<p>'+list[i].content+'</p>'+
				'</div>'+
				'</li>'

			} else { //文件类型 //图片信息
				HTML += '<li class="detail-left clear">'+
				'<div class="left-service-name">'+list[i].sendImName+'</div>'+
				'<div class="left-content">'+
				'<a target="_blank" href="'+list[i].filePath+'" title="" class="file-icon">'+list[i].content+'</a>'+
				'<span class=left-icon"></span>'+
				'</div>'+
				'</li>'
			} 
			
		}
	}
	
	if( Debug ){
		var h = this.cSetailC.prepend(HTML).height();
		this.cSetailCBox.scrollTop(h - custom.scrollTop);
		debugger
	} else {
		this.cSetailC.append(HTML);
		this.cSetailCBox.scrollTop(999999);
	}
}



/**
 * @param 
 * @data   数据
 * @debug boolean  区别是发消息还是接消息
 *发送消息 
 */

view_control.fn.sendText = function(data,debug){
	var Debug = debug || false
	var data = data,
		HTML = '';
	hasText = chooseNowPerson(data.text);
	if ( hasText ) data.text = hasText;
		if ( !Debug ){//发消息
			if( data.type == "text" ){
				HTML += '<li class="detail-right clear detail-right-now">'+
							'<div class="right-service-name">'+data.fromNick+'</div>'+
							'<div class="right-content">'+
								'<p>'+data.text+'</p>'+
								'<span class="right-icon"></span>'+
							'</div>'+
						'</li>'
			}
	   } else {//接消息
		   if( data.type == "text" ){
				HTML += '<li class="detail-left clear">'+
							'<div class="left-service-name">'+data.fromNick+'</div>'+
							'<div class="left-content">'+
								'<p>'+data.text+'</p>'+
								'<span class="left-icon"></span>'+
							'</div>'+
						'</li>'
			}
	   }
	
	this.cSetailC.append(HTML);
	this.cSetailCBox.scrollTop(999999);
}

/**
 * @param 
 * debug default false  if debug is true  ? Receive : send
 * data 参数
 * 文件发送view
 */
view_control.fn.sendFileText = function(data,debug){
	var debug = debug || false
	var data = data,
	HTML = '';
	if( !debug ){//发送消息
		//if( !data.content.url ){
			HTML += '<li class="detail-right clear">'+
					'<div class="right-service-name">'+data.fromNick+'</div>'+
					'<div class="right-content">'+
					'<a target="_blank" href="'+data.content.url+'" title="" class="file-icon">'+data.content.fileName+'</a>'+
					'<span class=right-icon"></span>'+
					'</div>'+
				'</li>'
		/*} else {
			HTML += '<li class="detail-right clear">'+
			'<div class="right-service-name">'+data.fromNick+'</div>'+
			'<div class="right-content">'+
			'<img width="200px" src='+data.content.url +' />'+
			'</div>'+
		'</li>'*/
		//}
	} else {//接收
		//if( !data.content.url ){
			HTML += '<li class="detail-left clear">'+
					'<div class="left-service-name">'+data.fromNick+'</div>'+
					'<div class="left-content">'+
					'<a target="_blank" href="'+data.content.url+'" title="" class="file-icon">'+data.content.fileName+'</a>'+
					'<span class=left-icon"></span>'+
					'</div>'+
				'</li>'
		/*} else {
			HTML += '<li class="detail-left clear">'+
			'<div class="left-service-name">'+data.fromNick+'</div>'+
			'<div class="left-content">'+
			'<img  width="200px" src='+data.content.url +' />'+
			'</div>'+
		'</li>'*/
		//}
		
	}
			
			
	this.cSetailC.append(HTML);
	this.cSetailCBox.scrollTop(999999);
}
/**
 *添加point 
 */
view_control.fn.addPoint = function(data){
	var conversationListUl = $('#conversation_list_ul li')
	var data = data
			for (var i = 0; i < view.teamList.length; i++) {
				if( data.to == view.teamList[i].imTid && i != view.tabIndex ){
					conversationListUl.eq(i).children('span').addClass('c-t-point');
					custom.imMessageId = data.idServer
					
				}
			
		}
}
/**
 * 会话历史记录
 * 
 */
view_control.fn.messageHistory = function(data){
	var html = '',
		data = data.list || [],
		time = '';
		if ( data.length > 0){
			for( var i = 0 ; i < data.length ; i++){
				time = data[i].sendTime.slice(0,4) +'年'+ data[i].sendTime.slice(5,7) +'月'+data[i].sendTime.slice(8,10)+'日'
				html += '<li><span class="his-date">'+
					'<p>'+time+'</p> <i></i>'+
					'</span><p>'+
					'<strong>'+data[i].sendImName+'</strong> : '+data[i].content+
					'</p>'+
				 '</li>'	
			}
		} else {
			html += '<li>暂无数据</li>';
		}
		
	$('.his-name ul ').empty().append(html)
}






