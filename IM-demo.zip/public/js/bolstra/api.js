/** API 功能相关 */
var bolstra_api = function () {
	
}

bolstra_api.fn = bolstra_api.prototype

/** 服务猫登录 */
bolstra_api.fn.login = function (token, callBack) {
	var param = {"token":token};
	ajaxApi(param, BOLSTRA_API_URL.login, callBack);
}

/** 获取会话一览 */
bolstra_api.fn.getConversationList = function (token, callBack) {
	var param = {"token":token};
	ajaxApi(param, BOLSTRA_API_URL.conversation_getList, callBack);
}

/** 获取会话详情 */
bolstra_api.fn.getConversationDetail = function (token, conversationId, callBack) {
	var param = {"token" : token, "conversationId" : conversationId};
	ajaxApi(param, BOLSTRA_API_URL.conversation_getDetail, callBack);
}
/**
 * 会话详情的一览
 * 
 */
bolstra_api.fn.messageDetail = function(param,callBack,faild){
	ajaxApi(param, BOLSTRA_API_URL.message_getDetail, callBack,faild);
}
/**
 *消息已读 
 * 
 */
bolstra_api.fn.messageReceive = function(param,callBack){
	ajaxApi(param, BOLSTRA_API_URL.message_receive, callBack);
}
/**
 *会话成员新增
 * 
 */
bolstra_api.fn.conversationUserCreate = function(param,callBack){
	ajaxApi(param, BOLSTRA_API_URL.conversationUser_create, callBack);
}
/**
 *文件上传获取签名 
 * 
 */
bolstra_api.fn.fileUploadGetSign = function(param,callBack){
	ajaxApiOss(param, BOLSTRA_API_URL.fileUpload_getSign, callBack);
}
/**
 * 取得交易相关人员一览。
 * 
 */
bolstra_api.fn.tradeMemberGetList = function(param,callBack){
	ajaxApi(param, BOLSTRA_API_URL.tradeMember_getTradeList, callBack);
}
/**
 * 取得交易企业的相关人员一览。
 * 
 */
bolstra_api.fn.tradeCompanyMemberGetList = function(param,callBack){
	ajaxApi(param, BOLSTRA_API_URL.tradeMember_getCompanyList, callBack);
}
/**
 *添加该交易的相关人员。 
 * 
 */
bolstra_api.fn.tradeMemberCreate = function(param,callBack){
	ajaxApi(param, BOLSTRA_API_URL.tradeMember_create, callBack);
}
/**
 *删除该交易的相关人员 
 * 
 */
bolstra_api.fn.tradeMemberDelete = function(param,callBack){
	ajaxApi(param, BOLSTRA_API_URL.tradeMember_delete, callBack);
}
/** AJAX请求共同 */
function ajaxApi (param, url, callBack,faildCallBack) {
	param.language = 'cn'
	param = JSON.stringify(param);
	$.ajax({
		type:"post",
		url:BOLSTRA_CONFIG.domain + url,
		contentType:"application/json; charset=utf-8",
		data:param,
		dataType:"json",
		timeout:30000,
		error : function (XMLHttpRequest, textStatus, errorThrown) {
			layer.alert("网络错误，请稍后重试", {icon: 5,title:"出错啦"});
			faildCallBack && faildCallBack(XMLHttpRequest,textStatus,errorThrown);
		},
		success:callBack
	});
}

/** AJAX OSS 请求共同 */
function ajaxApiOss (param, url, callBack,faildCallBack) {
	param.language = 'cn'
	param = JSON.stringify(param);
	$.ajax({
		type:"post",
		url:BOLSTRA_OSS.domain + url,
		async: false,
		contentType:"application/json; charset=utf-8",
		data:param,
		dataType:"json",
		timeout:30000,
		error : function (XMLHttpRequest, textStatus, errorThrown) {
			layer.alert("网络错误，请稍后重试", {icon: 5,title:"出错啦"});
			faildCallBack && faildCallBack(XMLHttpRequest,textStatus,errorThrown);
		},
		success:callBack
	});
}