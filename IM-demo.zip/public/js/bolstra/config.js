(function() {
    // 配置
    var configMap = {
    	local: {
    		domain : 'http://localhost:8080/im'
        },
        localIp: {
    		domain : 'http://192.168.1.156:8080/im'
        },
        dev: {
    		domain : 'http://20161214.team-lab.cn/im'
        },
        staging: {
    		domain : 'http://20161214.team-lab.cn/im'
        },
        product: {
    		domain : 'http://20161214.team-lab.cn/im'
        },
        oss:{
        	domain:'http://20161214.team-lab.cn'
        },
        common_config : {
        	api_url : {
        		login : "/user/login",
        		conversation_getList : "/conversation/getList",
        		conversation_getDetail : "/conversation/getDetail",
        		message_getDetail	:"/message/getList",
        		message_receive:"/message/receive",
        		conversationUser_create	:'/conversationUser/create',
        		fileUpload_getSign	:'/api/front/file/upload/getSign',
        		conversationUser_create :'/conversationUser/create',
        		conversationUser_delete :'/conversationUser/delete',
        		tradeMember_getTradeList:'/tradeMember/getTradeList',
        		tradeMember_getCompanyList:'tradeMember/getCompanyList',
    			tradeMember_delete:'/tradeMember/delete',
    			tradeMember_create:"/tradeMember/create"
        	},
        	code : {
        		/** 请求结果 1 成功 */
        		api_result_ok : "1",
        		/** 会话区分 2 交易 */
        		conversation_topic_type_trade : "2",
        		/** 会话区分 1 .服务咨询 */
        		conversation_topic_type_service : "1",
        		/** 会话区分 3 .企业咨询 */
        		conversation_topic_type_company : "3",
        		/** 会话成员交易角色 1 买方企业 */
        		conversation_user_trade_role_company : "1"
        	}
        }
    };
    window.BOLSTRA_CONFIG = configMap["dev"];
    window.BOLSTRA_OSS = configMap["oss"];
    window.BOLSTRA_API_URL = configMap["common_config"].api_url;
    window.BOLSTRA_CODE = configMap["common_config"].code;
}())