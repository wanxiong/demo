
/** 会话切换 */
function conversation_switch (event) {
	//存入当前tab的序列
	view.tabIndex = event.data.viewControl.tabIndex = $(this).index()
	custom.id = custom.arrayId[view.tabIndex]
	//分页初始化
	custom.page=1
	$('.his-name ul').empty()
	$('#txtBeginDate,#txtEndDate,.edit-area,.fileChange input').val('')
	//去除point
	clearPoint($(event.delegateTarget));
	// 样式切换
	$(event.delegateTarget).addClass("active").siblings().removeClass("active")
	
	/*for (var i = 0; i < imUser.conversationList.length; i++) {
		if (imUser.conversationList[i].id == event.data.id) {
			// 判断会话详情是否存在，不存在则请求API，存在则直接使用
			if (imUser.conversationList[i].detail == null) {
				loading = layer.load(1,{shade: [0.5,'#000']});
				api.getConversationDetail(user_token, event.data.id, getConversationDetail);
			} else {
				view.show_conversation_detail(imUser.conversationList[i].detail);
			}
		}
	}*/

	api.getConversationDetail(user_token, event.data.id, getConversationDetail);
	
}

/*去除point*/
function clearPoint (obj,debug) {
	
	var childrenElement =  obj.children('span')
	if( childrenElement.hasClass('c-t-point') ){
		
		childrenElement.removeClass('c-t-point')
		//消息已读
		messageReceive();
	}
}