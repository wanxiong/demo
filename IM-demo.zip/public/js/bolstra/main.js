/** 实例化服务猫API */
var api = new bolstra_api();
var view = new view_control();
var sdk,loading,imUser;

/*发送按钮*/
var editSend = $('.edit-send');
/*传送文件按钮*/
var editUpload = $('.edit-upload');
/*文言编辑区域*/
var editArea = $('.edit-area');
//input flie 元素
var uploadBtn = $('.edit-upload');
//uploadFile
//查询按钮
var fSearch = $('.f-search');
//var uploadFile = $('#uploadFile');
//添加成员
var add_member = $('.add-member');
editSend.on('click',sendTextMessage.bind(view))
fSearch.on('click',messageDetailHistory.bind(view))
editArea.on('keydown',inputMessageSend.bind(editArea))

var uploader;

var custom = {
	"page":1,
	"count":10,
	"loadMore":true,
	"scrollTop":0,
	"imMessageId":'',
	"conversationId":location.search.split('=')[1] || 0
}
var index = layer.load(1, {
  shade: [0.1,'#fff'] //0.1透明度的白色背景
});
//上传图片初始化
initWebUploader()

// 获取token
var user_token = readCookie("user_token");


if (user_token == null || user_token == "") {
	alert("尚未登录，无法使用IM！");
} else {
	loading = layer.load(1,{shade: [0.5,'#000']});
	api.login(user_token, loginCallBack);
}

/** 登录成功的回调 */
function loginCallBack (result) {
	if (BOLSTRA_CODE.api_result_ok == result.resultCd) {
		imUser = result.results;
		// 获取会话一览
		api.getConversationList(user_token, getConversationList);
		//用户ID
		custom.userId = imUser.userId
		//连接SDK
		SDK = new SDKBridge(imUser,view);
		
	} else {
		layer.alert('获取IM登录信息失败，请稍候重试！', {icon: 2,title:"出错啦"});
	}
}

/** 获取会话一览 回调 */
function getConversationList (result) {
	if (BOLSTRA_CODE.api_result_ok == result.resultCd) {
		
		imUser.conversationList = result.results.list;
		if(result.results.list.length == 0) return false;//没群
		view.teamList = result.results.list;
		view.userId = result.results.userId;
		view.companyId = result.results.companyId;
		view.show_conversation_list(result.results.list);
		//渲染当前数据
		if ( view.teamList.length == 0) return false;
		$("#conversation_list_ul li").eq(custom.conversationIndex).click().bind(view);
		//messageDetail()
		
	} else {
		layer.alert('获取会话一览信息失败，请稍候重试！', {icon: 2,title:"出错啦"});
	}
}

/** 会话详情回调 */
function getConversationDetail (result) {
	if (BOLSTRA_CODE.api_result_ok == result.resultCd) {
		// 更新会话列表中的会话详情
		/*for (var i = 0; i < imUser.conversationList.length; i++) {
			if (imUser.conversationList[i].id == result.results.id) {
				imUser.conversationList[i].detail = result.results;
			}
		}*/
		view.show_conversation_detail(result.results);
		view.person = []
		result.results.userList.forEach(function(key,value){//存数成员
			view.person.push(key.imName)
		})
		
		layer.close(loading);
	} else {
		layer.alert('获取会话详情信息失败，请稍候重试！', {icon: 2,title:"出错啦"});
	}
}

/*发送文言*/
function sendTextMessage(teamId) {
	var SessionType = 'team'
		SessionId = this.teamList[this.tabIndex].imTid
		console.log(this.teamList[this.tabIndex].imTid)
	var text = editArea.val().trim();
	if ( !! SessionId && !! text) {
	   if (text.length > 500) {
	        alert('消息长度最大为500字符')
	    }else if(text.length===0){
	        return
	    }else{
	    	editArea.val('')
	    	SDK.sendTextMessage(SessionType, SessionId, text,"", sendMsgDone)
	    }
	}
}
/**
 *  快捷键发送文本
 * 
 */
function inputMessageSend(e) {
    var ev = e || window.event
    if ($.trim(this.val()).length > 0) {
        if (ev.keyCode === 13 && ev.ctrlKey) {
        	//手动触发CLICK发送文言
  		    editSend.click()
        } else if (ev.keyCode === 13 && !ev.ctrlKey) {
 		   this.val(this.val() + '\r\n')
        }
    }
}


 /**
 * 发送消息完毕后的回调
 * @param error：消息发送失败的原因
 * @param msg：消息主体，类型分为文本、文件、图片、地理位置、语音、视频、自定义消息，通知等
 */
 function sendMsgDone(error, msg) {
	   console.log(msg)
	   if( error && (error.code =='803' || error.code =='802' ) ){
		   //没有权限    群不存在  不在群中，并且发送消息的话  默认被剔除  去除入口
		   $('.c-detail-c ul,.edit-area,#conversation_user_agency,#conversation_user_company,.his-name ul').empty()
		   custom.page=1
		   view.teamList.splice(view.tabIndex,1)//删除当前框
		   $('#conversation_list_ul li').eq(view.tabIndex).remove()
		   if ( view.teamList.length != 0) $("#conversation_list_ul li").eq(0).click().bind(view);
		   //初始化会话一览
		   return false
	   }
	   //消息已读
	   custom.imMessageId = msg.idServer
	   messageReceive()
	   
	   //更新视图
	   if(msg.content){
		   msg.content = JSON.parse(msg.content)
		   view.sendFileText(msg);
	   }else{
		   view.sendText(msg);
	   }
	   
	   
 }
 
/**
 *获取会话详情
 */
 messageDetail = function (params){
	 var params = params || {}
	 var param = {
			 "token":user_token,
			 "count":params.count || custom.count,
			 "page":params.page || custom.page,
			 "conversationId":custom.id
			 
	 }
	 api.messageDetail(param,
	     function(data){
			 if (BOLSTRA_CODE.api_result_ok == data.resultCd) {
				 data = data.results
				 view.defaultFirst(data)
			 }else {
				layer.alert('初始化数据失败', {title:"出错啦"});
			}
			
		 })
 }
 
 /**
  *加载更多获取会话详情
  */
 messageDetailAdd = function(errorCallback){
	 custom.page++;
	 addMoreLoading = layer.load(1,{shade: [0.5,'#000']});
	 var param = {
			 "token":user_token,
			 "count":custom.count,
			 "page":custom.page,
			 "conversationId":custom.id,
			 
			 
	 }
	 api.messageDetail(param,
	     function(data){
			 if (BOLSTRA_CODE.api_result_ok == data.resultCd) {
				 data = data.results
				 view.defaultFirst(data,true)
			 }else {
				 layer.alert('加载数据失败啦~', {title:"出错啦"});
			 }
			 custom.loadMore = true
			 layer.close(addMoreLoading)
		 },
		 function(data){//失败的回调
			 custom.page--;
			 custom.loadMore = true
			 layer.close(addMoreLoading)
			 layer.alert('加载数据失败啦~', {title:"出错啦"});
		 })
 }
 
 /**聊天历史记录滚动*/
function addHistoryContent(e){
	var Ele		 = $(e.delegateTarget);
		EleTop   = Ele.scrollTop(),
		EleH	 = Ele.height(),
		EleInner = Ele.children('ul').height();
		
	//console.log(Ele.scrollTop)
	if( EleTop <= 0 && EleInner > EleTop){
		console.log('可以开始加载了')
		custom.scrollTop = EleInner
		if( custom.loadMore ){
			custom.loadMore = false
			messageDetailAdd();
		}
	}
}
/**消息已读*/

function messageReceive(){
	
	var param = {
				"token" : user_token,
				"imMessageId" : custom.imMessageId
	};
	api.messageReceive(param, function(){
		
	});
}
//会话消息详情检索
function messageDetailHistory(){
	sendTimeFrom = $('#txtBeginDate').val()
	if (sendTimeFrom ){
		sendTimeFrom += ' 00:00:00.000'
	}
	sendTimeTo = $('#txtEndDate').val()
	if (sendTimeTo ){
		sendTimeTo += ' 23:59:59.999'
	}
	content = $('.fileChange input').val()
	keyword = ''
	var param = {
				"token" : user_token,
				"conversationId": custom.id,
				"page":1,
				"count":10,
				"sendTimeFrom":sendTimeFrom,
				"sendTimeTo":sendTimeTo,
				"content":content,
				"keyword":content
	};
	api.messageDetail(param, function(data){
		
		view.messageHistory(data.results)
	});
}
//选择成员
function selectAddMember(){
	
	$(this).css('background-color','red').siblings().css('background-color','inherit')
}

//添加该交易的相关人员。
function tradeMemberCreate(){
	api.tradeMemberCreate({
		"token" : user_token,
		"language":1,
		"tradeId":param.imTid,
		"userId":[]
	},function(data){
		
	})
}
//删除该交易的相关人员。
function tradeMemberDelete(){
	api.tradeMemberDelete({
		"token" : user_token,
		"language":1,
		"id":param.imTid,
		"updateTime":param.imOwnerId,
	},function(data){
		
	})
}
//init create webUploader
function initWebUploader(saveUrl){
	uploader = WebUploader.create({
	   	// 选完文件后，是否自动上传。  
		auto: false, 
	    // swf文件路径    
	    swf: '../lib/Uploader.swf',
	    // 文件接收服务端。
	    server: '',
	    // 内部根据当前运行是创建，可能是input元素，也可能是flash.
	    pick:{id:uploadBtn,multiple:false},
	    //是否已二进制的流的方式发送文件
	    sendAsBinary :false,
	    //验证文件总大小是否超出限制, 超出则不允许加入队列。int
	    //fileSizeLimit :
	    //文件上传方式，POST或者GET。  [默认值：'POST']
	    method :'POST',
	    // 不压缩image, 默认如果是jpeg，文件上传前会压缩一把再上传！
	    resize: false,
	    formData: {  
	        
	    }  
	});
	// 当有文件添加进来的时候
   	uploader.on( 'fileQueued', function( file ) {
   		
   		
	});
   	
   	uploader.on( 'beforeFileQueued', function( file ) {
   		
   		var fileSuffix = file.ext;
   		//fileType 10  对应 即时通讯 的序号
		api.fileUploadGetSign({
			"token": user_token,
			"fileType":10,
			"fileSuffix":fileSuffix
		},function(data){//回调
			//配置参数  开始请求
			var data = data.results
			var param = uploader.options
			console.data
			console.log('上传文件的回调')
			if( data){
				param.server = data.host
				param.formData.key = data.key,
				param.formData.policy = data.policy,
				param.formData.OSSAccessKeyId = data.accessid, 
				param.success_action_status = '200',
				param.formData.callback = data.callback 
				param.formData.signature = data.signature
				param.auto = true
				window.fileLoad= layer.load(1,{shade: [0.5,'#000']});
			} else{
				return false
			}
			
			
		})
	});
   	// 文件上传过程中创建进度条实时显示。
	uploader.on( 'uploadProgress', function( file, percentage ) {
		
		console.log(percentage * 100)
		

	});
	//文件成功、失败处理回调
	uploader.on( 'uploadSuccess', function( file,response ) {
	    //$( '#'+file.id ).find('p.state').text('已上传');
		console.log('上传成功')
		var fileSuffix = file.ext;
   		var name = file.name
   	    var src = response.results.url
   		var type = /png|jpg|bmp|jpeg|gif/i.test(fileSuffix) ? 'IMAGE' : 'FILE';
   		//fileUploadGetSign({"fileSuffix":fileType,"fileType":''})
   		var attach = {
        		"fileType":fileSuffix,
        		"url":src,
        		"fileId":response.results.id+'',
        		"type":type,
        		"fileName":name,
        		"topicType":view.teamList[view.tabIndex].topicType+'',
        		"topicTypeId":view.teamList[view.tabIndex].topicTypeId+'',
        		"userId":view.userId+'',
        		"companyId":view.companyId+''
        }
		uploader.makeThumb( file, function( error, src ) {
	        if ( error )   return;
	        
	        SDK.sendCustomMessage('team', view.teamList[view.tabIndex].imTid,attach, sendMsgDone)
	    });
		if ( type == 'FILE'){
			 SDK.sendCustomMessage('team', view.teamList[view.tabIndex].imTid,attach, sendMsgDone)
		}
		 
		//
	});
	
	uploader.on( 'uploadError', function( file ) {
	    //$( '#'+file.id ).find('p.state').text('上传出错');
		console.log('上传失败')
		layer.alert("上传文件失败", {icon: 5,title:"出错啦"});
		 //如果文件不为空  则放松请求
		//SDK.sendFileMessage('team', view.teams[view.tabIndex].teamId, file,sendMsgDone);
		
		
	});
	//无论成功失败
	uploader.on( 'uploadComplete', function( file ) {
	    //$( '#'+file.id ).find('.progress').fadeOut();
		layer.close(fileLoad)
	})
}

//处理@人的逻辑
function chooseNowPerson(text,debug){
	if( !debug ) {//发送消息
		if( text.indexOf('@') == -1 ) return false; //文本不存在@字符 
		text += ' ';
		html = text
		for( var h = 0 ; h < view.person.length; h++){
			newText = '@'+view.person[h]+' '
			
			if( text.indexOf(newText) != -1){
				html = html.replace(newText,'<span style="color:blue">'+newText+'</span>')
			}
		}
		
		return html
	} else {//画面刷新
		var newArr = []
		for( var i = 0 ;i<text.length;i++){
			if( text[i].content.indexOf('@') != -1 ){
				html = text[i].content + ' '
				newsHtml = html;
				for( var h = 0 ; h < view.person.length; h++){
					newText = '@'+view.person[h]+' '
					
					if( html.indexOf(newText) != -1){
						html = html.replace(newText,'<span style="color:blue">'+newText+'</span>')
					}
				}
				text[i].content = html
			}
		}
		//
		return text
	}
}
