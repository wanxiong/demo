(function() {
    // 配置
    var envir = 'bolstra';
    var configMap = {
        bolstra: {
            appkey: 'a3c0b1f82677a18330d47e5aa974a638',
            url:'https://app.netease.im'
        }
    };
    window.CONFIG = configMap[envir];
}())